//
//  Bundle+Extension.swift
//  HiralSigmaSolvePractical
//
//  Created by Hiral Jotaniya on 02/07/22.
//


import Foundation

// MARK: - SpreadSheetDataModel
struct SpreadSheetDataModel: Codable {
    let data: [MainDataObject]
}

// MARK: - MainDataObject
struct MainDataObject: Codable {
    let date: String?
    let teams: [Team]?
}

// MARK: - Team
struct Team: Codable {
    let name: String?
    let totalPoints: Int?
    let points: [Point]
}

// MARK: - Point
struct Point: Codable {
    let name: String?
    let color: String?
    let point: Int?
}
