//
//  Bundle+Extension.swift
//  HiralSigmaSolvePractical
//
//  Created by Hiral Jotaniya on 02/07/22.
//


import UIKit


class ViewController: UIViewController {
    
    // MARK: - IBOutlets
    @IBOutlet weak var spreadSheetView: SpreadsheetView!
    
    // MARK: - Variables
    private var arrMainData = [MainDataObject]()
    
    // MARK: - Life cycle methods
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setUpSpreadSheetView()
        self.getData()
    }
    
    // MARK: - functions
    private func getData() {
        let result = Bundle.main.decode(SpreadSheetDataModel.self, from: "document.json")
        arrMainData = result.data
    }
    
    private func setUpSpreadSheetView(){
        spreadSheetView.dataSource = self
        spreadSheetView.delegate = self
        spreadSheetView.contentInset = UIEdgeInsets(top: 1, left: 0, bottom: 1, right: 0)
        spreadSheetView.intercellSpacing = CGSize(width: 0, height: 0)
        spreadSheetView.gridStyle = .none
        spreadSheetView.register(TeamTableCell.self, forCellWithReuseIdentifier: String(describing: TeamTableCell.self))
        spreadSheetView.backgroundColor = UIColor(red: 250.0/255, green: 250.0/255, blue: 250.0/255, alpha: 1.0)
    }
}

// MARK: - Delegates
extension ViewController: SpreadsheetViewDataSource, SpreadsheetViewDelegate{
    
    func numberOfColumns(in spreadsheetView: SpreadsheetView) -> Int {
        return arrMainData.first?.teams?.first?.points.count ?? 0
    }
    
    func numberOfRows(in spreadsheetView: SpreadsheetView) -> Int {
        var numRow = 0
        for obj in arrMainData {
            numRow += obj.teams?.count ?? 0
        }
        return numRow + 4
    }
    
    func spreadsheetView(_ spreadsheetView: SpreadsheetView, widthForColumn column: Int) -> CGFloat {
        return 120
    }
    
    func spreadsheetView(_ spreadsheetView: SpreadsheetView, heightForRow row: Int) -> CGFloat {
        return 40
    }
    
    func spreadsheetView(_ spreadsheetView: SpreadsheetView, cellForItemAt indexPath: IndexPath) -> Cell? {
        
        if indexPath.row == 0 && indexPath.column != 0 {
            let cell = spreadsheetView.dequeueReusableCell(withReuseIdentifier: String(describing: TeamTableCell.self), for: indexPath) as! TeamTableCell
            cell.label.text = "\(indexPath.column)"
            cell.backgroundColor = .lightGray
            cell.label.textAlignment = .center
            cell.borders = .all(.solid(width: 1, color: .black))
            return cell
        }else {
            if indexPath.column == 0 && (indexPath.row > 0 && indexPath.row <= 4) {
                
                let cell = spreadsheetView.dequeueReusableCell(withReuseIdentifier: String(describing: TeamTableCell.self), for: indexPath) as! TeamTableCell
                if indexPath.row == 1 {
                    cell.label.text = arrMainData[0].date ?? "N/A"
                }else {
                    cell.label.text = arrMainData[0].teams?[indexPath.row - 2].name ?? "N/A"
                }
                
                cell.backgroundColor = .lightGray
                cell.label.textAlignment = .center
                
                cell.borders = .all(.solid(width: 1, color: .black))
                return cell
            }else if indexPath.column == 0 && (indexPath.row >= 5 && indexPath.row < 9){
                let cell = spreadsheetView.dequeueReusableCell(withReuseIdentifier: String(describing: TeamTableCell.self), for: indexPath) as! TeamTableCell
                
                let index = indexPath.row - 6
                
                if indexPath.row == 5 {
                    cell.label.text = arrMainData[1].date ?? "N/A"
                }else {
                    cell.label.text = arrMainData[1].teams?[index].name ?? "N/A"
                }
                
                cell.backgroundColor = .lightGray
                cell.label.textAlignment = .center
                cell.borders = .all(.solid(width: 1, color: .black))
                return cell
            }else if indexPath.column == 0 && indexPath.row >= 9 {
                let cell = spreadsheetView.dequeueReusableCell(withReuseIdentifier: String(describing: TeamTableCell.self), for: indexPath) as! TeamTableCell
                
                let index = indexPath.row - 10
                
                if indexPath.row == 9 {
                    cell.label.text = arrMainData[2].date ?? "N/A"
                }else {
                    cell.label.text = arrMainData[2].teams?[index].name ?? "N/A"
                }
                
                cell.backgroundColor = .lightGray
                cell.label.textAlignment = .center
                cell.borders = .all(.solid(width: 1, color: .black))
                return cell
            }else if indexPath.row == 1 || indexPath.row == 5 || indexPath.row == 9 {
                let cell = spreadsheetView.dequeueReusableCell(withReuseIdentifier: String(describing: TeamTableCell.self), for: indexPath) as! TeamTableCell
                cell.label.text = ""
                cell.backgroundColor = .lightGray
                cell.borders = .all(.none)
                return cell
            }else {
                if indexPath.row == 0 && indexPath.column == 0 {
                    return nil
                }
                let cell = spreadsheetView.dequeueReusableCell(withReuseIdentifier: String(describing: TeamTableCell.self), for: indexPath) as! TeamTableCell
                cell.label.text = "\(arrMainData[0].teams?[0].points[indexPath.column].point ?? 0)"
                cell.backgroundColor = .white
                cell.label.textAlignment = .center
                cell.borders = .all(.solid(width: 1, color: .black))
                return cell
            }
        }
    }
}

