//
//  TopView.swift
//  SwiftToSwiftUI
//
//  Created by Akash S on 22/01/2024.
//

import SwiftUI

struct TopView: View {
    
    let stackDateFormat: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateFormat = "dd MMM yyyy"
        return formatter
    }()
    
    var body: some View {
        VStack {
            HStack {
                VStack(alignment: .leading) {
                    Text("Good Afternoon")
                        .font(.smallFont)
                        .foregroundStyle(.white)
                    Text("John Doe")
                        .font(.mediumFont)
                        .foregroundStyle(.white)
                        .padding(.top,10)
                        .padding(.bottom,10)
                    Text("\(self.stackDateFormat.string(from: Date()))")
                        .font(.smallFont)
                        .foregroundStyle(.white)
                    Spacer()
                    Text("Reflection/Notes")
                        .font(.headline)
                        .foregroundStyle(.white)
                }
                Spacer()
                Button(action: {
                    print("TAP ON Profile")
                }, label: {
                    VStack(alignment: .trailing) {
                        Image(systemName: "person.fill")
                            .resizable()
                            .foregroundStyle(.white)
                            .frame(width: 40, height: 40, alignment: .center)
                            .padding(10)
                            .clipShape(Circle())
                    }
                    .background(Color.teal)
                    .clipShape(Circle())
//                    .padding()
                })
                
            }
            VStack {
                Button(action: {
                    print("TAP ON IMAGE")
                }, label: {
                    Image(systemName: "photo.artframe")
                        .resizable()
                        .padding()
                        .foregroundStyle(.black)
                        .frame(height: 400)
                })
               
            }
            .background(Color.white)
            .clipShape(RoundedRectangle(cornerRadius: 10))
            Spacer(minLength: 25)
            VStack {
                Button(action: {
                    print("TAP ON ALL COGENT FEED")
                }, label: {
                    VStack(alignment: .leading, spacing: 10) {
                        
                        HStack() {
                            Image(systemName: "photo.artframe")
                                .resizable()
                                .frame(width: 30,height: 30)
                                .foregroundStyle(.white)
                            Text("All Cogent Feed Reflections")
                                .foregroundStyle(.white)
                        }
                        .padding(10)
                    }
                    .frame(maxWidth: .infinity)
                })
            }
            .cornerRadiusWithBorder(radius: 5, borderLineWidth: 1, borderColor: .white)
        }
    }
}

#Preview {
    TopView()
}
