//
//  GoalView.swift
//  SwiftToSwiftUI
//
//  Created by Akash S on 24/01/2024.
//

import SwiftUI

struct GoalView: View {
    
    var goals = ["All","Mindset","Performance","Health","Mental Health","Fitness","Recharge","Professional"]
    
    var body: some View {
        VStack {
            
            Spacer(minLength: 40)
            HStack {
                Text("Goals + Affirmation Meditations")
                    .font(.title3)
                Spacer()
                Button(action: {
                    print("TAP ON See ALL")
                }, label: {
                    Text("See All")
                        .font(.mediumSmallFont)
                })
                
            }
            .foregroundStyle(.white)
            Spacer(minLength: 25)
            ScrollView(.horizontal) {
                LazyHStack {
                    ForEach(self.goals, id: \.self) { object in
                        Text(object)
                            .onAppear {
                                print(index)
                            }
                            .font(.footnote)
                        Spacer(minLength: 20)
                    }
                }
            }
            .foregroundStyle(.white)
            Spacer(minLength: 25)
            
            HStack {
                VStack {
                    Button(action: {
                        print("TAP MINDSET")
                    }, label: {
                        VStack(alignment: .leading, spacing: 10) {
                            
                            HStack() {
                                Image(systemName: "photo.artframe")
                                    .resizable()
                                    .frame(width: 30,height: 30)
                                    .foregroundStyle(.white)
                                Text("MindSet")
                                    .foregroundStyle(.white)
                            }
                            .padding(10)
                        }
                        .frame(maxWidth: .infinity)
                    })
                }
                .cornerRadiusWithBorder(radius: 5, borderLineWidth: 1, borderColor: .white)
                VStack {
                    Button(action: {
                        print("TAP PERFORMANCE")
                    }, label: {
                        VStack(alignment: .leading, spacing: 10) {
                            
                            HStack() {
                                Image(systemName: "photo.artframe")
                                    .resizable()
                                    .frame(width: 30,height: 30)
                                    .foregroundStyle(.white)
                                
                                Text("Performance")
                                    .foregroundStyle(.white)
                            }
                            .padding(10)
                        }
                        .frame(maxWidth: .infinity)
                    })
                }.cornerRadiusWithBorder(radius: 5, borderLineWidth: 1, borderColor: .white)
                
            }
            Spacer(minLength: 10)
            HStack {
                VStack {
                    Button(action: {
                        print("TAP MINDSET")
                    }, label: {
                        VStack(alignment: .leading, spacing: 10) {
                            
                            HStack() {
                                Image(systemName: "photo.artframe")
                                    .resizable()
                                    .frame(width: 30,height: 30)
                                    .foregroundStyle(.white)
                                Text("Health")
                                    .foregroundStyle(.white)
                            }
                            .padding(10)
                        }
                        .frame(maxWidth: .infinity)
                    })
                }
                .cornerRadiusWithBorder(radius: 5, borderLineWidth: 1, borderColor: .white)
                VStack {
                    Button(action: {
                        print("TAP PERFORMANCE")
                    }, label: {
                        VStack(alignment: .leading, spacing: 10) {
                            
                            HStack() {
                                Image(systemName: "photo.artframe")
                                    .resizable()
                                    .frame(width: 30,height: 30)
                                    .foregroundStyle(.white)
                                Text("Mental Health")
                                    .foregroundStyle(.white)
                            }
                            .padding(10)
                        }
                        .frame(maxWidth: .infinity)
                    })
                }.cornerRadiusWithBorder(radius: 5, borderLineWidth: 1, borderColor: .white)
            }
            Spacer(minLength: 15)
            HStack {
                VStack {
                    Button(action: {
                        print("TAP PERFORMANCE")
                    }, label: {
                        VStack(alignment: .leading, spacing: 10) {
                            
                            HStack() {
                                Image(systemName: "plus")
                                    .resizable()
                                    .frame(width: 15,height: 15)
                                    .foregroundStyle(.white)
                                Text("Add Goal")
                                    .foregroundStyle(.white)
                            }
                            .padding(10)
                        }
                        .frame(maxWidth: .infinity)
                        .frame(width: .infinity, height: 50, alignment: .center)
                    })
                }.cornerRadiusWithBorder(radius: 5, borderLineWidth: 1, borderColor: .white)
            }
            Spacer(minLength: 25)
           
        }
        .background(Color.blue)
    }
}

#Preview {
    GoalView()
}
