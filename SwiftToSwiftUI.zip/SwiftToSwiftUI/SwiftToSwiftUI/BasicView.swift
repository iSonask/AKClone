//
//  BasicView.swift
//  SwiftToSwiftUI
//
//  Created by Akash S on 22/01/2024.
//

import SwiftUI

struct BasicView: View {
    
    var body: some View {
        NavigationView {
            ScrollView() {
                
                ZStack() {
                    // Background color or other background views
                    Color.blue.edgesIgnoringSafeArea(.all)
                    
                    // Scrollable content
                    VStack {
                        TopView()
                        GoalView()
                        
                        VStack {
                            
                            VStack {
                                
                                Text("Health")
                                VStack {
                                    Button(action: {
                                        print("TAP ON IMAGE")
                                    }, label: {
                                        Text("Goal 1")
                                    })
                                    
                                }
                            }
                            
                        }
                            .clipShape(RoundedRectangle(cornerRadius: 10))
                            .frame(width: .infinity, height: 300, alignment: .center)
                        
                    }
                }
                .scrollIndicators(.hidden)
                .navigationBarTitle("Cogent", displayMode: .inline)
                .navigationBarColor(backgroundColor: Color.blue, titleColor: .white)
                .navigationBarItems(leading: HStack {
                    Image(systemName: "applelogo") // Replace with the name of your image
                        .foregroundColor(.white)
                        .position(x: 145)
                        .position(y: 24)
                    Button(action: {
                        print("Test2")
                    }, label: {
                    Image(systemName: "line.3.horizontal")
                        .foregroundStyle(.white)
                        .position(x: -5)
                            .position(y: 20)
                        
                    })
                }, trailing: HStack {
                    Button(action: {
                        print("Test")
                    }, label: {
                        Image(systemName: "bell.fill")
                            .foregroundStyle(.white)
                        
                    })
                }
                )
                .padding()
                
            }
            .background(Color.blue.edgesIgnoringSafeArea(.all))
            
            
        }
        
    }
}

#Preview {
    BasicView()
}


fileprivate struct ModifierCornerRadiusWithBorder: ViewModifier {
    var radius: CGFloat
    var borderLineWidth: CGFloat = 1
    var borderColor: Color = .gray
    var antialiased: Bool = true
    
    func body(content: Content) -> some View {
        content
            .cornerRadius(self.radius, antialiased: self.antialiased)
            .overlay(
                RoundedRectangle(cornerRadius: self.radius)
                    .inset(by: self.borderLineWidth)
                    .strokeBorder(self.borderColor, lineWidth: self.borderLineWidth, antialiased: self.antialiased)
            )
    }
}

extension View {
    func cornerRadiusWithBorder(radius: CGFloat, borderLineWidth: CGFloat = 1, borderColor: Color = .gray, antialiased: Bool = true) -> some View {
        modifier(ModifierCornerRadiusWithBorder(radius: radius, borderLineWidth: borderLineWidth, borderColor: borderColor, antialiased: antialiased))
    }
}

struct NavigationBarModifier: ViewModifier {

    var backgroundColor: UIColor?
    var titleColor: UIColor?
    

    init(backgroundColor: Color, titleColor: UIColor?) {
        self.backgroundColor = UIColor(backgroundColor)
        
        let coloredAppearance = UINavigationBarAppearance()
        coloredAppearance.configureWithTransparentBackground()
        coloredAppearance.backgroundColor = UIColor(backgroundColor)
        coloredAppearance.titleTextAttributes = [.foregroundColor: UIColor.white]
        coloredAppearance.largeTitleTextAttributes = [.foregroundColor: UIColor.white]
        coloredAppearance.shadowColor = .clear
        
        UINavigationBar.appearance().standardAppearance = coloredAppearance
        UINavigationBar.appearance().compactAppearance = coloredAppearance
        UINavigationBar.appearance().scrollEdgeAppearance = coloredAppearance
        UINavigationBar.appearance().tintColor = titleColor
    }

    func body(content: Content) -> some View {
        ZStack{
            content
            VStack {
                GeometryReader { geometry in
                    Color(self.backgroundColor ?? .clear)
                        .frame(height: geometry.safeAreaInsets.top)
                        .edgesIgnoringSafeArea(.top)
                    Spacer()
                }
            }
        }
    }
}

extension View {

    func navigationBarColor(backgroundColor: Color, titleColor: UIColor?) -> some View {
        self.modifier(NavigationBarModifier(backgroundColor: backgroundColor, titleColor: titleColor))
    }

}
