//
//  ViewController.swift
//  KVCDemo
//
//  Created by Akash S on 10/07/2023.
//

import UIKit

class ViewController: UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.

        let singleton = MyObject.shared

        // Set the value change handler
        singleton.valueChangeHandler = { newValue in
            print("New value: \(newValue)")
        }
        print("test")
        // Change the value of myProperty
        DispatchQueue.main.asyncAfter(deadline: .now() + 15.0) {
            singleton.myProperty = "Hello, World!1"
        }

        DispatchQueue.main.asyncAfter(deadline: .now() + 10.0) {
            singleton.myProperty = "Hello, World!2"
        }

        DispatchQueue.main.asyncAfter(deadline: .now() + 5.0) {
            singleton.myProperty = "Hello, World!3"
        }
    }
}

class MyObject: NSObject {
    // Create a shared instance of MyObject
    static let shared = MyObject()

    // The property to observe
    @objc dynamic var myProperty: String = ""

    // Closure-based delegate for handling value changes
    var valueChangeHandler: ((String) -> Void)?

    private var observation: NSKeyValueObservation?

    override private init() {
        super.init()

        // Register for KVO notifications
        observation = observe(\.myProperty, options: [.new]) { _, change in
            if let newValue = change.newValue {
                // Call the value change handler
                self.valueChangeHandler?(newValue)
            }
        }
    }
}
