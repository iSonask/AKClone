//
//  AppDelegate.swift
//  DemoRechability
//
//  Created by Akash on 08/10/24.
//

import Cocoa
import Reachability

@main
class AppDelegate: NSObject, NSApplicationDelegate {
    var reachability: Reachability?

    func applicationDidFinishLaunching(_ aNotification: Notification) {
        // Insert code here to initialize your application
        //declare this property where it won't go out of scope relative to your listener
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
            self.stopNotifier()
            self.setupReachability(nil, useClosures: true)
            self.startNotifier()
        }
    }
    
    func setupReachability(_ hostName: String?, useClosures: Bool) {
        let reachability: Reachability?
        if let hostName = hostName {
            reachability = try? Reachability(hostname: "")
             print(hostName)
        } else {
            reachability = try? Reachability()
            print("No host name")
        }
        self.reachability = reachability
        
        reachability?.whenReachable = { reachability in
            if reachability.connection == .wifi || reachability.connection == .cellular {
                print("CONNECTED")
            } else {
                print("NOT CONNECTED")
            }
            print("\(reachability.connection)")
        }
        
        reachability?.whenUnreachable = { reachability in
            print("\(reachability.connection)")
        }
       
    }
    
    func startNotifier() {
        print("--- started notifier")
        do {
            try reachability?.startNotifier()
        } catch {
            print("Unable to start\nnotifier")
            return
        }
    }
    
    func stopNotifier() {
        print("--- stop notifier")
        reachability?.stopNotifier()
        reachability = nil
    }

    func applicationWillTerminate(_ aNotification: Notification) {
        // Insert code here to tear down your application
    }

    func applicationSupportsSecureRestorableState(_ app: NSApplication) -> Bool {
        return true
    }


}

