//
//  ViewController.swift
//  DemoRechability
//
//  Created by Akash on 08/10/24.
//

import Cocoa
import Reachability
class ViewController: NSViewController {
    

    override func viewDidLoad() {
        super.viewDidLoad()
        view.wantsLayer = true
        
    }
    override var representedObject: Any? {
        didSet {
            // Update the view, if already loaded.
        }
    }
    
    
}

