//
//  ViewController.swift
//  TimeDemo
//
//  Created by Akash on 10/09/24.
//

import Cocoa

class ViewController: NSViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        trackChromeTime()
    }

    override var representedObject: Any? {
        didSet {
        // Update the view, if already loaded.
        }
    }
    
    func getActiveChromeWindowTitle() -> String? {
        let workspace = NSWorkspace.shared
        let frontApp = workspace.frontmostApplication

        if let appName = frontApp?.localizedName, appName == "Google Chrome" {
            if let windowsInfo = CGWindowListCopyWindowInfo(.optionOnScreenOnly, kCGNullWindowID) as? [[String: Any]] {
                for window in windowsInfo {
                    if let ownerName = window[kCGWindowOwnerName as String] as? String, ownerName == "Google Chrome",
                       let windowTitle = window[kCGWindowName as String] as? String {
                        return windowTitle
                    }
                }
            }
        }
        return nil
    }

    func trackChromeTime() {
        var lastWindowTitle: String?
        var totalTimeSpent: [String: TimeInterval] = [:]
        var startTime = Date()

        Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { _ in
            if let windowTitle = self.getActiveChromeWindowTitle() {
                if windowTitle != lastWindowTitle {
                    if let lastTitle = lastWindowTitle {
                        let timeSpent = Date().timeIntervalSince(startTime)
                        totalTimeSpent[lastTitle] = (totalTimeSpent[lastTitle] ?? 0) + timeSpent
                        print("Time spent on \(lastTitle): \(totalTimeSpent[lastTitle]!) seconds")
                    }
                    lastWindowTitle = windowTitle
                    startTime = Date()
                    print("Switched to \(windowTitle)")
                }
            }
        }
    }
}

