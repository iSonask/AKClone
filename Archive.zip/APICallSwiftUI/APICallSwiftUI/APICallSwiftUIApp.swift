//
//  APICallSwiftUIApp.swift
//  APICallSwiftUI
//
//  Created by Akash on 08/10/24.
//

import SwiftUI

@main
struct APICallSwiftUIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
