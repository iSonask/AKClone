//
//  ContentView.swift
//  APICallSwiftUI
//
//  Created by Akash on 08/10/24.
//

import SwiftUI

struct ContentView: View {
    
    @State private var user: GithubUser?
    
    var body: some View {
        VStack(spacing: 20) {
            
            AsyncImage(url: URL(string: user?.avatarUrl ?? "")) { image in
                image
                    .resizable()
                    .frame(width: 150,height: 150)
                    .aspectRatio(contentMode: .fill)
                    .clipShape(Circle())

            } placeholder: {
                Circle()
                    .foregroundStyle(.secondary)
                    .frame(width: 100,height: 100)
            }

            
            Text(user?.login ?? "")
                .bold()
                .font(.title2)
            Text(user?.bio ?? "")
                .padding()
            Spacer()
        }
        .padding()
        .task {
            do {
                user =  try await getUser()
            } catch GHError.invalidURL {
                
            } catch GHError.invalidResponse {
                
            } catch GHError.invalidData {
                
            } catch {
                print("ERROR Unexpected")
            }
        }
    }
    
    func getUser() async throws -> GithubUser {
        
        let endpoint = "https://api.github.com/users/twostraws"
        
        guard let url = URL(string: endpoint ) else { throw GHError.invalidURL }
        
        let (data, response ) = try await URLSession.shared.data(from: url)
        
        guard let response = response as? HTTPURLResponse, response.statusCode == 200 else { throw GHError.invalidResponse }
        
        do {
            let decoder = JSONDecoder()
            decoder.keyDecodingStrategy = .convertFromSnakeCase
            return try decoder.decode(GithubUser.self, from: data)
        } catch {
            throw GHError.invalidData
        }
    }
    
}

#Preview {
    ContentView()
}


struct GithubUser: Codable  {
    let login: String
    let avatarUrl: String
    let bio: String
}


enum GHError: Error {
case invalidURL
    case invalidResponse
    case invalidData
}
