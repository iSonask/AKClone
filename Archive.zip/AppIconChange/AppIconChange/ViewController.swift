//
//  ViewController.swift
//  AppIconChange
//
//  Created by Akash on 26/09/24.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        if UIApplication.shared.supportsAlternateIcons {
            print(UIApplication.shared.alternateIconName ?? "Primary")

            // let the user choose a new icon
        }

        // Do any additional setup after loading the view.
        DispatchQueue.main.asyncAfter(deadline: .now() + 5) {
            UIApplication.shared.setAlternateIconName(nil)
            UIApplication.shared.setAlternateIconName("appIc") { error in
                if let error = error {
                    print(error.localizedDescription)
                } else {
                    print("Success!")
                }
            }
        }
    }


}

