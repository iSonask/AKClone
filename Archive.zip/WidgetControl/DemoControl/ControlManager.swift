//
//  ControlManager.swift
//  ControlCenterWidget
//
//  Created by Akash on 08/10/24.
//

class ControlManager {
    static let shared = ControlManager()
    var isRunning = false
    var glassOfWater = 0
}
