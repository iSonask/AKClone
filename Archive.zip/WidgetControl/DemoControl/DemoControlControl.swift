//
//  DemoControlControl.swift
//  DemoControl
//
//  Created by Akash on 08/10/24.
//

import AppIntents
import SwiftUI
import WidgetKit

struct DemoControlControl: ControlWidget {
    var body: some ControlWidgetConfiguration {
        StaticControlConfiguration(
            kind: "com.ControlCenterWidget.DemoControl"
        ){
            
            ControlWidgetButton(action: WaterIntakeIntent(count: 1)) {
                Text("You had \(ControlManager.shared.glassOfWater) glass of water")
                Image(systemName: ControlManager.shared.glassOfWater >= 5 ? "wineglass.fill" : "wineglass")
                    .tint(.cyan)
            }
        }
        
//        {
//            ControlWidgetToggle(
//                "Turn \(ControlManager.shared.isRunning ? "Off" : "On" ) FlashLight",
//                isOn: ControlManager.shared.isRunning,
//                action: FlashControlIntent()
//            ) { isRunning in
//                Label(isRunning ? "On" : "Off", systemImage: isRunning ? "flashlight.on.fill" : "flashlight.off.fill")
//            }
//            .tint(.green)
//        }
//        .displayName("Flash")
//        .description("A an example control that turn on of flashlight")
    }
}

//extension DemoControlControl {
//    struct Provider: ControlValueProvider {
//        var previewValue: Bool {
//            false
//        }
//
//        func currentValue() async throws -> Bool {
//            let isRunning = true // Check if the timer is running
//            return isRunning
//        }
//    }
//}

struct FlashControlIntent: SetValueIntent {
    static let title: LocalizedStringResource = "Start a FlashLight"

    @Parameter(title: "FlashLight is On")
    var value: Bool

    func perform() async throws -> some IntentResult {
        // Start / stop the timer based on `value`.
        ControlManager.shared.isRunning = value
        return .result()
    }
}


struct WaterIntakeIntent: AppIntent {
    static let title: LocalizedStringResource = "Record Water Intake"
    @Parameter(title: "Add Water Intake")
    var count: Int

    init() {}
    
    
    init(count: Int) {
        self.count = count
    }
    
    func perform() async throws -> some IntentResult {
        ControlManager.shared.glassOfWater += count
        WidgetCenter.shared.reloadAllTimelines()
        return .result()
    }
}
