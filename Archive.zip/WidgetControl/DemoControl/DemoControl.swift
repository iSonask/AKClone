//
//  DemoControl.swift
//  DemoControl
//
//  Created by Akash on 08/10/24.
//

import WidgetKit
import SwiftUI
struct WaterIntakeEntry: TimelineEntry {
    var date: Date
    
    let waterIntake: String
}

struct GetProviderEx: TimelineProvider {
    func placeholder(in context: Context) -> WaterIntakeEntry {
        WaterIntakeEntry(date: Date(), waterIntake: "0")
    }
    
    func getSnapshot(in context: Context, completion: @escaping (Entry) -> Void) {
        let entry = WaterIntakeEntry(date: Date(), waterIntake: "0")
        completion(entry)
    }
    
    func getTimeline(in context: Context, completion: @escaping (Timeline<WaterIntakeEntry>) -> Void) {
        var entries = [WaterIntakeEntry]()
        let currentDate = Date()
        for hourOffset in 0 ..< 5 {
            let entryDate = Calendar.current.date(byAdding: .second, value: hourOffset, to: currentDate)!
            let entry = WaterIntakeEntry(date: entryDate, waterIntake: "\(ControlManager.shared.glassOfWater)")
            entries.append(entry)
        }
        let timeline = Timeline(entries: entries, policy: .atEnd)
        completion(timeline)
    }
}

struct DemoControlEntryView : View {
//    var entry: Provider.Entry
    var entry: GetProviderEx.Entry

    var body: some View {
        VStack {
            
            Text("Current Time:")
            Text(entry.date, style: .time)
            Text("Glass - \(entry.waterIntake)")
        }
    }
}

struct DemoControl: Widget {
    let kind: String = "DemoControl"

    var body: some WidgetConfiguration {
        StaticConfiguration(kind: kind, provider: GetProviderEx()) { entry in
            if #available(iOS 17.0, *) {
                DemoControlEntryView(entry: entry)
                    .containerBackground(.fill.tertiary, for: .widget)
                    
            } else {
                DemoControlEntryView(entry: entry)
                    .padding()
                    .background()
            }
        }
        
        .configurationDisplayName("My Widget")
        .description("This is an example widget.")
    }
}

#Preview(as: .systemSmall) {
    DemoControl()
} timeline: {
    WaterIntakeEntry(date: .now, waterIntake: "1")
}
