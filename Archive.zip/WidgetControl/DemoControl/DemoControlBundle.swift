//
//  DemoControlBundle.swift
//  DemoControl
//
//  Created by Akash on 08/10/24.
//

import WidgetKit
import SwiftUI

@main
struct DemoControlBundle: WidgetBundle {
    var body: some Widget {
        
        DemoControl()
        DemoControlControl()
    }
}
