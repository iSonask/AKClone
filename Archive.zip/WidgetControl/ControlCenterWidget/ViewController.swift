//
//  ViewController.swift
//  ControlCenterWidget
//
//  Created by Akash on 08/10/24.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
    }


}


//MARK: IF We want to add wdget inside lockscreen below is code.
/*
 
 //
 //  DemoControl.swift
 //  DemoControl
 //
 //  Created by Akash on 08/10/24.
 //

 import WidgetKit
 import SwiftUI
 struct WaterIntakeEntry: TimelineEntry {
     var date: Date
     
     let waterIntake: String
 }

 struct GetProviderEx: TimelineProvider {
     func placeholder(in context: Context) -> WaterIntakeEntry {
         WaterIntakeEntry(date: Date(), waterIntake: "0")
     }
     
     func getSnapshot(in context: Context, completion: @escaping (Entry) -> Void) {
         let entry = WaterIntakeEntry(date: Date(), waterIntake: "0")
         completion(entry)
     }
     
     func getTimeline(in context: Context, completion: @escaping (Timeline<WaterIntakeEntry>) -> Void) {
         var entries = [WaterIntakeEntry]()
         let currentDate = Date()
         for hourOffset in 0 ..< 5 {
             let entryDate = Calendar.current.date(byAdding: .second, value: hourOffset, to: currentDate)!
             let entry = WaterIntakeEntry(date: entryDate, waterIntake: "\(ControlManager.shared.glassOfWater)")
             entries.append(entry)
         }
         let timeline = Timeline(entries: entries, policy: .atEnd)
         completion(timeline)
     }
 }

 struct DemoControlEntryView : View {
 //    var entry: Provider.Entry
     var entry: GetProviderEx.Entry
     @Environment(\.widgetFamily) var widgetFamily
     var body: some View {
         switch widgetFamily {
             
         case .accessoryCircular:
             Gauge(value: Double(entry.waterIntake) ?? 0.5) {
                 Text(entry.waterIntake)
             }
             .gaugeStyle(.accessoryCircular)
         case .accessoryRectangular:
             Gauge(value: Double(entry.waterIntake) ?? 0.5) {
                 Text(entry.waterIntake)
             }
             .gaugeStyle(.accessoryLinear)
         case .accessoryInline:
             Text(entry.waterIntake)
         default:
             VStack {
                 Text("Time:")
                 Text(entry.date, style: .time)
                 Text(entry.waterIntake)
             }
         }
     }
 }

 struct DemoControl: Widget {
     let kind: String = "DemoControl"

     var body: some WidgetConfiguration {
         StaticConfiguration(kind: kind, provider: GetProviderEx()) { entry in
             if #available(iOS 17.0, *) {
                 DemoControlEntryView(entry: entry)
                     .containerBackground(.fill.tertiary, for: .widget)
                     
             } else {
                 DemoControlEntryView(entry: entry)
                     .padding()
                     .background()
             }
         }
         
         .configurationDisplayName("My Widget")
         .description("This is an example widget.")
         .supportedFamilies([.accessoryInline,.accessoryCircular,.accessoryRectangular])
     }
 }
 struct DemoControl_Previews: PreviewProvider {
     static var previews: some View {
         DemoControlEntryView(entry: WaterIntakeEntry(date: Date(), waterIntake: "1"))
             .previewContext(WidgetPreviewContext(family: .accessoryInline))
             .previewDisplayName("Inline")
         
         DemoControlEntryView(entry: WaterIntakeEntry(date: Date(), waterIntake: "1"))
             .previewContext(WidgetPreviewContext(family: .accessoryCircular))
             .previewDisplayName("Circular")
         
         DemoControlEntryView(entry: WaterIntakeEntry(date: Date(), waterIntake: "1"))
             .previewContext(WidgetPreviewContext(family: .accessoryRectangular))
             .previewDisplayName("Rectangular")
         
     }
 }
 #Preview(as: .systemSmall) {
     DemoControl()
     
 } timeline: {
     WaterIntakeEntry(date: .now, waterIntake: "1")
 }

 
 */
