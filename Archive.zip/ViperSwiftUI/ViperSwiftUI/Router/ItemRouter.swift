//
//  ItemRouter.swift
//  ViperSwiftUI
//
//  Created by Akash on 23/10/24.
//

// VIPER/Router/ItemRouter.swift
import SwiftUI

class ItemRouter {
    func createModule() -> some View {
        var view = ItemView()
        let interactor = ItemInteractor()
        let presenter = ItemPresenter(view: view, interactor: interactor)
        view.presenter = presenter
        return view
    }
}
