//
//  Tab2Router.swift
//  ViperSwiftUI
//
//  Created by Akash on 23/10/24.
//

// VIPER/Home/Tab2/Tab2Router.swift
import SwiftUI

class Tab2Router {
    func createTab2Module() -> some View {
        Tab2View()
    }
}
