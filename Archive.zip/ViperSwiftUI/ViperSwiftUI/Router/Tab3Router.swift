//
//  Tab3Router.swift
//  ViperSwiftUI
//
//  Created by Akash on 23/10/24.
//

// VIPER/Home/Tab3/Tab3Router.swift
import SwiftUI

class Tab3Router {
    func createTab3Module() -> some View {
        Tab3View()
    }
}
