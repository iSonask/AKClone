//
//  LoginRouter.swift
//  ViperSwiftUI
//
//  Created by Akash on 23/10/24.
//

// VIPER/Login/LoginRouter.swift
import SwiftUI

protocol LoginRouterProtocol {
    func navigateToHome()
}

class LoginRouter: LoginRouterProtocol {
    var view: LoginView?
    
    func navigateToHome() {
        view?.isLoggedIn = true
    }
    
    func createLoginModule() -> some View {
        var view = LoginView()
        let interactor = LoginInteractor()
        let router = LoginRouter()
        let presenter = LoginPresenter(view: view, interactor: interactor, router: router)
        view.presenter = presenter
        router.view = view
        return view
    }
}
