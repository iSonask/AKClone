//
//  HomeRouter.swift
//  ViperSwiftUI
//
//  Created by Akash on 23/10/24.
//

// VIPER/Home/HomeRouter.swift
import SwiftUI

class HomeRouter {
    func createHomeModule() -> some View {
        HomeView()
    }
}
