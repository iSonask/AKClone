//
//  Tab1Router.swift
//  ViperSwiftUI
//
//  Created by Akash on 23/10/24.
//

// VIPER/Home/Tab1/Tab1Router.swift
import SwiftUI

class Tab1Router {
    func createTab1Module() -> some View {
        Tab1View()
    }
}
