//
//  Item.swift
//  ViperSwiftUI
//
//  Created by Akash on 23/10/24.
//

struct Item {
    let id: Int
    let name: String
    let description: String
}
