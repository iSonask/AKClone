//
//  User.swift
//  ViperSwiftUI
//
//  Created by Akash on 23/10/24.
//

// VIPER/Login/LoginEntity.swift
struct User {
    let username: String
    let password: String
}
