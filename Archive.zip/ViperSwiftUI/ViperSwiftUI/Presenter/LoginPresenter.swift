//
//  LoginPresenter.swift
//  ViperSwiftUI
//
//  Created by Akash on 23/10/24.
//

// VIPER/Login/LoginPresenter.swift
protocol LoginPresenterProtocol: AnyObject {
    func login(username: String, password: String)
}


protocol LoginViewProtocol {
    func login(username: String, password: String)
    func showLoginError(_ message: String)
}
class LoginPresenter: LoginPresenterProtocol {
    private var view: LoginViewProtocol?
    private var interactor: LoginInteractorProtocol
    private var router: LoginRouterProtocol
    
    init(view: LoginViewProtocol, interactor: LoginInteractorProtocol, router: LoginRouterProtocol) {
        self.view = view
        self.interactor = interactor
        self.router = router
    }
    
    func login(username: String, password: String) {
        if interactor.login(username: username, password: password) {
            router.navigateToHome()
        } else {
            view?.showLoginError("Invalid credentials")
        }
    }
}
