//
//  ItemPresenter.swift
//  ViperSwiftUI
//
//  Created by Akash on 23/10/24.
//

import SwiftUI

protocol ItemPresenterProtocol: AnyObject {
    func getItems() -> [Item]
}

protocol ItemViewProtocol {
    func displayItems(_ items: [Item])
}

class ItemPresenter: ItemPresenterProtocol {
    private var view: ItemViewProtocol?
    private var interactor: ItemInteractorProtocol
    
    init(view: ItemViewProtocol, interactor: ItemInteractorProtocol) {
        self.view = view
        self.interactor = interactor
    }
    
    func getItems() -> [Item] {
        return interactor.fetchItems()
    }
}
