//
//  Tab2View.swift
//  ViperSwiftUI
//
//  Created by Akash on 23/10/24.
//

// VIPER/Home/Tab2/Tab2View.swift
import SwiftUI

struct Tab2View: View {
    let columns = [
        GridItem(.flexible()),
        GridItem(.flexible())
    ]
    
    let items = ["Item A", "Item B", "Item C", "Item D"]
    
    var body: some View {
        ScrollView {
            LazyVGrid(columns: columns, spacing: 20) {
                ForEach(items, id: \.self) { item in
                    Text(item)
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.blue)
                        .cornerRadius(8)
                        .foregroundColor(.white)
                }
            }
            .padding()
        }
    }
}
