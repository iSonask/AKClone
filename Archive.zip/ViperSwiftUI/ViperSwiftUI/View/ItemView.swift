//
//  ItemView.swift
//  ViperSwiftUI
//
//  Created by Akash on 23/10/24.
//

// VIPER/View/ItemView.swift
import SwiftUI


struct ItemView: View, ItemViewProtocol {
    @State private var items: [Item] = []
    var presenter: ItemPresenterProtocol?
    
    var body: some View {
        List(items, id: \.id) { item in
            VStack(alignment: .leading) {
                Text(item.name)
                    .font(.headline)
                Text(item.description)
                    .font(.subheadline)
            }
        }
        .onAppear {
            items = presenter?.getItems() ?? []
        }
    }
    
//    func displayItems(_ items: [Item]) {
//        self.items = items
//    }

    func displayItems(_ items: [Item]) {
        self.items = items
    }
}
