//
//  Tab1View.swift
//  ViperSwiftUI
//
//  Created by Akash on 23/10/24.
//

// VIPER/Home/Tab1/Tab1View.swift
import SwiftUI

struct Tab1View: View {
    let items = ["Item 1", "Item 2", "Item 3"]
    
    var body: some View {
        List(items, id: \.self) { item in
            Text(item)
        }
    }
}
