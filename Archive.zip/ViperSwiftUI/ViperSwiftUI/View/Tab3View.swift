//
//  Tab3View.swift
//  ViperSwiftUI
//
//  Created by Akash on 23/10/24.
//

// VIPER/Home/Tab3/Tab3View.swift
import SwiftUI

struct Tab3View: View {
    @Environment(\.presentationMode) var presentationMode
    @State private var isLoggedOut = false
    
    var body: some View {
        Button(action: {
            isLoggedOut = true
        }) {
            Text("Logout")
                .padding()
                .background(Color.red)
                .foregroundColor(.white)
                .cornerRadius(8)
        }
        .fullScreenCover(isPresented: $isLoggedOut) {
            LoginRouter().createLoginModule()
        }
    }
}
