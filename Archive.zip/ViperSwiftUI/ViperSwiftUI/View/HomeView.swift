//
//  HomeView.swift
//  ViperSwiftUI
//
//  Created by Akash on 23/10/24.
//

// VIPER/Home/HomeView.swift
import SwiftUI

struct HomeView: View {
    var body: some View {
        TabView {
            Tab1Router().createTab1Module()
                .tabItem {
                    Label("List", systemImage: "list.bullet")
                }
            Tab2Router().createTab2Module()
                .tabItem {
                    Label("Grid", systemImage: "square.grid.2x2")
                }
            Tab3Router().createTab3Module()
                .tabItem {
                    Label("Logout", systemImage: "arrow.backward.circle")
                }
        }
    }
}
