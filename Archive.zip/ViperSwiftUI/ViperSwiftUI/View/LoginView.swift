//
//  LoginView.swift
//  ViperSwiftUI
//
//  Created by Akash on 23/10/24.
//
import SwiftUI



struct LoginView: View, LoginViewProtocol {
    
    
    @State private var username = ""
    @State private var password = ""
    @State private var errorMessage = ""
    @State var isLoggedIn = false
    
    var presenter: LoginPresenterProtocol?
    
    var body: some View {
        VStack {
            TextField("Username", text: $username)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .padding()
            SecureField("Password", text: $password)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .padding()
            
            Button(action: {
                presenter?.login(username: username, password: password)
            }) {
                Text("Login")
                    .padding()
                    .background(Color.blue)
                    .foregroundColor(.white)
                    .cornerRadius(8)
            }
            
            if !errorMessage.isEmpty {
                Text(errorMessage)
                    .foregroundColor(.red)
                    .padding()
            }
        }
        .fullScreenCover(isPresented: $isLoggedIn) {
            HomeRouter().createHomeModule()
        }
    }
    
    func showLoginError(_ message: String) {
        errorMessage = message
    }
    
    func login(username: String, password: String) {
        
    }
}
