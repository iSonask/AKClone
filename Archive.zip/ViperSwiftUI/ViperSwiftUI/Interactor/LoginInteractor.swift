//
//  LoginInteractor.swift
//  ViperSwiftUI
//
//  Created by Akash on 23/10/24.
//

// VIPER/Login/LoginInteractor.swift
protocol LoginInteractorProtocol {
    func login(username: String, password: String) -> Bool
}

class LoginInteractor: LoginInteractorProtocol {
    func login(username: String, password: String) -> Bool {
        // Simulating login logic. In a real app, you'd call a service or database.
        return username == "admin" && password == "password"
    }
}
