//
//  ViperSwiftUIApp.swift
//  ViperSwiftUI
//
//  Created by Akash on 23/10/24.
//

import SwiftUI

@main
struct ViperSwiftUIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
