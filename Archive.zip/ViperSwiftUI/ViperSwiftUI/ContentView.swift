//
//  ContentView.swift
//  ViperSwiftUI
//
//  Created by Akash on 23/10/24.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
//        ItemRouter().createModule()
        LoginRouter().createLoginModule()
    }
}

#Preview {
    ContentView()
}
