//
//  CommonCoordinator.swift
//  CoordinatorSwiftui
//
//  Created by Akash on 11/11/24.
//
import SwiftUI

class CommonCoordinator: NavigationCoordinator {
    
    // screens available for navigation
    enum Screen: ScreenProtocol {
        case first
        case second
        case third
        case fourth
    }
    
    // view for each screen
    func destination(for screen: Screen) -> some View {
        switch screen {
        case .first: ContentView()
        case .second: FirstView()
        case .third: SecondView()
        case .fourth: ThirdView()
        }
    }
}
