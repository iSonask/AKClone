//
//  ContentView.swift
//  CoordinatorSwiftui
//
//  Created by Akash on 11/11/24.
//

import SwiftUI

struct ContentView: View {
    @EnvironmentObject var coordinator: Navigation<CommonCoordinator>

    init() {
        // Set the color of unselected tab bar items
        UITabBar.appearance().unselectedItemTintColor = UIColor.white
    }

    var body: some View {
//        TabView{
//            FirstView()
//                .tabItem {
//                                    Label("Home", systemImage: "house")
//                                }
//            SecondView()
//                .tabItem {
//                                    Label("Search", systemImage: "magnifyingglass")
//                                }
//            ThirdView()
//                .tabItem {
//                                    Label("Profile", systemImage: "person")
//                                }
//        }
//        .accentColor(.black)
        VStack {
            Button("Second") {
                // navigation to the second screen
                coordinator().present(.second)
            }
            Button("Third") {
                // navigation to the third screen
                coordinator().present(.third)
            }
        }
    }
}

#Preview {
    ContentView()
}


struct FirstView: View {

    var body: some View {
        Color.red
            .ignoresSafeArea(.all)
    }
}


struct SecondView: View {
    @EnvironmentObject var coordinator: Navigation<CommonCoordinator>

    var body: some View {
        Color.secondary
            .ignoresSafeArea(.all)
    }
}


struct ThirdView: View {
    @EnvironmentObject var coordinator: Navigation<CommonCoordinator>

    var body: some View {
        Color.teal
            .ignoresSafeArea(.all)
    }
}
