//
//  Coordinator.swift
//  CoordinatorSwiftui
//
//  Created by Akash on 11/11/24.
//

import Foundation
import SwiftUI
import Combine

///Example:
///
///    final class SomeCoordinator: NavigationModalCoordinator {
///
///      enum Screen: ScreenProtocol {
///         case screen1
///         case screen2
///         case screen3
///      }
///
///      func destination(for screen: Screen) -> some View {
///         switch screen {
///             case .screen1: Screen1View()
///             case .screen2: Screen2View()
///             case .screen3: Screen3View()
///         }
///      }
///
///      enum ModalFlow: ModalProtocol {
///         case modalScreen1
///         case modalFlow(ChildCoordinator = .init())
///      }
///
///      func destination(for flow: ModalFlow) -> some View {
///         switch flow {
///            case .modalScreen1: Modal1View()
///            case .modalFlow(let coordinator): coordinator.view(for: .rootScreen)
///         }
///      }
///    }
///
///SomeCoordinator contains a navigation controller that can push one of the 3 views defined by Screen enum.
///Also it can present a modal view and a modal navigation flow with child navigation specified by ChildCoordinator
///
///Show view in SwiftUI hierarchy, with screen1 as root view:
///
///     coordinator.view(for: .screen1)
///
///Push view in navigation stack:
///
///     coordinator.present(.screen1)
///
///Present modal view:
///
///     coordinator.present(.modalFlow())
///

///A class representing a weak reference for a specific Coordinator, that is passed by as an EnvironmentObject
@MainActor
public final class Navigation<C: Coordinator>: ObservableObject {
    private(set) weak var object: C?
    private var observer: AnyCancellable?
    
    public init(_ object: C) {
        self.object = object
        
        ///Observer triggers changes to the SwiftUI view when the Coordinator changes
        observer = object.objectWillChange.sink { [weak self] _ in
            self?.objectWillChange.send()
        }
    }
    
    ///Access the Coordinator via a function call
    public func callAsFunction() -> C { object! }
}

///A protocol representing a Coordinator, which manages the navigation flow and must be ObservableObject and Hashable
public protocol Coordinator: ObservableObject, Hashable { }

///A unique key for associating a Coordinator state
private var coordinatorStateKey: UInt8 = 0

///A unique key for associating a Coordinator weak reference
private var coordinatorWeakReferenceKey: UInt8 = 0

public extension Coordinator {
    
    ///Coordinator state, encapsulates current navigation path and presented modal flow and reference to parent coordinator
    @MainActor var state: NavigationState {
        get {
            if let state = objc_getAssociatedObject(self, &coordinatorStateKey) as? NavigationState {
                return state
            } else {
                let state = NavigationState()
                objc_setAssociatedObject(self, &coordinatorStateKey, state, .OBJC_ASSOCIATION_RETAIN)
                return state
            }
        }
    }
    
    ///A weak reference to this Coordiantor, it is passed by using EnvironmentObject
    @MainActor var weakReference: Navigation<Self> {
        get {
            if let reference = objc_getAssociatedObject(self, &coordinatorWeakReferenceKey) as? Navigation<Self> {
                return reference
            } else {
                let reference = Navigation(self)
                objc_setAssociatedObject(self, &coordinatorWeakReferenceKey, reference, .OBJC_ASSOCIATION_RETAIN)
                return reference
            }
        }
    }
    
    func hash(into hasher: inout Hasher) {
        hasher.combine(ObjectIdentifier(self))
    }
    
    static func == (lhs: Self, rhs: Self) -> Bool { lhs.hashValue == rhs.hashValue }
    
    ///Dismiss modal navigation of this Coordiantor
    @MainActor func dismiss() {
        state.presentedBy?.dismissPresented()
    }
    
    ///Dismiss modal navigation presented over this Coordinator
    @MainActor func dismissPresented() {
        state.modalPresented = nil
    }
    
    ///Move to the previous screen of the current navigation stack
    @MainActor func pop() {
        state.path.removeLast()
    }
    
    ///Pops all views and returns to the root view
    @MainActor func popToRoot() {
        state.path.removeAll()
    }
}

@MainActor
extension Coordinator {
    
    ///Presents a new modal or navigation presentation based on the given ModalPresentation and resolve policy
    func present(_ presentation: ModalPresentation, resolve: PresentationResolve = .overAll) {
        if let presentedCoordinator = state.modalPresented?.coordinator {
            switch resolve {
            case .replaceCurrent:
                dismissPresented()
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) { [weak self] in
                    self?.present(presentation, resolve: resolve)
                }
            case .overAll:
                presentedCoordinator.present(presentation, resolve: resolve)
            }
        } else {
            presentation.coordinator.state.presentedBy = self
            state.modalPresented = presentation
        }
    }
}

///Extension providing utility functions for presenting alerts
@MainActor
public extension Coordinator {
    
    static nonisolated var defaultAlertTitle: String {
        Bundle.main.infoDictionary!["CFBundleDisplayName"] as? String ??
        Bundle.main.infoDictionary!["CFBundleName"] as? String ?? ""
    }
    
    private var topCoordinator: any Coordinator {
        state.modalPresented?.coordinator.topCoordinator ?? self
    }
    
    ///Presents an alert with customizable message and actions
    func alert<A: View, M: View>(_ title: String = Self.defaultAlertTitle,
                                 @ViewBuilder _ message: @escaping ()->M,
                                 @ViewBuilder actions: @escaping ()->A) {
        topCoordinator.state.alerts.append(.init(title: title, actions: actions, message: message))
    }
    
    ///Presents an alert with a default "OK" button and custom message
    func alert<M: View>(_ title: String = Self.defaultAlertTitle,
                        @ViewBuilder _ message: @escaping ()->M) {
        topCoordinator.state.alerts.append(.init(title: title,
                                                 actions: { Button("OK") {} },
                                                 message: message))
    }
    
    ///Presents an alert with a message and a default "OK" button
    func alert(_ title: String = Self.defaultAlertTitle, message: String) {
        topCoordinator.state.alerts.append(.init(title: title,
                                                 actions: { Button("OK") {} },
                                                 message: { Text(message) }))
    }
    
    ///Presents an alert with a message and customizable actions
    func alert<A: View>(_ title: String = Self.defaultAlertTitle,
                        message: String,
                        @ViewBuilder actions: @escaping ()->A) {
        topCoordinator.state.alerts.append(.init(title: title,
                                                 actions: actions,
                                                 message: { Text(message) }))
    }
}

///Typealias for a Coordinator that supports both navigation and modal presentations
public typealias NavigationModalCoordinator = NavigationCoordinator & ModalCoordinator

///Extension defining custom CoordinateSpaces for navigation and modal views
public extension CoordinateSpace {
    
    ///Coordinate space for a navigation controller
    static let navController = "CoordinatorSpaceNavigationController"
    
    ///Coordinate space for modal presentations
    static let modal = "CoordinatorSpaceModal"
}











public protocol CustomCoordinator: Coordinator {
    associatedtype DestinationView: View
    
    @MainActor
    func destination() -> DestinationView
}

@MainActor
public extension CustomCoordinator {
    
    var rootView: some View { destination().withModal(self) }
}







public enum ModalStyle {
    
    ///Presents the modal as a sheet, which occupies part of the screen and dims the background
    case sheet
    
    ///Presents the modal as a full-screen cover
    case cover
    
    /// Presents the modal as an overlay on top of the current navigation.
    /// This option is customizable and doesn't interfere with the native navigation controller or modal presentation flow.
    case overlay
}

///Protocol to be conformed by a modal navigation flow
public protocol ModalProtocol: Hashable, Identifiable {
    
    ///The presentation style of the modal flow
    var style: ModalStyle { get }
}

public extension ModalProtocol {
    
    ///Default presentation style for modals is `.sheet`
    var style: ModalStyle { .sheet }
    
    var id: Int { hashValue }
}

extension ModalProtocol {
    
    ///Returns a Coordinator If a modal flow contains one.
    ///It iterates through the properties of the modal flow using reflection.
    var coordinator: (any Coordinator)? {
        for child in Mirror(reflecting: self).children {
            if let value = child.value as? (any Coordinator) {
                return value
            }
        }
        return nil
    }
}

///Protocol for a Coordinator that manages modals
public protocol ModalCoordinator: Coordinator {
    associatedtype Modal: ModalProtocol
    associatedtype ModalView: View
    
    ///A method that returns the destination view for a given modal
    @MainActor @ViewBuilder func destination(for modal: Modal) -> ModalView
}

///Enum to define how to resolve situations where a modal is already presented by this Coordinator
public enum PresentationResolve {
    
    ///Present the new modal on top of the currently presented screen
    case overAll
    
    ///Dismiss the currently presented modal and replace it with the new one
    case replaceCurrent
}

@MainActor
public extension ModalCoordinator {
    
    ///Presents a modal flow over the current navigation using the specified `resolve` strategy
    func present(_ modalFlow: Modal, resolve: PresentationResolve = .overAll) {
        present(.init(modalFlow: modalFlow,
                      destination: { [unowned self] in AnyView(self.destination(for: modalFlow)) }),
                resolve: resolve)
    }
}

///A view modifier that manages the presentation of modal views based on the current navigation state
private struct ModalModifer: ViewModifier {
    
    @ObservedObject var state: NavigationState
    
    ///Creates a binding for checking if a modal of a specific style is currently presented
    func isPresentedBinding(_ style: ModalStyle) -> Binding<Bool> {
        .init { [weak state] in
            state?.modalPresented?.modalFlow.style == style
        } set: { [weak state] _ in
            if let presented = state?.modalPresented,
               let overlayPresented = presented.coordinator.state.modalPresented,
               overlayPresented.modalFlow.style == .overlay {
                presented.coordinator.state.modalPresented = nil
            } else {
                state?.modalPresented = nil
            }
        }
    }
    
    func body(content: Content) -> some View {
        content.overlay {
            if let presented = state.modalPresented, presented.modalFlow.style == .overlay {
                presented.destination()
                    .coordinateSpace(name: CoordinateSpace.modal)
            }
        }.sheet(isPresented: isPresentedBinding(.sheet)) { [weak state] in
            state?.modalPresented!.destination()
                .coordinateSpace(name: CoordinateSpace.modal)
        }.fullScreenCover(isPresented: isPresentedBinding(.cover)) { [weak state] in
            state?.modalPresented!.destination()
                .coordinateSpace(name: CoordinateSpace.modal)
        }.alert(state.alerts.last?.title ?? "",
                isPresented: Binding(get: { state.alerts.last != nil }, set: { _ in
            if state.alerts.count > 0 {
                state.alerts.removeLast()
            }
        } ), actions: state.alerts.last?.actions ?? { AnyView(EmptyView()) },
                message: state.alerts.last?.message ?? { AnyView(EmptyView()) })
    }
}

public extension View {
    
    ///Extends the current view to support modal presentation via a specified `Coordinator`
    func withModal<C: Coordinator>(_ coordinator: C) -> some View {
        modifier(ModalModifer(state: coordinator.state)).environmentObject(coordinator.weakReference)
    }
}




///Protocol for conforming by a screen identifier in horizontal navigation flow
public protocol ScreenProtocol: Hashable { }

///Protocol that defines navigation-specific behavior
public protocol NavigationCoordinator: Coordinator {
    associatedtype Screen: ScreenProtocol
    associatedtype ScreenView: View
    
    ///A method that returns the destination view for a given screen identifier
    @MainActor @ViewBuilder func destination(for screen: Screen) -> ScreenView
}

@MainActor
public extension NavigationCoordinator {
    
    ///Navigate to a new screen in current navigation stack
    func present(_ screen: Screen) {
        state.path.append(screen)
    }
    
    ///Move back in the navigation stack to the first screen that meets the specified condition, returns True if the screen has been found
    @discardableResult
    func popTo(where condition: (Screen) -> Bool) -> Bool {
        if let index = state.path.firstIndex(where: {
            if let screen = $0 as? Screen {
                return condition(screen)
            }
            return false
        }) {
            state.path.removeLast(state.path.count - index - 1)
            return true
        }
        return false
    }
    
    ///Move back in the navigation stack to a specific screen, returns True if the screen has been found
    @discardableResult
    func popTo(_ element: Screen) -> Bool {
        popTo(where: { $0 == element })
    }
}

@available(iOS 16.0, *)
public extension View {
    
    ///Extend the view with navigation capabilities using the specified Coordinator
    func withNavigation<C: NavigationCoordinator>(_ coordinator: C) -> some View {
        modifier(NavigationModifer(coordinator: coordinator))
    }
}

@available(iOS 16.0, *)
@MainActor
public extension NavigationCoordinator {
    
    /// Creates a view for the given screen identifier and applies both navigation and modal capabilities
    func view(for screen: Screen) -> some View {
        destination(for: screen).withNavigation(self).withModal(self)
    }
}

///A `ViewModifier` that adds navigation functionality to views managed by a `NavigationCoordinator`
@available(iOS 16.0, *)
private struct NavigationModifer<Coordinator: NavigationCoordinator>: ViewModifier {
    
    let coordinator: Coordinator
    @ObservedObject var state: NavigationState
    
    init(coordinator: Coordinator) {
        self.coordinator = coordinator
        self.state = coordinator.state
    }
    
    public func body(content: Content) -> some View {
        NavigationStack(path: $state.path) { [weak coordinator] in
            content.navigationDestination(for: AnyHashable.self) {
                if let screen = $0 as? Coordinator.Screen {
                    coordinator?.destination(for: screen)
                }
            }
        }.coordinateSpace(name: CoordinateSpace.navController)
    }
}



import Combine

///Structure that represents the current modal presentation in the navigation flow.
///It holds the modal flow and the associated parent coordinator.
public struct ModalPresentation {
    
    ///A placeholder coordinator used when no coordinator is provided for the modal flow.
    private final class PlaceholderCoordinator: Coordinator { }
    
    ///The modal flow that this presentation is handling.
    public let modalFlow: any ModalProtocol
    
    ///The parent coordinator responsible for managing the modal flow.
    let coordinator: any Coordinator
    
    ///A closure that returns the view to be displayed for the modal.
    let destination: ()->AnyView
    
    init(modalFlow: any ModalProtocol, destination: @escaping () -> AnyView) {
        self.modalFlow = modalFlow
        
        if let coordinator = modalFlow.coordinator {
            self.destination = destination
            self.coordinator = coordinator
        } else {
            let coordinator = PlaceholderCoordinator()
            self.destination = { [unowned coordinator] in AnyView(destination().withModal(coordinator)) }
            self.coordinator = coordinator
        }
    }
}

///Class that manages the navigation state for the coordinator.
///It stores the current navigation path, presented modal flows, and any alerts.
public final class NavigationState: ObservableObject {
    
    ///The current navigation path, which is a list of screen identifiers in the navigation stack.
    @Published public var path: [AnyHashable] = []
    
    ///The modal flow that is presented over the current navigation.
    @Published public internal(set) var modalPresented: ModalPresentation?
    
    struct Alert {
        let title: String
        let actions: ()->AnyView
        let message: ()->AnyView
        
        init<A: View, M: View>(title: String, actions: @escaping ()->A, message: @escaping ()->M) {
            self.title = title
            self.actions = { AnyView(actions()) }
            self.message = { AnyView(message()) }
        }
    }
    
    ///A list of currently presented alerts.
    @Published var alerts: [Alert] = []
    
    ///A weak reference to the parent coordinator that presented the current navigation modally, if any.
    public internal(set) weak var presentedBy: (any Coordinator)?
    
    private var observers: [AnyCancellable] = []
    
    public init() {
        $path.sink { [weak self] _ in
            self?.closeKeyboard()
        }.store(in: &observers)
        
        $modalPresented.sink { [weak self] _ in
            self?.closeKeyboard()
        }.store(in: &observers)
    }
    
    ///Helper method to close the keyboard when navigation or modal state changes.
    private func closeKeyboard() {
        UIApplication.shared.resignFirstResponder()
    }
}
