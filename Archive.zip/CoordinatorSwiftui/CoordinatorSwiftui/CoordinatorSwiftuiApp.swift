//
//  CoordinatorSwiftuiApp.swift
//  CoordinatorSwiftui
//
//  Created by Akash on 11/11/24.
//

import SwiftUI

@main
struct CoordinatorSwiftuiApp: App {
    
    @StateObject var coordinator = CommonCoordinator()

    
    var body: some Scene {
        WindowGroup {
            coordinator.view(for: .first)
        }
    }
}
