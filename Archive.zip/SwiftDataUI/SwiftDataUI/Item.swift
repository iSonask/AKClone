//
//  Item.swift
//  SwiftDataUI
//
//  Created by Akash on 29/07/24.
//

import Foundation
import SwiftData

@Model
final class Item {
    
    var name: String
    init(name: String) {
        
        self.name = name
    }
}
