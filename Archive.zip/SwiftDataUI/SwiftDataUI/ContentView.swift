//
//  ContentView.swift
//  SwiftDataUI
//
//  Created by Akash on 29/07/24.
//

import SwiftUI
import SwiftData

struct ContentView: View {
    @Environment(\.modelContext) private var modelContext
    @Query private var items: [Item]

    @State private var showingUpdateAlert = false
    @State private var itemToUpdate: Item?
    @State private var newName: String = ""

    var body: some View {
        NavigationView {
            List {
                ForEach(items) { item in
                    HStack {
                        Text("Item at \(item.name)")
                        Spacer()
                        Button(action: {
                            itemToUpdate = item
                            showingUpdateAlert = true
                        }) {
                            Text("Update")
                                .foregroundColor(.blue)
                        }
                    }
                }
                .onDelete(perform: deleteItems)
            }
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    EditButton()
                }
                ToolbarItem {
                    Button(action: addItem) {
                        Label("Add Item", systemImage: "plus")
                    }
                }
            }
            .alert("Update Item", isPresented: $showingUpdateAlert, actions: {
                TextField("New Name", text: $newName)
                Button("Cancel", role: .cancel) {}
                Button("Update", action: {
                    if let item = itemToUpdate {
                        updateItem(item)
                    }
                })
            }, message: {
                Text("Enter a new name for the item.")
            })
        }
    }

    private func addItem() {
        let newItem = Item(name: "New Item")
        modelContext.insert(newItem)
        do {
            try modelContext.save()
        } catch {
            // Handle the error appropriately in a real application.
            print("Failed to save item: \(error.localizedDescription)")
        }
    }

    private func deleteItems(offsets: IndexSet) {
        for index in offsets {
            modelContext.delete(items[index])
        }
        do {
            try modelContext.save()
        } catch {
            // Handle the error appropriately in a real application.
            print("Failed to delete item: \(error.localizedDescription)")
        }
    }

    private func updateItem(_ item: Item) {
        item.name = newName
        do {
            try modelContext.save()
        } catch {
            // Handle the error appropriately in a real application.
            print("Failed to update item: \(error.localizedDescription)")
        }
    }
}

private let itemFormatter: DateFormatter = {
    let formatter = DateFormatter()
    formatter.dateStyle = .short
    formatter.timeStyle = .medium
    return formatter
}()


#Preview {
    ContentView()
        .modelContainer(for: Item.self, inMemory: true)
}
