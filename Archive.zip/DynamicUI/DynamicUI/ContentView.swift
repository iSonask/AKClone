//
//  ContentView.swift
//  DynamicUI
//
//  Created by Akash on 28/10/24.
//

import SwiftUI

struct ContentView: View {
    let countries = ["Afghanistan", "Albania", "Algeria", "Angola", "Argentia", "Armenia", "Australia", "Austria"]

    // A dynamic string to capture and reflect user input in the search bar
    @State private var searchString = ""

    // The main view, housing the navigation and list structure
    var body: some View {
        NavigationView {
            List {
                // A conditional rendering based on user input, ensuring a responsive and intuitive search experience
                ForEach(searchString.isEmpty ? countries : countries.filter { $0.contains(searchString)}, id: \.self) { country in
                    Text(country)
                }
                .navigationTitle("Countries")
            }
            // Incorporating the searchable modifier to facilitate search functionality and bind it to the user input
            .searchable(text: $searchString)
        }
    }
}

#Preview {
    ContentView()
}
