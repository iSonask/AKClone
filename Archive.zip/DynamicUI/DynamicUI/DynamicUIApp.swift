//
//  DynamicUIApp.swift
//  DynamicUI
//
//  Created by Akash on 28/10/24.
//

import SwiftUI

@main
struct DynamicUIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
