//
//  ViewController.swift
//  DocumentScanner
//
//  Created by Akash on 25/10/24.
//

import UIKit
import VisionKit

class ViewController: UIViewController,DocumentScannerDelegate {
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationItem.rightBarButtonItem = UIBarButtonItem(barButtonSystemItem: .add, target: self, action: #selector(openDocumentScanner))
    }
    
    @objc func openDocumentScanner() {
        let scannerVC = DocumentScannerViewController()
        scannerVC.delegate = self
        present(scannerVC, animated: true, completion: nil)
    }
    
    func didCaptureDocuments(_ images: [UIImage]) {
        for image in images {
            // Process the scanned images, display or save them as needed
            print("Scanned document: \(image)")
        }
    }
    
    func didFailWithError(_ error: Error) {
        print("Failed to scan document: \(error.localizedDescription)")
    }


}

import UIKit

protocol DocumentScannerDelegate: AnyObject {
    func didCaptureDocuments(_ images: [UIImage])
    func didFailWithError(_ error: Error)
}
import UIKit

class DocumentDetectionOverlayView: UIView {
    
    private var path = UIBezierPath()
    
    func updateOverlay(with corners: [CGPoint]) {
        path = UIBezierPath()
        path.move(to: corners[0])
        
        for corner in corners.dropFirst() {
            path.addLine(to: corner)
        }
        path.close()
        
        setNeedsDisplay()
    }
    
    override func draw(_ rect: CGRect) {
        UIColor.green.setStroke()
        path.lineWidth = 2.0
        path.stroke()
    }
    
    func clearOverlay() {
        path = UIBezierPath()
        setNeedsDisplay()
    }
}
import UIKit
import AVFoundation
import Vision

class DocumentScannerViewController: UIViewController, AVCaptureVideoDataOutputSampleBufferDelegate {
    
    weak var delegate: DocumentScannerDelegate?
    private var captureSession: AVCaptureSession!
    private var previewLayer: AVCaptureVideoPreviewLayer!
    private var documentOverlay = DocumentDetectionOverlayView()
    private var isTorchOn = false
    private var isAutoCaptureEnabled = true
    private var capturedImages: [UIImage] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupCamera()
        setupUI()
    }
    
    private func setupCamera() {
        captureSession = AVCaptureSession()
        captureSession.sessionPreset = .photo
        
        guard let backCamera = AVCaptureDevice.default(for: .video) else {
            delegate?.didFailWithError(NSError(domain: "Camera not available", code: -1, userInfo: nil))
            return
        }
        
        do {
            let input = try AVCaptureDeviceInput(device: backCamera)
            captureSession.addInput(input)
            
            let output = AVCaptureVideoDataOutput()
            output.setSampleBufferDelegate(self, queue: DispatchQueue(label: "videoQueue"))
            captureSession.addOutput(output)
            
            previewLayer = AVCaptureVideoPreviewLayer(session: captureSession)
            previewLayer.videoGravity = .resizeAspectFill
            previewLayer.frame = view.bounds
            view.layer.addSublayer(previewLayer)
            
            captureSession.startRunning()
        } catch {
            delegate?.didFailWithError(error)
        }
    }
    
    private func setupUI() {
        // Add document overlay
        documentOverlay.frame = view.bounds
        view.addSubview(documentOverlay)
        
        // Torch button
        let torchButton = UIButton(type: .system)
        torchButton.setTitle("Torch", for: .normal)
        torchButton.addTarget(self, action: #selector(toggleTorch), for: .touchUpInside)
        torchButton.frame = CGRect(x: 20, y: view.bounds.height - 80, width: 80, height: 40)
        view.addSubview(torchButton)
        
        // Capture button
        let captureButton = UIButton(type: .system)
        captureButton.setTitle("Capture", for: .normal)
        captureButton.addTarget(self, action: #selector(captureDocument), for: .touchUpInside)
        captureButton.frame = CGRect(x: view.bounds.width - 100, y: view.bounds.height - 80, width: 80, height: 40)
        view.addSubview(captureButton)
    }
    
    @objc private func toggleTorch() {
        guard let device = AVCaptureDevice.default(for: .video), device.hasTorch else { return }
        try? device.lockForConfiguration()
        device.torchMode = isTorchOn ? .off : .on
        isTorchOn.toggle()
        device.unlockForConfiguration()
    }
    
    @objc private func captureDocument() {
        isAutoCaptureEnabled = false
    }
    
    // Process captured image buffer
    func captureOutput(_ output: AVCaptureOutput, didOutput sampleBuffer: CMSampleBuffer, from connection: AVCaptureConnection) {
        guard let pixelBuffer = CMSampleBufferGetImageBuffer(sampleBuffer) else { return }
        
        let request = VNDetectRectanglesRequest { [weak self] request, error in
            if let results = request.results as? [VNRectangleObservation], let strongestResult = results.first {
                DispatchQueue.main.async {
                    self?.drawRectangle(observation: strongestResult)
                    if self?.isAutoCaptureEnabled == true {
                        self?.processRectangle(pixelBuffer: pixelBuffer, observation: strongestResult)
                    }
                }
            } else {
                DispatchQueue.main.async {
                    self?.documentOverlay.clearOverlay()
                }
            }
        }
        request.minimumConfidence = 0.8
        request.minimumAspectRatio = 0.5
        
        let handler = VNImageRequestHandler(cvPixelBuffer: pixelBuffer, orientation: .up, options: [:])
        try? handler.perform([request])
    }
    
    private func drawRectangle(observation: VNRectangleObservation) {
        let corners = [
            observation.topLeft, observation.topRight,
            observation.bottomRight, observation.bottomLeft
        ].map {
            previewLayer.layerPointConverted(fromCaptureDevicePoint: CGPoint(x: $0.x, y: 1 - $0.y))
        }
        documentOverlay.updateOverlay(with: corners)
    }
    
    private func processRectangle(pixelBuffer: CVPixelBuffer, observation: VNRectangleObservation) {
        let ciImage = CIImage(cvPixelBuffer: pixelBuffer)
        let cgImage = CIContext().createCGImage(ciImage, from: ciImage.extent)
        guard let croppedImage = cgImage?.cropping(to: observation.boundingBox) else { return }
        
        let uiImage = UIImage(cgImage: croppedImage)
        capturedImages.append(uiImage)
        
        DispatchQueue.main.async {
            self.delegate?.didCaptureDocuments(self.capturedImages)
            self.dismiss(animated: true, completion: nil)
        }
    }
}
