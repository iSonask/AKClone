//
//  ViewController.swift
//  CombineDemo
//
//  Created by Akash on 16/07/24.
//

import UIKit
import Combine

struct Post: Decodable,Hashable {
    let id: Int
    let title: String
}

class APIService {
    func fetchPosts() -> AnyPublisher<[Post], Error> {
        let url = URL(string: "https://jsonplaceholder.typicode.com/posts")!
        
        return URLSession.shared.dataTaskPublisher(for: url)
            .map { $0.data }
            .decode(type: [Post].self, decoder: JSONDecoder())
            .eraseToAnyPublisher()
    }
}

class LoginViewModel {
    @Published var email: String = ""
    @Published var password: String = ""
    @Published private(set) var isLoginEnabled: Bool = false

    var cancellables = Set<AnyCancellable>()

    init() {
        Publishers.CombineLatest($email, $password)
            .map { email, password in
                return email.contains("@") && password.count >= 6
            }
            .assign(to: \.isLoginEnabled, on: self)
            .store(in: &cancellables)
    }
}


class ViewController: UIViewController {
    private var tableView: UITableView!
//    private var viewModel = ViewModel()
    private var cancellables = Set<AnyCancellable>()
    @IBOutlet weak var firstTF: UITextField!
    @IBOutlet weak var secondTF: UITextField!
    private var dataSource: UITableViewDiffableDataSource<Int, Post>!
    let viewModel = LoginViewModel()
    @IBOutlet weak var loginButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        viewModel.$isLoginEnabled
            .sink { isEnabled in
                print("Login enabled: \(isEnabled)")
            }
            .store(in: &viewModel.cancellables)

        
        firstTF
            .textPublisher
            .assign(to: \.email, on: viewModel)
            .store(in: &cancellables)

        // Bind password text field to the view model's password property
        secondTF
            .textPublisher
            .assign(to: \.password, on: viewModel)
            .store(in: &cancellables)

        // Observe isLoginEnabled to update login button state
        viewModel.$isLoginEnabled
            .receive(on: DispatchQueue.main)
            .sink { [weak self] isEnabled in
                self?.loginButton.isEnabled = isEnabled
                self?.loginButton.alpha = isEnabled ? 1.0 : 0.5
            }
            .store(in: &cancellables)

        
//        setupTableView()
//        setupDataSource()
//        bindViewModel()
//        
//        viewModel.getPosts()
    }
    
    private func setupTableView() {
        tableView = UITableView(frame: view.bounds, style: .plain)
        tableView.register(UINib(nibName: "CustomCell", bundle: nil), forCellReuseIdentifier: "CustomCell")
        view.addSubview(tableView)
    }
    
    private func setupDataSource() {
        dataSource = UITableViewDiffableDataSource(tableView: tableView, cellProvider: { tableView, indexPath, itemIdentifier in
            if let cell = tableView.dequeueReusableCell(withIdentifier: "CustomCell", for: indexPath) as? CustomCell {
                cell.object = itemIdentifier.title
                return cell
            } else {
                return UITableViewCell()
            }
        })
    }
    
    private func bindViewModel() {
//        viewModel.$posts
//            .receive(on: DispatchQueue.main)
//            .sink { [weak self] posts in
//                self?.updateTableView(with: posts)
//            }
//            .store(in: &cancellables)
    }
    
    private func updateTableView(with posts: [Post]) {
        var snapshot = NSDiffableDataSourceSnapshot<Int, Post>()
        snapshot.appendSections([0])
        snapshot.appendItems(posts)
        dataSource.apply(snapshot, animatingDifferences: true)
    }

}


class ViewModel: ObservableObject {
    @Published var posts: [Post] = []
    private var cancellables = Set<AnyCancellable>()
    private let apiService = APIService()
    
    func getPosts() {
        apiService.fetchPosts()
            .receive(on: DispatchQueue.main)
            .sink(receiveCompletion: { completion in
                switch completion {
                case .finished:
                    print("Finished")
                case .failure(let error):
                    print("Error: \(error)")
                }
            }, receiveValue: { [weak self] posts in
                self?.posts = posts
            })
            .store(in: &cancellables)
    }
}

import Combine
import UIKit

extension UITextField {
    var textPublisher: AnyPublisher<String, Never> {
        NotificationCenter.default.publisher(for: UITextField.textDidChangeNotification, object: self)
            .compactMap { ($0.object as? UITextField)?.text }
            .eraseToAnyPublisher()
    }
}
