//
//  ViewController.swift
//  NewClone
//
//  Created by Akash on 26/11/24.
//

import UIKit
import Combine

class ViewController: UIViewController {
    @IBOutlet weak var tableView: UITableView!
    
    private var viewModel = PostsViewModel()
    private var cancellables = Set<AnyCancellable>()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupTableView()
        bindViewModel()
        viewModel.fetchPosts()
    }
    
    private func setupTableView() {
        tableView.dataSource = self
        tableView.delegate = self
        
        // Enable pagination by detecting when the user reaches the bottom
        tableView.prefetchDataSource = self
        
    }
    
    private func bindViewModel() {
        // Bind movies to tableView reload
        viewModel.$posts
            .receive(on: DispatchQueue.main)
            .sink { [weak self] _ in
                self?.tableView.reloadData()
            }
            .store(in: &cancellables)
        
        // Bind error messages
        viewModel.$errorMessage
            .receive(on: DispatchQueue.main)
            .sink { errorMessage in
                
                print("**********")
                print(errorMessage ?? "")
                //                self?.errorLabel.text = errorMessage
                //                self?.errorLabel.isHidden = errorMessage == nil
            }
            .store(in: &cancellables)
        
        viewModel.$isLoading
            .receive(on: DispatchQueue.main)
            .sink { isLoading in
                if isLoading {
                    ActivityIndicatorView.shared.show()
                } else {
                    ActivityIndicatorView.shared.hide()
                }
            }
            .store(in: &cancellables)
        
    }
    
}

extension ViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return viewModel.posts.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if let cell = tableView.dequeueReusableCell(withIdentifier: "PostsCell", for: indexPath) as? PostsCell {
            let movie = viewModel.posts[indexPath.row]
            cell.titleLabel?.text = movie.title
            return cell
        }
        return UITableViewCell()
    }
}

extension ViewController: UITableViewDelegate {
    // Detect when the user reaches the bottom of the table view
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        let threshold = scrollView.contentSize.height - scrollView.frame.height
        if scrollView.contentOffset.y > threshold {
            // If we're close to the bottom, fetch more posts
            if !viewModel.isLoading {
                viewModel.fetchPosts()
            }
        }
    }
}

extension ViewController: UITableViewDataSourcePrefetching {
    // Prefetch data before the user scrolls all the way to the bottom
    func tableView(_ tableView: UITableView, prefetchRowsAt indexPaths: [IndexPath]) {
        for indexPath in indexPaths {
            if indexPath.row == viewModel.posts.count - 1 && !viewModel.isLoading {
                viewModel.fetchPosts() // Fetch more data if near the last row
            }
        }
    }
}

