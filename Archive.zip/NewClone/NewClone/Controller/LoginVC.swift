//
//  LoginVC.swift
//  NewClone
//
//  Created by Akash on 26/11/24.
//

import UIKit
import Combine



class LoginVC: UIViewController {
    private var cancellables = Set<AnyCancellable>()
    @IBOutlet weak var firstTF: UITextField!
    @IBOutlet weak var secondTF: UITextField!
    @IBOutlet weak var loginButton: UIButton!
    let viewModel = LoginViewModel()

    override func viewDidLoad() {
        super.viewDidLoad()
        viewModel.$isLoginEnabled
            .sink { isEnabled in
                print("Login enabled: \(isEnabled)")
            }
            .store(in: &viewModel.cancellables)

        
        firstTF
            .textPublisher
            .assign(to: \.email, on: viewModel)
            .store(in: &cancellables)

        // Bind password text field to the view model's password property
        secondTF
            .textPublisher
            .assign(to: \.password, on: viewModel)
            .store(in: &cancellables)

        // Observe isLoginEnabled to update login button state
        viewModel.$isLoginEnabled
            .receive(on: DispatchQueue.main)
            .sink { [weak self] isEnabled in
                self?.loginButton.isEnabled = isEnabled
                self?.loginButton.alpha = isEnabled ? 1.0 : 0.5
            }
            .store(in: &cancellables)

        
    }
    
    @IBAction func loginButtonAction(_ sender: UIButton) {
        if let vc = storyboard?.instantiateViewController(withIdentifier: "ViewController") as? ViewController {
            navigationController?.pushViewController(vc, animated: true)
        }
    }
    
}

import Combine
import UIKit

extension UITextField {
    var textPublisher: AnyPublisher<String, Never> {
        NotificationCenter.default.publisher(for: UITextField.textDidChangeNotification, object: self)
            .compactMap { ($0.object as? UITextField)?.text }
            .eraseToAnyPublisher()
    }
}
