//
//  PostsViewModel.swift
//  NewClone
//
//  Created by Akash on 26/11/24.
//

import Combine
import UIKit

class PostsViewModel: ObservableObject {
    @Published var posts: [Post] = []
    @Published var errorMessage: String?
    @Published var isLoading: Bool = false
    private var currentPage: Int = 1
    private let pageSize: Int = 20 // Number of posts per page
    private var cancellables = Set<AnyCancellable>()

    func fetchPosts() {
        guard !isLoading else { return } // Prevent multiple simultaneous requests

        self.isLoading = true

        Task {
            do {
                let url = URL(string: "https://jsonplaceholder.typicode.com/posts?_page=\(currentPage)&_limit=\(pageSize)")!
                let fetchedPosts: [Post] = try await APIManager.shared.fetchData(from: url, type: [Post].self)

                DispatchQueue.main.async {
                    // Append new posts to the existing posts array
                    self.posts.append(contentsOf: fetchedPosts)
                    self.currentPage += 1
                    self.isLoading = false
                }
            } catch {
                DispatchQueue.main.async {
                    self.errorMessage = error.localizedDescription
                    self.isLoading = false
                }
            }
        }
    }

//    func uploadImage(_ image: UIImage) {
//        Task {
//            do {
//                let url = URL(string: "https://example.com/upload")! // Replace with your upload endpoint
//                let response = try await APIManager.shared.uploadData(
//                    to: url,
//                    image: image,
//                    fieldName: "file",
//                    fileName: "image.jpg"
//                )
//
//                DispatchQueue.main.async {
//                    self.uploadResponse = response
//                }
//            } catch {
//                DispatchQueue.main.async {
//                    self.errorMessage = error.localizedDescription
//                }
//            }
//        }
//    }
}
