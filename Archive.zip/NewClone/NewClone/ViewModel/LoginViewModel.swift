//
//  LoginViewModel.swift
//  NewClone
//
//  Created by Akash on 26/11/24.
//

import Combine

class LoginViewModel {
    @Published var email: String = ""
    @Published var password: String = ""
    @Published private(set) var isLoginEnabled: Bool = false

    var cancellables = Set<AnyCancellable>()

    init() {
        Publishers.CombineLatest($email, $password)
            .map { email, password in
                return email.contains("@") && password.count >= 6
            }
            .assign(to: \.isLoginEnabled, on: self)
            .store(in: &cancellables)
    }
}
