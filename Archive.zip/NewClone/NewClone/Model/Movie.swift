//
//  Movie.swift
//  NewClone
//
//  Created by Akash on 26/11/24.
//
import Foundation

class Post: Codable {
    let id: Int
    let userId: Int
    let title: String
    let body: String
}
