//
//  RequestRetrier.swift
//  NewClone
//
//  Created by Akash on 26/11/24.
//


import Foundation

final class ReqRetrier: RequestInterceptor {
    private let maxRetryCount: Int

    init(maxRetryCount: Int = 2) {
        self.maxRetryCount = maxRetryCount
    }

    // Determines whether to retry a request
    func retry(
        _ request: Request,
        for session: Session,
        dueTo error: Error,
        completion: @escaping (RetryResult) -> Void
    ) {
        let retryCount = request.retryCount

        if retryCount < maxRetryCount {
            print("Retrying request (\(retryCount + 1)/\(maxRetryCount))...")
            completion(.retryWithDelay(5.0)) // Retry after a delay (e.g., 1 second)
        } else {
            print("Max retries reached. Giving up.")
            completion(.doNotRetry)
        }
    }
}
