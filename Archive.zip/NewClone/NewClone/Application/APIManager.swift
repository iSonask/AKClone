//
//  APIManager.swift
//  NewClone
//
//  Created by Akash on 26/11/24.
//


import Foundation
import UIKit

actor APIManager {
    static let shared = APIManager()

    private let session: Session

    private init() {
        let retrier = ReqRetrier(maxRetryCount: 2)
        session = Session(interceptor: retrier)
    }

    // Fetch data using Alamofire with retry support
    func fetchData<T: Decodable>(from url: URL, type: T.Type) async throws -> T {
        try await withCheckedThrowingContinuation { continuation in
            session.request(url)
                .validate()
                .responseDecodable(of: T.self) { response in
                    switch response.result {
                    case .success(let data):
                        continuation.resume(returning: data)
                    case .failure(let error):
                        continuation.resume(throwing: error)
                    }
                }
        }
    }

    // Upload data using Alamofire with retry support
    func uploadData(
        to url: URL,
        image: UIImage,
        fieldName: String,
        fileName: String
    ) async throws -> String {
        try await withCheckedThrowingContinuation { continuation in
            session.upload(multipartFormData: { formData in
                if let imageData = image.jpegData(compressionQuality: 0.8) {
                    formData.append(imageData, withName: fieldName, fileName: fileName, mimeType: "image/jpeg")
                }
            }, to: url)
            .validate()
            .responseString { response in
                switch response.result {
                    case .success(let successMessage):
                        continuation.resume(returning: successMessage)
                    case .failure(let error):
                        continuation.resume(throwing: error)
                }
            }
        }
    }
}
