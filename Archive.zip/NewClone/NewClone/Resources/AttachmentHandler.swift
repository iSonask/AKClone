//
//  AttachmentHandler.swift
//  NewClone
//
//  Created by Akash on 26/11/24.
//


import UIKit
import Photos
import AVFoundation
import MobileCoreServices
import Combine


/*

// Handling picked image (in imagePickedBlock closure)
AttachmentHandler.shared.imagePickedBlock = { image in
    DispatchQueue.main.async {
        print(image)
//                self.imageView.image = image // Assuming you have an image view to display the image
    }
}

// Handling picked video (in videoPickedBlock closure)
AttachmentHandler.shared.videoPickedBlock = { videoUrl in
    // Play video or do something with the video URL
    print("Video picked: \(videoUrl)")
    // You could load this video into an AVPlayer to play it
}

// Handling picked file (in filePickedBlock closure)
AttachmentHandler.shared.filePickedBlock = { fileUrl in
    // Handle the selected file
    print("File picked: \(fileUrl)")
    // You might want to upload it or store it in a database
}
// Call this function to present the action sheet to pick an attachment
        Task {
            await AttachmentHandler.shared.showAttachmentActionSheet(vc: self)
        }

*/
actor AttachmentHandler: Sendable {
    static let shared = AttachmentHandler()

    private var currentVC: UIViewController?
    
    // Closure for image, video, file picked
    var imagePickedBlock: ((UIImage) -> Void)?
    var videoPickedBlock: ((URL) -> Void)?
    var filePickedBlock: ((URL) -> Void)?

    enum AttachmentType {
        case camera, photoLibrary, video
    }

    // MARK: - Private Constants
    private struct Constants {
        static let actionFileTypeDescription = "Choose a filetype to add..."
        static let camera = "Camera"
        static let phoneLibrary = "Phone Library"
        static let video = "Video"
        static let file = "File"
        static let cancelBtnTitle = "Cancel"
        
        static let alertForPhotoLibraryMessage = "App does not have access to your photos."
        static let alertForCameraAccessMessage = "App does not have access to your camera."
        static let alertForVideoLibraryMessage = "App does not have access to your video."
        
        static let settingsBtnTitle = "Settings"
    }

    // MARK: - Public API to show Attachment Action Sheet
    func showAttachmentActionSheet(vc: UIViewController) async {
        currentVC = vc
        let actionSheet = UIAlertController(title: "Select Attachment", message: Constants.actionFileTypeDescription, preferredStyle: .actionSheet)

        actionSheet.addAction(UIAlertAction(title: Constants.camera, style: .default, handler: { [weak self] _ in
            self?.checkAuthorization(for: .camera)
        }))
        
        actionSheet.addAction(UIAlertAction(title: Constants.phoneLibrary, style: .default, handler: { [weak self] _ in
            self?.checkAuthorization(for: .photoLibrary)
        }))
        
        actionSheet.addAction(UIAlertAction(title: Constants.video, style: .default, handler: { [weak self] _ in
            self?.checkAuthorization(for: .video)
        }))
        
        actionSheet.addAction(UIAlertAction(title: Constants.file, style: .default, handler: { [weak self] _ in
            self?.documentPicker()
        }))
        
        actionSheet.addAction(UIAlertAction(title: Constants.cancelBtnTitle, style: .cancel, handler: nil))

        DispatchQueue.main.async {
            vc.present(actionSheet, animated: true, completion: nil)
        }
    }

    // MARK: - Check Authorization and Proceed
    private func checkAuthorization(for attachmentType: AttachmentType) {
        Task {
            let status = await PHPhotoLibrary.authorizationStatus(for: .readWrite)
            
            switch status {
            case .authorized:
                await self.handlePicker(for: attachmentType)
            case .denied, .restricted:
                await self.presentSettingsAlert(for: attachmentType)
            case .notDetermined:
                await PHPhotoLibrary.requestAuthorization(for: .readWrite) { newStatus in
                    if newStatus == .authorized {
                        Task { await self.handlePicker(for: attachmentType) }
                    } else {
                        Task { await self.presentSettingsAlert(for: attachmentType) }
                    }
                }
            default:
                break
            }
        }
    }

    // MARK: - Handle Picker
    private func handlePicker(for attachmentType: AttachmentType) async {
        switch attachmentType {
        case .camera:
            await openCamera()
        case .photoLibrary:
            await openPhotoLibrary()
        case .video:
            await openVideoLibrary()
        }
    }

    private func openCamera() async {
        guard UIImagePickerController.isSourceTypeAvailable(.camera), let currentVC = currentVC else { return }
        let picker = UIImagePickerController()
        picker.delegate = PickerDelegateHandler.shared
        picker.sourceType = .camera
        
        DispatchQueue.main.async {
            currentVC.present(picker, animated: true, completion: nil)
        }
    }
    
    private func openPhotoLibrary() async {
        guard UIImagePickerController.isSourceTypeAvailable(.photoLibrary), let currentVC = currentVC else { return }
        let picker = UIImagePickerController()
        picker.delegate = PickerDelegateHandler.shared
        picker.sourceType = .photoLibrary
        
        DispatchQueue.main.async {
            currentVC.present(picker, animated: true, completion: nil)
        }
    }
    
    private func openVideoLibrary() async {
        guard UIImagePickerController.isSourceTypeAvailable(.photoLibrary), let currentVC = currentVC else { return }
        let picker = UIImagePickerController()
        picker.delegate = PickerDelegateHandler.shared
        picker.sourceType = .photoLibrary
        picker.mediaTypes = [kUTTypeMovie as String, kUTTypeVideo as String]
        
        DispatchQueue.main.async {
            currentVC.present(picker, animated: true, completion: nil)
        }
    }

    // MARK: - Document Picker
    private func documentPicker() {
        let importMenu = UIDocumentPickerViewController(documentTypes: [String(kUTTypePDF)], in: .import)
        importMenu.delegate = PickerDelegateHandler.shared
        importMenu.modalPresentationStyle = .formSheet
        currentVC?.present(importMenu, animated: true, completion: nil)
    }

    // MARK: - Settings Alert
    private func presentSettingsAlert(for attachmentType: AttachmentType) async {
        var alertTitle = ""
        switch attachmentType {
        case .camera:
            alertTitle = Constants.alertForCameraAccessMessage
        case .photoLibrary:
            alertTitle = Constants.alertForPhotoLibraryMessage
        case .video:
            alertTitle = Constants.alertForVideoLibraryMessage
        }

        let alertController = UIAlertController(title: alertTitle, message: nil, preferredStyle: .alert)
        let settingsAction = UIAlertAction(title: Constants.settingsBtnTitle, style: .destructive) { _ in
            if let url = URL(string: UIApplication.openSettingsURLString) {
                UIApplication.shared.open(url, options: [:], completionHandler: nil)
            }
        }
        let cancelAction = UIAlertAction(title: Constants.cancelBtnTitle, style: .default, handler: nil)
        
        alertController.addAction(cancelAction)
        alertController.addAction(settingsAction)

        DispatchQueue.main.async {
            self.currentVC?.present(alertController, animated: true, completion: nil)
        }
    }
}

// MARK: - Picker Delegate Handler
final class PickerDelegateHandler: NSObject, UIImagePickerControllerDelegate, UINavigationControllerDelegate, UIDocumentPickerDelegate {
    static let shared = PickerDelegateHandler()

    // Image Picker Delegate Methods
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true, completion: nil)
    }

    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        if let image = info[.originalImage] as? UIImage {
            AttachmentHandler.shared.imagePickedBlock?(image)
        } else if let videoUrl = info[.mediaURL] as? URL {
            AttachmentHandler.shared.videoPickedBlock?(videoUrl)
        }
        picker.dismiss(animated: true, completion: nil)
    }

    // Document Picker Delegate Methods
    func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentAt url: URL) {
        AttachmentHandler.shared.filePickedBlock?(url)
    }

    func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) {
        controller.dismiss(animated: true, completion: nil)
    }
}
