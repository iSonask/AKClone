//
//  FormTextField.swift
//  NewClone
//
//  Created by Akash on 26/11/24.
//

import UIKit

// Configuration Structure
struct FormTextFieldConfiguration {
    public let highlightColor: UIColor = UIColor(red: 208.0/255.0, green: 2.0/255.0, blue: 205.0/255.0, alpha: 1.00)
    public let barDefaultColor: UIColor = .darkGray
    public let animationDuration: TimeInterval = 0.2
    public let textFieldHeight: CGFloat = 40.0
    public let textFieldFont: UIFont = UIFont.systemFont(ofSize: 18.0)
    public let minimizedPlaceholderFont: UIFont = UIFont.systemFont(ofSize: 10.0)
}

struct Constant {
    static let defaultBottomLineHeight: CGFloat = 1.0
}


class FormTextField: UITextField {
    
   

    // Configuration Object
    public var configuration: FormTextFieldConfiguration = FormTextFieldConfiguration()

    // Bottom Line
    let bottomLine = UIView()
    var bottomLineHeightConstraint: NSLayoutConstraint?
    
    // Minimized Placeholder
    let minimizedPlaceholderLabel = UILabel()

    private var textFieldActor: TextFieldActor!

    init(configuration: FormTextFieldConfiguration) {
        super.init(frame: .zero)
        self.configuration = configuration
        textFieldActor = TextFieldActor(textField: self, configuration: configuration)
        setupInterface()
    }

    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        textFieldActor = TextFieldActor(textField: self, configuration: configuration)
        setupInterface()
    }
    
    override var intrinsicContentSize: CGSize {
        let superSize = super.intrinsicContentSize
        return CGSize(width: superSize.width, height: configuration.textFieldHeight)
    }

    // MARK: - Interface Setup
    
    private func setupInterface() {
        delegate = self
        font = configuration.textFieldFont
        borderStyle = .none
        
        // Bottom Line Setup
        bottomLine.backgroundColor = configuration.barDefaultColor
        bottomLine.translatesAutoresizingMaskIntoConstraints = false
        addSubview(bottomLine)
        
        bottomLineHeightConstraint = bottomLine.heightAnchor.constraint(equalToConstant: Constant.defaultBottomLineHeight)
        bottomLineHeightConstraint?.isActive = true
        bottomLine.leadingAnchor.constraint(equalTo: leadingAnchor).isActive = true
        bottomLine.trailingAnchor.constraint(equalTo: trailingAnchor).isActive = true
        bottomLine.bottomAnchor.constraint(equalTo: bottomAnchor).isActive = true

        // Placeholder Label Setup
        minimizedPlaceholderLabel.font = configuration.minimizedPlaceholderFont
        minimizedPlaceholderLabel.textColor = configuration.highlightColor
        minimizedPlaceholderLabel.backgroundColor = .clear
        minimizedPlaceholderLabel.translatesAutoresizingMaskIntoConstraints = false
    }
}

// MARK: - TextField Actor Class

class TextFieldActor {
    private weak var textField: FormTextField?
    private var configuration: FormTextFieldConfiguration

    init(textField: FormTextField, configuration: FormTextFieldConfiguration) {
        self.textField = textField
        self.configuration = configuration
    }

    func showMinimizedPlaceholder() {
        guard let textField = textField else { return }
        textField.minimizedPlaceholderLabel.text = textField.placeholder?.uppercased()
        textField.addSubview(textField.minimizedPlaceholderLabel)
        
        let topConstraint = textField.minimizedPlaceholderLabel.topAnchor.constraint(equalTo: textField.topAnchor, constant: 10.0)
        topConstraint.isActive = true
        textField.minimizedPlaceholderLabel.leadingAnchor.constraint(equalTo: textField.leadingAnchor).isActive = true
        textField.minimizedPlaceholderLabel.alpha = 0.3
        
        textField.layoutIfNeeded()
        
        UIView.animate(withDuration: configuration.animationDuration) {
            textField.minimizedPlaceholderLabel.alpha = 1.0
            topConstraint.constant = -5.0
            textField.layoutIfNeeded()
        }
    }

    func hideMinimizedPlaceholder() {
        guard let textField = textField else { return }
        UIView.animate(withDuration: configuration.animationDuration, animations: {
            textField.minimizedPlaceholderLabel.alpha = 0.0
        }) { isFinished in
            if isFinished {
                textField.minimizedPlaceholderLabel.removeFromSuperview()
            }
        }
    }

    func highlightBottomLine() {
        guard let textField = textField else { return }
        UIView.animate(withDuration: configuration.animationDuration) {
            textField.bottomLine.backgroundColor = self.configuration.highlightColor
            textField.bottomLineHeightConstraint?.constant = Constant.defaultBottomLineHeight
            textField.layoutIfNeeded()
        }
    }

    func resetBottomLine() {
        guard let textField = textField else { return }
        UIView.animate(withDuration: configuration.animationDuration) {
            textField.bottomLine.backgroundColor = self.configuration.barDefaultColor
            textField.bottomLineHeightConstraint?.constant = Constant.defaultBottomLineHeight
        }
    }
}

// MARK: - UITextFieldDelegate

extension FormTextField: UITextFieldDelegate {
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        let currentText = textField.text ?? ""
        if currentText.isEmpty {
            textFieldActor.showMinimizedPlaceholder()
        } else if currentText.count == 1 && string.isEmpty {
            textFieldActor.hideMinimizedPlaceholder()
        }
        return true
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        textFieldActor.highlightBottomLine()
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        textFieldActor.resetBottomLine()
    }
    
    func textFieldShouldClear(_ textField: UITextField) -> Bool {
        textFieldActor.hideMinimizedPlaceholder()
        return true
    }
}

// MARK: - Public Methods for Customization

extension FormTextField {
    
    func setRightImage(_ image: UIImage) {
        let imgView = UIImageView(image: image)
        imgView.contentMode = .center
        rightView = imgView
        rightViewMode = .always
        textFieldActor.resetBottomLine()
    }
}
