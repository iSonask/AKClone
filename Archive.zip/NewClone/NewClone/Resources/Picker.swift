//
//  Picker.swift
//  NewClone
//
//  Created by Akash on 26/11/24.
//


/*
 let options = ["Option 1", "Option 2", "Option 3", "Option 4"]

 let pickerVC = PickerViewController(title: "Pick an Option", items: options, allowMultipleSelection: true) { selectedItems in
     print("Selected Items: \(selectedItems)")
 }
 pickerVC.modalPresentationStyle = .overCurrentContext
 pickerVC.modalTransitionStyle = .crossDissolve
 present(pickerVC, animated: true, completion: nil)
 */

import UIKit

class PickerViewController: UIViewController {
    private var items: [String]
    private var allowMultipleSelection: Bool
    private var selectedItems: [String]
    private var completion: ([String]) -> Void

    private let containerView = UIView()
    private let titleLabel = UILabel()
    private let tableView = UITableView()
    private let toolbar = UIToolbar()

    init(title: String, items: [String], allowMultipleSelection: Bool = false, selectedItems: [String] = [], completion: @escaping ([String]) -> Void) {
        self.items = items
        self.allowMultipleSelection = allowMultipleSelection
        self.selectedItems = selectedItems
        self.completion = completion
        super.init(nibName: nil, bundle: nil)

        // Title label setup
        titleLabel.text = title
        titleLabel.textAlignment = .center
        titleLabel.font = UIFont.boldSystemFont(ofSize: 18)
        titleLabel.translatesAutoresizingMaskIntoConstraints = false
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        setupBackground()
        setupContainerView()
        setupTableView()
        setupToolbar()
        layoutUI()
    }

    private func setupBackground() {
        view.backgroundColor = UIColor.black.withAlphaComponent(0.5) // Dimmed background
    }

    private func setupContainerView() {
        containerView.backgroundColor = .white
        containerView.layer.cornerRadius = 12
        containerView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(containerView)
    }

    private func setupTableView() {
        tableView.translatesAutoresizingMaskIntoConstraints = false
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "PickerCell")
        tableView.dataSource = self
        tableView.delegate = self
        containerView.addSubview(tableView)
    }

    private func setupToolbar() {
        toolbar.translatesAutoresizingMaskIntoConstraints = false
        let cancelButton = UIBarButtonItem(title: "Cancel", style: .plain, target: self, action: #selector(cancelTapped))
        let flexibleSpace = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
        let selectButton = UIBarButtonItem(title: "Select", style: .done, target: self, action: #selector(selectTapped))
        toolbar.items = [cancelButton, flexibleSpace, selectButton]
        containerView.addSubview(toolbar)
    }

    private func layoutUI() {
        containerView.addSubview(titleLabel)

        NSLayoutConstraint.activate([
            // Center the container view
            containerView.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            containerView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            containerView.widthAnchor.constraint(equalTo: view.widthAnchor, multiplier: 0.8),
            containerView.heightAnchor.constraint(equalToConstant: 300),

            // Layout for the title label
            titleLabel.topAnchor.constraint(equalTo: containerView.topAnchor, constant: 10),
            titleLabel.leadingAnchor.constraint(equalTo: containerView.leadingAnchor, constant: 10),
            titleLabel.trailingAnchor.constraint(equalTo: containerView.trailingAnchor, constant: -10),
            titleLabel.heightAnchor.constraint(equalToConstant: 40),

            // Layout for the table view
            tableView.topAnchor.constraint(equalTo: titleLabel.bottomAnchor, constant: 10),
            tableView.leadingAnchor.constraint(equalTo: containerView.leadingAnchor),
            tableView.trailingAnchor.constraint(equalTo: containerView.trailingAnchor),
            tableView.bottomAnchor.constraint(equalTo: toolbar.topAnchor),

            // Layout for the toolbar
            toolbar.leadingAnchor.constraint(equalTo: containerView.leadingAnchor),
            toolbar.trailingAnchor.constraint(equalTo: containerView.trailingAnchor),
            toolbar.bottomAnchor.constraint(equalTo: containerView.bottomAnchor),
            toolbar.heightAnchor.constraint(equalToConstant: 44)
        ])
    }

    @objc private func cancelTapped() {
        dismiss(animated: true, completion: nil)
    }

    @objc private func selectTapped() {
        completion(selectedItems)
        dismiss(animated: true, completion: nil)
    }
}

// MARK: - UITableViewDataSource and UITableViewDelegate

extension PickerViewController: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return items.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "PickerCell", for: indexPath)
        let item = items[indexPath.row]

        cell.textLabel?.text = item
        cell.accessoryType = selectedItems.contains(item) ? .checkmark : .none

        return cell
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let selectedItem = items[indexPath.row]

        if allowMultipleSelection {
            if selectedItems.contains(selectedItem) {
                selectedItems.removeAll { $0 == selectedItem }
            } else {
                selectedItems.append(selectedItem)
            }
        } else {
            selectedItems = [selectedItem]
        }

        tableView.reloadData()
    }
}

