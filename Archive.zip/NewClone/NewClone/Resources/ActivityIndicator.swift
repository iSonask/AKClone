//
//  ActivityIndicator.swift
//  NewClone
//
//  Created by Akash on 26/11/24.
//

import UIKit

class ActivityIndicatorView: UIView {
    
    // Singleton instance to manage activity indicator globally
    static let shared = ActivityIndicatorView()
    
    // The actual activity indicator and overlay view
    private var overlayView: UIView!
    private var activityIndicator: UIActivityIndicatorView!

    // Private init to prevent multiple instances
    private override init(frame: CGRect) {
        super.init(frame: frame)
        setupView()
    }

    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setupView()
    }
    
    // Setup the view for the ActivityIndicator
    private func setupView() {
        // Set up the overlay
        overlayView = UIView()
        overlayView.backgroundColor = UIColor.black.withAlphaComponent(0.5)
        overlayView.layer.cornerRadius = 10
        
        // Set up the activity indicator
        activityIndicator = UIActivityIndicatorView(style: .large)
        activityIndicator.color = .white
        activityIndicator.translatesAutoresizingMaskIntoConstraints = false
        
        // Add the overlay and indicator to the main view
        overlayView.addSubview(activityIndicator)
        addSubview(overlayView)
        
        // Constraints for overlayView to cover the screen
        overlayView.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            overlayView.topAnchor.constraint(equalTo: self.topAnchor),
            overlayView.bottomAnchor.constraint(equalTo: self.bottomAnchor),
            overlayView.leftAnchor.constraint(equalTo: self.leftAnchor),
            overlayView.rightAnchor.constraint(equalTo: self.rightAnchor),
            
            // Center activity indicator
            activityIndicator.centerXAnchor.constraint(equalTo: overlayView.centerXAnchor),
            activityIndicator.centerYAnchor.constraint(equalTo: overlayView.centerYAnchor)
        ])
        
        // Initially, hide the view
        overlayView.isHidden = true
    }

    // Show the activity indicator
    func show() {
        DispatchQueue.main.async {
            if let window = UIApplication.shared.windows.first(where: { $0.isKeyWindow }) {
                window.addSubview(self)
                self.frame = window.bounds
                self.overlayView.isHidden = false
                self.activityIndicator.startAnimating()
            }
        }
    }

    // Hide the activity indicator
    func hide() {
        DispatchQueue.main.async {
            self.overlayView.isHidden = true
            self.activityIndicator.stopAnimating()
            self.removeFromSuperview()
        }
    }
}
