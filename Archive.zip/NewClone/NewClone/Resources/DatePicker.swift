//
//  DatePicker.swift
//  NewClone
//
//  Created by Akash on 26/11/24.
//

import UIKit

/*
 DatePicker.presentDatePicker(from: self, completion: { selectedDate in
     print("Selected Date: \(selectedDate)")
 })
 */


class DatePicker {
    static func presentDatePicker(
        from viewController: UIViewController,
        title: String? = "Select Date",
        mode: UIDatePicker.Mode = .date,
        minimumDate: Date? = nil,
        maximumDate: Date? = nil,
        initialDate: Date? = Date(),
        completion: @escaping (Date) -> Void
    ) {
        let alertController = UIAlertController(title: title, message: "\n\n\n\n\n\n", preferredStyle: .alert)

        let datePicker = UIDatePicker()
        datePicker.datePickerMode = mode
        datePicker.minimumDate = minimumDate
        datePicker.maximumDate = maximumDate
        datePicker.date = initialDate ?? Date()
        datePicker.preferredDatePickerStyle = .wheels
        datePicker.translatesAutoresizingMaskIntoConstraints = false

        alertController.view.addSubview(datePicker)
        
        // Constraints for datePicker
        NSLayoutConstraint.activate([
            datePicker.topAnchor.constraint(equalTo: alertController.view.topAnchor, constant: 50),
            datePicker.centerXAnchor.constraint(equalTo: alertController.view.centerXAnchor),
            datePicker.widthAnchor.constraint(equalToConstant: 250),
            datePicker.heightAnchor.constraint(equalToConstant: 150)
        ])

        let selectAction = UIAlertAction(title: "Select", style: .default) { _ in
            completion(datePicker.date)
        }
        
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
        
        alertController.addAction(selectAction)
        alertController.addAction(cancelAction)

        viewController.present(alertController, animated: true, completion: nil)
    }
}
