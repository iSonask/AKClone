//
//  PostsCell.swift
//  NewClone
//
//  Created by Akash on 26/11/24.
//


import UIKit


class PostsCell: UITableViewCell {
    
    @IBOutlet weak var titleLabel: UILabel!
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
}
