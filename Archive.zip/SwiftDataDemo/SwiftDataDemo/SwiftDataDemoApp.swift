//
//  SwiftDataDemoApp.swift
//  SwiftDataDemo
//
//  Created by Akash on 10/10/24.
//

import SwiftUI
import SwiftData

@main
struct SwiftDataDemoApp: App {
    var sharedModelContainer: ModelContainer = {
        let schema = Schema([
            Item.self,Address.self,Students.self,Stream.self
        ])
        let modelConfiguration = ModelConfiguration(schema: schema, isStoredInMemoryOnly: false)

        do {
            return try ModelContainer(for: schema, configurations: [modelConfiguration])
        } catch {
            fatalError("Could not create ModelContainer: \(error)")
        }
    }()

    var body: some Scene {
        WindowGroup {
            ContentView()
        }
        .modelContainer(sharedModelContainer)
    }
}
