//
//  Student.swift
//  SwiftDataDemo
//
//  Created by Akash on 14/10/24.
//

import SwiftUI
import SwiftData


struct Student: View {
    @Environment(\.modelContext) private var modelContext
    @Query private var students: [Students]
    
    @State private var isAddingStudent = false
    @State private var showToast = false  // State for showing toast

    var body: some View {
        VStack {
            // List to display students
            List {
                ForEach(students) { student in
                    NavigationLink(destination: StudentFormView(student: student, isUpdating: true, showToast: $showToast)) {
                        VStack(alignment: .leading) {
                            Text(student.name)
                            Text("Standard: \(student.standard)")
                            Text("Stream: \(student.stream.name)")
                        }
                    }
                    
                }.onDelete(perform: deleteItems)
            }
            .navigationTitle("Students")
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button(action: {
                        isAddingStudent = true
                    }) {
                        Image(systemName: "plus")
                    }
                }
            }
            .sheet(isPresented: $isAddingStudent) {
                StudentFormView(student: Students(name: "", standard: "", stream: Stream.science), isUpdating: false, showToast: $showToast)
            }
            
            // Display toast message when student is added
            if showToast {
                Text("Student added successfully!")
                    .font(.caption)
                    .padding()
                    .background(Color.green.opacity(0.8))
                    .cornerRadius(10)
                    .foregroundColor(.white)
                    .transition(.slide)
                    .onAppear {
                        DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                            showToast = false
                        }
                    }
            }
        }
    }
    
    
    private func deleteItems(offsets: IndexSet) {
        withAnimation {
            for index in offsets {
                modelContext.delete(students[index])
            }
        }
    }
}
