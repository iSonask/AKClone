//
//  StudentFormView.swift
//  SwiftDataDemo
//
//  Created by Akash on 14/10/24.
//


import SwiftUI
import SwiftData

struct StudentFormView: View {
    @Environment(\.modelContext) private var modelContext
    @Environment(\.dismiss) private var dismiss
    
    @State var student: Students
    @State private var selectedStream: Stream = Stream.science // Default stream
    
    var isUpdating: Bool // True if updating a student, otherwise adding a new one
    
    @Binding var showToast: Bool // Pass this binding to trigger a success toast
    
    var body: some View {
        Form {
            TextField("Name", text: $student.name)
            TextField("Standard", text: $student.standard)
            
            Picker("Stream", selection: $selectedStream) {
                ForEach(Stream.allStreams, id: \.id) { stream in
                    Text(stream.name).tag(stream)
                }
            }
            
            Button(action: {
                if isUpdating {
                    // Update the student's stream and save changes
                    student.stream = selectedStream
                    try? modelContext.save()  // Save the updates
                } else {
                    // Add new student
                    let newStudent = Students(name: student.name, standard: student.standard, stream: selectedStream)
                    modelContext.insert(newStudent)  // Insert new student
                    try? modelContext.save()         // Save the new student
                }
                
                // Trigger the toast on successful save
                showToast = true
                
                // Dismiss the sheet after saving
                dismiss()
            }) {
                Text(isUpdating ? "Update Student" : "Add Student")
            }
        }
        .onAppear {
            selectedStream = student.stream
        }
    }
}
