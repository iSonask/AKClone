//
//  NormalInsert.swift
//  SwiftDataDemo
//
//  Created by Akash on 10/10/24.
//
import SwiftUI
import SwiftData

struct NormalInsertView: View {
    
    @Environment(\.modelContext) private var modelContext
    @Query private var addresses: [Address]

    
    var body: some View {
        List {
            ForEach(addresses) { item in
                Text(item.address1)
            }
            .onDelete(perform: deleteItems)
        }
        .navigationTitle("Normal Insert")
        .toolbar {
            ToolbarItem(placement: .navigationBarTrailing) {
                EditButton()
            }
            ToolbarItem {
                Button(action: addItem) {
                    Label("Add Item", systemImage: "plus")
                }
            }
        }
    }

    private func addItem() {
        withAnimation {
            let newItem = Address(id: UUID() , title: String.random(), address1: String.random(length: 50), address2: String.random(length: 10), zip: String.random(length: 5))
            modelContext.insert(newItem)
        }
    }

    private func deleteItems(offsets: IndexSet) {
        withAnimation {
            for index in offsets {
                modelContext.delete(addresses[index])
            }
        }
    }
}

#Preview() {
    NormalInsertView()
}
