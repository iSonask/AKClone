//
//  BatchInsert.swift
//  SwiftDataDemo
//
//  Created by Akash on 10/10/24.
//
import SwiftUI
import SwiftData

struct BatchInsertView: View {
    
    @Environment(\.modelContext) private var modelContext
    @State var addresses: [Address]
    @State var batchSize: Int = 100  // Number of records to fetch in one batch
    @State private var currentOffset: Int = 0
    @State private var isLoading: Bool = false
    @State private var allDataLoaded: Bool = false

    
    var body: some View {
            List {
                ForEach(addresses) { item in
                    Text(item.address1)
                        .onAppear {                                            // Check if the current item is the last one in the list
                            if addresses.last == item {
                                loadMoreItems()
                            }
                        }
                }
                .onDelete(perform: deleteItems)
            }
            .onAppear() {
                loadMoreItems()
            }
            .navigationTitle("Batch Insert")
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    EditButton()
                }
                ToolbarItem {
                    Button(action: addItem) {
                        Image(systemName: "plus.circle")
                    }
                }
                ToolbarItem {
                    Button(action: insertMultipleRecordsInBatches) {
                        Label("Add Item", systemImage: "plus.circle.fill")
                            .tint(Color.red)
                    }
                }
                ToolbarItem {
                    Button(action: deleteAllItems) {
                        Image(systemName: "trash.fill")
                    }
                }
            }
        
    }

    private func loadMoreItems() {
        // If already loading data or all records are loaded, do nothing
        guard !isLoading && !allDataLoaded else { return }
        
        isLoading = true
        
        // Perform the fetch operation for the next batch
        Task {
            let fetchRequest = FetchDescriptor<Address>(
                predicate: nil, sortBy: [SortDescriptor(\Address.id, order: .forward)] // Optional: No filtering based on predicate for now
            )
            
            do {
                // Fetch all items at once (without limit)
                let fetchedItems = try modelContext.fetch(fetchRequest)
                
                // Fetch the next batch manually by slicing the fetched result
                let newItems = Array(fetchedItems.dropFirst(currentOffset).prefix(batchSize))
                
                // If no more items are fetched, mark all data as loaded
                if newItems.isEmpty {
                    allDataLoaded = true
                } else {
                    // Append newly fetched items to the list without duplication
                    addresses.append(contentsOf: newItems)
                    
                    // Update the offset for the next batch
                    currentOffset += newItems.count
                }
            } catch {
                print("Error fetching items: \(error)")
            }
            
            isLoading = false
        }
    }


    private func deleteAllItems() {
        Task {
            let fetchRequest = FetchDescriptor<Address>(
                sortBy: [SortDescriptor(\Address.id, order: .forward)]
            )
            
            do {
                // Fetch all items
                let allItems = try modelContext.fetch(fetchRequest)
                
                // Delete each item
                for item in allItems {
                    modelContext.delete(item)
                }
                
                // Save the changes to persist the deletion
                try modelContext.save()
                
                // Clear the state to refresh the view
                addresses.removeAll()
                allDataLoaded = false
                currentOffset = 0
            } catch {
                print("Error deleting items: \(error)")
            }
        }
    }

    private func addItem() {
        withAnimation {
            let newItem = Address(id: UUID(), title: String.random(), address1: String.random(length: 50), address2: String.random(length: 10), zip: String.random(length: 5))
            modelContext.insert(newItem)
        }
    }
    
    @MainActor
    func insertMultipleRecordsInBatches() {
        let batchSize = 10
        var count = 0
        
        for _ in 1...1_000 {
            let newItem = Address(id: UUID(),title: String.random(length: 5), address1: String.random(length: 10), address2: String.random(length: 10), zip: String.random(length: 5))
            modelContext.insert(newItem)
            
            count += 1
            if count % batchSize == 0 {
                do {
                    try modelContext.save()
//                    modelContext.reset() // Reset context to free up memory
                } catch {
                    print("Failed to save batch: \(error)")
                }
            }
        }
        
        // Save any remaining records
        if modelContext.hasChanges {
            do {
                try modelContext.save()
            } catch {
                print("Failed to save final batch: \(error)")
            }
        }
    }
    
   


    private func deleteItems(offsets: IndexSet) {
        withAnimation {
            for index in offsets {
                modelContext.delete(addresses[index])
            }
        }
    }
}

#Preview() {
    BatchInsertView(addresses: [])
}
