//
//  Insert.swift
//  SwiftDataDemo
//
//  Created by Akash on 10/10/24.
//
import SwiftUI

struct InsertView: View {
    var titleArray = ["Normal Insert","Batch Insert"]
    var body: some View {
            List {
                ForEach(Array(titleArray.enumerated()),id: \.offset) { index, element in
                    NavigationLink {
                        switch element {
                        case "Normal Insert":
                            NormalInsertView()
                        case "Batch Insert":
                            BatchInsertView(addresses: [])
                        default:
                            EmptyView()
                        }
                    } label: {
                        Text("\(element)")
                    }

                    
                }
            }
            .navigationTitle("Insert")
    }
}

#Preview() {
    InsertView()
}
