//
//  Update.swift
//  SwiftDataDemo
//
//  Created by Akash on 10/10/24.
//

import SwiftUI
import SwiftData


struct UpdateView: View {
    @Environment(\.modelContext) private var modelContext
    @Query private var addresses: [Address]
    
    @State private var selectedAddress: Address?
    @State private var showEditSheet: Bool = false
    @State private var refreshToggle: Bool = false
    @State private var searchText: String = ""  // Search text for filtering
    
    var body: some View {
            VStack {
                // Search Bar
                SearchBar(text: $searchText)
                
                // Filtered list of addresses based on search text
                List {
                    ForEach(filteredAddresses) { item in
                        Text(item.address1)
                            .onTapGesture {
                                selectedAddress = item // Set the selected item for editing
                                showEditSheet = true  // Show the edit sheet
                            }
                    }
                    .onDelete(perform: deleteItems)  // Delete items
                }
            }
            .navigationTitle("Update")
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button(action: addItem) {
                        Label("Add Item", systemImage: "plus")
                    }
                }
            }
            .sheet(isPresented: $showEditSheet) {
                if let address = selectedAddress {
                    EditAddressSheet(address: $selectedAddress, showSheet: $showEditSheet, onSave: refreshList)
                }
            }
            .id(refreshToggle)  // Force refresh the list when refreshToggle changes
    }
    
    // Computed property to filter addresses based on the search query
    var filteredAddresses: [Address] {
        if searchText.isEmpty {
            return addresses
        } else {
            return addresses.filter { $0.address1.localizedCaseInsensitiveContains(searchText) || $0.title.localizedCaseInsensitiveContains(searchText) }
        }
    }
    
    private func addItem() {
        withAnimation {
            let newItem = Address(id: UUID(), title: String.random(), address1: String.random(length: 50), address2: String.random(length: 10), zip: String.random(length: 5))
            modelContext.insert(newItem)
            refreshList()  // Refresh after adding a new item
        }
    }
    
    private func deleteItems(at offsets: IndexSet) {
        withAnimation {
            for index in offsets {
                let addressToDelete = filteredAddresses[index]
                modelContext.delete(addressToDelete)
            }
            refreshList()  // Refresh after deleting an item
        }
    }
    
    private func refreshList() {
        refreshToggle.toggle()  // Toggle the value to refresh the list
    }
}

struct EditAddressSheet: View {
    
    @Environment(\.modelContext) private var modelContext
    @Binding var address: Address?
    @Binding var showSheet: Bool
    var onSave: () -> Void  // Callback to refresh the list
    
    var body: some View {
        if let address = address {
            NavigationView {
                Form {
                    TextField("Title", text: Binding(get: { address.title }, set: { address.title = $0 }))
                    TextField("Address 1", text: Binding(get: { address.address1 }, set: { address.address1 = $0 }))
                    TextField("Address 2", text: Binding(get: { address.address2 }, set: { address.address2 = $0 }))
                    TextField("ZIP", text: Binding(get: { address.zip }, set: { address.zip = $0 }))
                }
                .navigationTitle("Edit Address")
                .toolbar {
                    ToolbarItem(placement: .confirmationAction) {
                        Button("Submit") {
                            saveChanges()
                        }
                    }
                    ToolbarItem(placement: .cancellationAction) {
                        Button("Cancel") {
                            showSheet = false
                        }
                    }
                }
            }
        }
    }
    
    private func saveChanges() {
        withAnimation {
            try? modelContext.save() // Save the changes to SwiftData
            showSheet = false // Dismiss the sheet
            onSave()  // Call the onSave closure to refresh the list
        }
    }
}

struct SearchBar: View {
    @Binding var text: String
    
    var body: some View {
        HStack {
            TextField("Search...", text: $text)
                .padding(7)
                .background(Color(.systemGray6))
                .cornerRadius(8)
        }
        .padding(.horizontal)
    }
}


#Preview() {
    UpdateView()
}
