//
//  CRUD.swift
//  SwiftDataDemo
//
//  Created by Akash on 11/10/24.
//
import SwiftUI

struct CRUD: View {
    var titleArray = ["Insert","Update","Delete"]
    var body: some View {
        List {
            ForEach(Array(titleArray.enumerated()),id: \.offset) { index, element in
                NavigationLink {
                    switch element {
                    case "Insert":
                        InsertView()
                    case "Update":
                        UpdateView()
                    case "Delete":
                        DeleteView(addresses: [])
                    default:
                        EmptyView()
                    }
                } label: {
                    Text("\(element)")
                }
            }
        }
        .navigationTitle("CRUD")
    }
    
}
