//
//  Item.swift
//  SwiftDataDemo
//
//  Created by Akash on 10/10/24.
//

import Foundation
import SwiftData

@Model
final class Item {
    var timestamp: Date
    
    init(timestamp: Date) {
        self.timestamp = timestamp
    }
}



@Model
final class Address: Identifiable {
    var id: UUID
    var title: String
    var address1: String
    var address2: String
    var zip: String
    
    init(id: UUID, title: String, address1: String, address2: String, zip: String) {
        self.id = id
        self.title = title
        self.address1 = address1
        self.address2 = address2
        self.zip = zip
    }
}



//@Model
//final class Students: Identifiable {
//    var id: UUID
//    var name: String
//    var address: String
//    var stream: Stream
//    var zip: String
//    
//    init(id: UUID, name: String, address: String, stream: Stream, zip: String) {
//        self.id = id
//        self.name = name
//        self.address = address
//        self.stream = stream
//        self.zip = zip
//    }
//}
//
//
//@Model
//final class Stream: Identifiable {
//    var id: UUID
//    var science: Science
//    var commerce: Commerce
//    var arts: Arts
//    
//    init(id: UUID, science: Science, commerce: Commerce, arts: Arts) {
//        self.id = id
//        self.science = science
//        self.commerce = commerce
//        self.arts = arts
//    }
//}
//
//@Model
//final class Science: Identifiable {
//    var id: UUID
//    var bachelor: String
//    var master: String
//    var phd: String
//    
//    init(id: UUID, bachelor: String, master: String, phd: String) {
//        self.id = id
//        self.bachelor = bachelor
//        self.master = master
//        self.phd = phd
//    }
//}
//
//@Model
//final class Commerce: Identifiable {
//    var id: UUID
//    var bachelor: String
//    var master: String
//    var phd: String
//    
//    init(id: UUID, bachelor: String, master: String, phd: String) {
//        self.id = id
//        self.bachelor = bachelor
//        self.master = master
//        self.phd = phd
//    }
//}
//
//@Model
//final class Arts: Identifiable {
//    var id: UUID
//    var bachelor: String
//    var master: String
//    var phd: String
//    
//    init(id: UUID, bachelor: String, master: String, phd: String) {
//        self.id = id
//        self.bachelor = bachelor
//        self.master = master
//        self.phd = phd
//    }
//}

import SwiftData


@Model
final class Students: Identifiable {
    var id: UUID
    var name: String
    var standard: String
    var stream: Stream

    init(name: String, standard: String, stream: Stream) {
        self.id = UUID()
        self.name = name
        self.standard = standard
        self.stream = stream
    }
}

@Model
final class Stream: Identifiable {
    var id: UUID
    var name: String
    static var science = Stream(name: "Science")
    static var arts = Stream(name: "Arts")
    static var commerce = Stream(name: "Commerce")
    static var allStreams: [Stream] = [science, arts, commerce]

    init(name: String) {
        self.id = UUID()
        self.name = name
    }
}
