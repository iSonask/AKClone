//
//  CustomButton.swift
//  demoSwiftui
//
//  Created by Akash on 16/05/24.
//

import Foundation
import SwiftUI

struct CustomButton: View {
    
    let label: String
    let action: () -> Void
    let height: CGFloat
    
    var body: some View {
        Button(action: action) {
            Text(label)
                .padding(8)
                .foregroundColor(.white)
                .background(Color.blue)
                .cornerRadius(10)
        }
        .frame(height: height)
        .padding()
        .font(.custom("Helvetica-Bold", size: 18)) // Custom font and size
    }
}
