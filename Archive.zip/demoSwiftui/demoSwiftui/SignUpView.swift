//
//  SignUpView.swift
//  demoSwiftui
//
//  Created by Akash on 17/05/24.
//

import SwiftUI

struct SignUpView: View {
    @ObservedObject var viewModel = SignInViewModel()
    
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack {
                    
                    CustomTextField(text: $viewModel.name, placeholder: "Name", height: 50)
                        .padding(10)
                    CustomTextField(text: $viewModel.email, placeholder: "Email", height: 50)
                        .padding(10)
                    CountryPickerTextField(selectedCountry: $viewModel.country, placeholder: "Country", height: 50)
                        .padding(10)
                    CustomTextField(text: $viewModel.number, placeholder: "Number", height: 50)
                        .padding(10)
                    CustomTextField(text: $viewModel.password, placeholder: "Password", height: 50)
                        .padding(10)
                    
                    HStack {
                        NavigationLink(destination:
                                        HomeView()
                        ) {
                            Text("SIGN UP")
                                .padding()
                        }.disabled(viewModel.email.isEmpty ? true : viewModel.password.isEmpty ? true : false)
                    }
                }
                .padding()
            }.navigationTitle("Sign Up")
                .background(Color.green.scaledToFill().opacity(0.5).ignoresSafeArea())
        }
    }
}

#Preview {
    SignUpView()
}


struct DetailView: View {
    var body: some View {
        Text("DETAILS")
    }
}
