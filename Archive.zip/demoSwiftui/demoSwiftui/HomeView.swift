//
//  HomeView.swift
//  demoSwiftui
//
//  Created by Akash on 17/05/24.
//

import SwiftUI
import Combine

struct User: Identifiable, Codable {
    let id: Int
    let firstName: String
    let lastName: String
    let avatar: String
    
    enum CodingKeys: String, CodingKey {
        case id
        case firstName = "first_name"
        case lastName = "last_name"
        case avatar
    }
}

struct UsersResponse: Codable {
    let data: [User]
}

class HomeViewModel: ObservableObject {
    @Published var users: [User] = []
    private var cancellable: AnyCancellable?

    init() {
        fetchUsers()
    }

    func fetchUsers() {
        guard let url = URL(string: "https://reqres.in/api/users?page=1") else { return }

        cancellable = URLSession.shared.dataTaskPublisher(for: url)
            .map { $0.data }
            .decode(type: UsersResponse.self, decoder: JSONDecoder())
            .map { $0.data }
            .replaceError(with: [])
            .receive(on: DispatchQueue.main)
            .assign(to: \.users, on: self)
    }
}


struct HomeView: View {
    
//    var viewModel = SignInViewModel()
//    
//    init(model: SignInViewModel) {
//        self.viewModel = model
//    }
//
//    var body: some View {
//        Text("Hello, World!\n\(viewModel.email)\n\(viewModel.name)\n\(viewModel.country)\n\(viewModel.number)")
//    }
    @StateObject private var viewModel = HomeViewModel()

    var body: some View {
        NavigationView {
            List(viewModel.users) { user in
                HStack {
                    AsyncImage(url: URL(string: user.avatar)) { image in
                        image.resizable()
                             .aspectRatio(contentMode: .fill)
                             .frame(width: 50, height: 50)
                             .clipShape(Circle())
                    } placeholder: {
                        ProgressView()
                    }

                    VStack(alignment: .leading) {
                        Text("\(user.firstName) \(user.lastName)")
                            .font(.headline)
                    }
                }
            }
            .navigationTitle("Users")
        }
    }

}

#Preview {
    HomeView()
}
