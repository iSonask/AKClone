//
//  CustomTextField.swift
//  demoSwiftui
//
//  Created by Akash on 16/05/24.
//

import Foundation
import SwiftUI

struct CustomTextField: View {
    
    @Binding var text: String
    let placeholder: String
    let height: CGFloat

    var body: some View {
        TextField(placeholder, text: $text)
            .padding()
            .frame(height: height)
            .font(.custom("Arial", size: 16)) // Custom font and size
            .overlay(
                RoundedRectangle(cornerRadius: 8)
                    .stroke(Color.gray, lineWidth: 1) // Optional: Add border for visualization
            )
    }
}

struct Country: Identifiable,Hashable {
    let id = UUID()
    let name: String
}

let countries = [
    Country(name: "United States"),
    Country(name: "Canada"),
    Country(name: "Mexico"),
    // Add more countries as needed
]

struct CountryPickerTextField: View {
    @Binding var selectedCountry: Country?
    let placeholder: String
    let height: CGFloat
    @State private var isPickerPresented = false
    

    var body: some View {
        VStack {
            TextField(placeholder, text: Binding(
                get: { selectedCountry?.name ?? "" },
                set: { _ in }
            ))
            .padding()
            .frame(height: height)
            .font(.custom("Arial", size: 16))
            .overlay(
                RoundedRectangle(cornerRadius: 8)
                    .stroke(Color.gray, lineWidth: 1)
            )
            .onTapGesture {
                isPickerPresented.toggle()
            }
            .disabled(true) // Prevent manual editing

            if isPickerPresented {
                Picker("Select a Country", selection: $selectedCountry) {
                    ForEach(countries) { country in
                        Text(country.name).tag(country as Country?)
                    }
                }
                .pickerStyle(WheelPickerStyle()) // Customize as needed
                .padding()
                .onTapGesture {
                    isPickerPresented.toggle()
                }
            }
        }
    }
}
