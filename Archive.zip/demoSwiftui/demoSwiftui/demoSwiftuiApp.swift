//
//  demoSwiftuiApp.swift
//  demoSwiftui
//
//  Created by Akash on 16/05/24.
//

import SwiftUI

@main
struct demoSwiftuiApp: App {
    
    var userModel = SignInViewModel()
    
    var body: some Scene {
        WindowGroup {
            if userModel.email.isEmpty {
                ContentView()
            } else {
                HomeView()
            }
        }
    }
}
