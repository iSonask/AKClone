//
//  ContentView.swift
//  demoSwiftui
//
//  Created by Akash on 16/05/24.
//

import SwiftUI

class SignInViewModel: ObservableObject{
    @AppStorage("email") var email = ""
    @Published var password = ""
    @AppStorage("name") var name = ""
    @AppStorage("number") var number = ""
//    @AppStorage("country") var country = ""
    @Published var country: Country? = countries.first

}


struct ContentView: View {
    @ObservedObject var viewModel = SignInViewModel()
    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack {
                    CustomTextField(text: $viewModel.email, placeholder: "Email", height: 50)
                        .padding(10)
                    CustomTextField(text: $viewModel.password, placeholder: "Password", height: 50)
                        .padding(10)
                    HStack {
                        NavigationLink(destination:
                                        HomeView()
                        ) {
                            Text("LOGIN")
                                .padding()
                        }.disabled(viewModel.email.isEmpty ? true : viewModel.password.isEmpty ? true : false)
                            .padding()
                        NavigationLink(destination:
                                        SignUpView()
                        ) {
                            Text("SIGNUP")
                                .padding()
                        }.padding()
                    }
                }.padding()
                .padding(.top,100)
            }
                .background(Color.green.scaledToFill().opacity(0.5).ignoresSafeArea())
        }
    }
}



//struct ContentView: View {
//    @State private var isShowingDetail = false
//
//    var body: some View {
//        NavigationView {
//            ScrollView {
//                    VStack(spacing: 10) {
//                        ForEach(1...10, id: \.self) { index in
//                            HStack(alignment: .top) {
//                                Image(systemName: "applelogo")
//                                    .frame(width: 40, height: 40)
//                                    .foregroundColor(.black)
//                                    .background(Color.red)
//                                    .padding(.trailing, 0) // Add padding to the image
//                                    .clipShape(Circle())
//                                VStack {
//                                    Text("Your Content Here \(index)")
//                                        .padding(.vertical, 0) // Add vertical padding to the text
//                                        .frame(maxWidth: .infinity, alignment: .leading) // Expand text to fill width
//                                    Text("\(index)")
//                                        .padding(.vertical,0)
//                                        .foregroundColor(.gray)
//                                        .frame(maxWidth: .infinity, alignment: .leading)
//                                }
//                                Text("29/05/2024")
//                                    .foregroundColor(.gray)
//                                    .font(.custom("Arial", size: 12))
//                                
//                            }
//                            .padding(.horizontal,10) // Add horizontal padding to the HStack
//                            .cornerRadius(10) // Optional: Add corner radius to each row
//                            Divider()
//                        }
//                    }
////                    .padding(.horizontal, 10) // Add horizontal padding to the VStack
////                    .padding(.top, 10) // Add top padding to the VStack
//                }
//            .ignoresSafeArea(.keyboard)
//            .navigationBarTitle("Home")
//            .navigationBarTitleDisplayMode(.inline)
//            .navigationBarItems(
//                trailing:
//                    HStack {
//                        NavigationLink(
//                            destination: DetailView(),
//                            isActive: $isShowingDetail,
//                            label: {
//                                Image(systemName: "play.fill")
//                                    .imageScale(.large)
//                            }
//                        )
//                        Button(action: {
//                            // Perform action for the first right bar button item
//                            print("First Item Tapped")
//                            DetailView()
//                        }) {
//                            Image(systemName: "gear")
//                                .imageScale(.large)
//                        }
//
//                        NavigationLink(
//                            destination: DetailView(),
//                            isActive: $isShowingDetail,
//                            label: {
//                                Image(systemName: "applelogo")
//                                    .imageScale(.large)
//                                    
//                            }
//                        )
//                    }.foregroundColor(.black)
//            )
//        }
//        
//    }
//}
//
//struct DetailView: View {
//    var body: some View {
//        Text("Detail View")
//            .navigationBarTitle("Detail")
//    }
//}


#Preview {
    ContentView()
}
