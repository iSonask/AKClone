//
//  AppstorageApp.swift
//  Appstorage
//
//  Created by Akash on 13/06/24.
//

import SwiftUI

@main
struct AppstorageApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
