//
//  ContentView.swift
//  Appstorage
//
//  Created by Akash on 13/06/24.
//

import SwiftUI
class UserViewModel: ObservableObject {
    @Published var username: String = "Guest"
}

//struct ContentView: View {
//    @ObservedObject var userViewModel = UserViewModel()
//    
//    var body: some View {
//        VStack {
//            Text("Username: \(userViewModel.username)")
//            Button("Change Username") {
//                userViewModel.username = "User123"
//            }
//        }
//    }
//}




//struct ContentView: View {
//        
//    var body: some View {
//            NavigationView {
//                NavigationLink(destination: DetailView()) {
//                    Text("Go to Detail View")
//                        .padding()
//                        .background(Color.blue)
//                        .foregroundColor(.white)
//                        .cornerRadius(8)
//                }
//                .navigationTitle("Home")
//            }
//        }
//}


//struct ContentView: View {
//    let fruits = ["Apple", "Banana", "Cherry"]
//    
//    var body: some View {
//        List(fruits, id: \.self) { fruit in
//            Text(fruit)
//        }
//    }
//}


struct ContentView: View {
    @State private var isVisible: Bool = false
    
    var body: some View {
        VStack {
            if isVisible {
                Text("Hello, Animation!")
                    .transition(.slide)
            }
            Button("Toggle") {
                withAnimation {
                    isVisible.toggle()
                }
            }
        }
    }
}

#Preview {
    ContentView()
}

struct DetailView: View {
    var body: some View {
        Text("This is the Detail View")
            .font(.largeTitle)
            .padding()
    }
}
