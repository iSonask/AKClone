//
//  Coordinator.swift
//  MVVMDemo
//
//  
//

import Foundation
import UIKit

protocol Coordinator {
    var navigationController: UINavigationController { get set }
    func start()
}
