//
//  ViewController.swift
//  ExpandCollapse
//
//  Created by Akash on 11/10/24.
//

import UIKit

class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource,CustomTableViewCellDelegate {

    var expandedCells: Set<IndexPath> = []
    
    @IBOutlet weak var tableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.register(UINib(nibName: "ExpandCell", bundle: nil), forCellReuseIdentifier: "ExpandCell")
    }
    
    // MARK: - Table view data source

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 10 // Number of rows in the table
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "ExpandCell", for: indexPath) as? ExpandCell else {
            return UITableViewCell()
        }

        // Configure the cell based on whether it is expanded or not
        let isExpanded = expandedCells.contains(indexPath)
        cell.configure(isExpanded: !isExpanded)
        
        cell.delegate = self // Set the delegate to handle button tap
        return cell
    }
    
    // Handle button tap via delegate
    func didTapRadioButton(in cell: ExpandCell) {
        // Find the indexPath of the cell where the button was tapped
        guard let indexPath = tableView.indexPath(for: cell) else { return }
        
        if cell.isExpanded {
            // If the cell is expanded, add it to the set
            expandedCells.insert(indexPath)
        } else {
            // If collapsed, remove from the set
            expandedCells.remove(indexPath)
        }
//        cell.configure(isExpanded: cell.isExpanded)
        // Animate the height change
        UIView.animate(withDuration: 0.3) {
            self.tableView.beginUpdates()
            self.tableView.endUpdates()
        }
    }

    // MARK: - Table view delegate

    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        // Return dynamic height based on expansion state
        return expandedCells.contains(indexPath) ? UITableView.automaticDimension : 82
    }

    func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
        return 82
    }



}

