//
//  ExpandCell.swift
//  ExpandCollapse
//
//  Created by Akash on 11/10/24.
//

import UIKit

protocol CustomTableViewCellDelegate: AnyObject {
    func didTapRadioButton(in cell: ExpandCell)
}

class ExpandCell: UITableViewCell {
    @IBOutlet weak var titleLabel: UILabel!
    
    @IBOutlet weak var yesButton: UIButton!
    @IBOutlet weak var noButton: UIButton!
    @IBOutlet weak var customView: UIView!
    
    var isExpanded: Bool = false

    weak var delegate: CustomTableViewCellDelegate?

    override func awakeFromNib() {
        super.awakeFromNib()
        yesButton.setImage(UIImage(systemName: "circle"), for: .normal)
        yesButton.setImage(UIImage(systemName: "circle.fill"), for: .selected)
        
        noButton.setImage(UIImage(systemName: "circle"), for: .normal)
        noButton.setImage(UIImage(systemName: "circle.fill"), for: .selected)
        
//        customView.isHidden = true
        
    }
    @IBAction func yesButtonAction(_ sender: UIButton) {
        yesButton.isSelected = true
        noButton.isSelected = false
        isExpanded = true
        delegate?.didTapRadioButton(in: self)
        
        self.customView.isHidden = true
        
    }
    
    @IBAction func noButtonAction(_ sender: UIButton) {
        yesButton.isSelected = false
        noButton.isSelected = true
        isExpanded = false
        delegate?.didTapRadioButton(in: self)
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.4){
            self.customView.isHidden = false
        }
        
    }
   
    func configure(isExpanded: Bool) {
        self.isExpanded = isExpanded
    }


    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
