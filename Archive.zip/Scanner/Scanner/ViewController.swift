//
//  ViewController.swift
//  Scanner
//
//  Created by Akash on 24/10/24.
//

import UIKit
import AVFoundation

class ViewController: UIViewController {
    
    var images = [UIImage]()
    @IBOutlet weak var collectionView: UICollectionView!

    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        navigationItem.rightBarButtonItem = UIBarButtonItem(barButtonSystemItem: .add, target: self, action: #selector(handleAdd))
        let input = ["life", "taste", "file", "bat","angel","glean","bored","cat", "tab","act","inch","chin","robed","players" , "parsley","state"]
        let output = groupAnagrams(words: input)
        print(output)
        
        let inputArray: [Int] = [22, 1, 10, 20,17,3]
        guard let maxNumber = inputArray.max() else { return}
        var missingNumbers = [Int]()

        for number in 1...maxNumber {
            if !inputArray.contains(number) {
                missingNumbers.append(number)
            }
        }
        print(missingNumbers)
    }
    
    func groupAnagrams(words: [String]) -> [[String]] {
        var anagramGroups: [[String]] = []

        for word in words {
            let sortedWord = String(word.sorted())

            // Check if there's already a group with this sorted word
            if let index = anagramGroups.firstIndex(where: { $0.contains(where: { String($0.sorted()) == sortedWord }) }) {
                anagramGroups[index].append(word)
            } else {
                anagramGroups.append([word])
            }
        }

        return anagramGroups
    }

    func findMissingNumbers(input: [Int]) -> [Int] {
        guard let maxNumber = input.max() else { return [] }
        let fullRange = Set(1...maxNumber)
        let inputSet = Set(input)
        let missingNumbers = fullRange.subtracting(inputSet).sorted()
        return missingNumbers
    }

    
    @objc func handleAdd() {
        let vc = ScannerController()
        let navvc = UINavigationController(rootViewController: vc)
        
        navvc.modalPresentationStyle = .overFullScreen
        vc.didSavePhoto = {[weak self] imagesArray in
            
            guard let this = self else { return }
            
            this.images.removeAll()
            
            if let imagesArray = imagesArray {
                print(#function)
                print(imagesArray)
                for object in imagesArray {
                    this.images.append(object)
                }
                
                DispatchQueue.main.async {
                    this.collectionView.reloadData()
                }
            }
        }
        present(navvc, animated: true)
    }

}


extension ViewController: UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        images.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "ImageCell", for: indexPath) as? ImageCell {
            cell.myImageView.image = images[indexPath.item]
            return cell
        }
        return UICollectionViewCell()
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: collectionView.frame.width - 10, height: collectionView.frame.width - 10)
    }
}


class ImageCell: UICollectionViewCell {
    @IBOutlet weak var myImageView: UIImageView!
    
    override class func awakeFromNib() {
        super.awakeFromNib()
    }
    
}
