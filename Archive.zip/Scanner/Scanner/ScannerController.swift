

import AVFoundation
import UIKit

/// A simple button used for the shutter.
final class ShutterButton: UIControl {
    
    private let outterRingLayer = CAShapeLayer()
    private let innerCircleLayer = CAShapeLayer()
    
    private let outterRingRatio: CGFloat = 0.80
    private let innerRingRatio: CGFloat = 0.75
    
    private let impactFeedbackGenerator = UIImpactFeedbackGenerator(style: .light)
    
    override var isHighlighted: Bool {
        didSet {
            if oldValue != isHighlighted {
                animateInnerCircleLayer(forHighlightedState: isHighlighted)
            }
        }
    }
    
    // MARL: Life Cycle
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        layer.addSublayer(outterRingLayer)
        layer.addSublayer(innerCircleLayer)
        backgroundColor = .clear
        isAccessibilityElement = true
        accessibilityTraits = UIAccessibilityTraits.button
        impactFeedbackGenerator.prepare()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    // MARK: - Drawing
    
    override func draw(_ rect: CGRect) {
        super.draw(rect)

        outterRingLayer.frame = rect
        outterRingLayer.path = pathForOutterRing(inRect: rect).cgPath
        outterRingLayer.fillColor = UIColor.white.cgColor
        outterRingLayer.rasterizationScale = UIScreen.main.scale
        outterRingLayer.shouldRasterize = true
        
        innerCircleLayer.frame = rect
        innerCircleLayer.path = pathForInnerCircle(inRect: rect).cgPath
        innerCircleLayer.fillColor = UIColor.white.cgColor
        innerCircleLayer.rasterizationScale = UIScreen.main.scale
        innerCircleLayer.shouldRasterize = true
    }
    
    // MARK: - Animation
    
    private func animateInnerCircleLayer(forHighlightedState isHighlighted: Bool) {
        let animation = CAKeyframeAnimation(keyPath: "transform")
        var values = [CATransform3DMakeScale(1.0, 1.0, 1.0), CATransform3DMakeScale(0.9, 0.9, 0.9), CATransform3DMakeScale(0.93, 0.93, 0.93), CATransform3DMakeScale(0.9, 0.9, 0.9)]
        if isHighlighted == false {
            values = [CATransform3DMakeScale(0.9, 0.9, 0.9), CATransform3DMakeScale(1.0, 1.0, 1.0)]
        }
        animation.values = values
        animation.isRemovedOnCompletion = false
        animation.fillMode = CAMediaTimingFillMode.forwards
        animation.duration = isHighlighted ? 0.35 : 0.10
        
        innerCircleLayer.add(animation, forKey: "transform")
        impactFeedbackGenerator.impactOccurred()
    }
    
    // MARK: - Paths
    
    private func pathForOutterRing(inRect rect: CGRect) -> UIBezierPath {
        let path = UIBezierPath(ovalIn: rect)
        
        let innerRect = rect.scaleAndCenter(withRatio: outterRingRatio)
        let innerPath = UIBezierPath(ovalIn: innerRect).reversing()
        
        path.append(innerPath)
        
        return path
    }
    
    private func pathForInnerCircle(inRect rect: CGRect) -> UIBezierPath {
        let rect = rect.scaleAndCenter(withRatio: innerRingRatio)
        let path = UIBezierPath(ovalIn: rect)
        
        return path
    }
}

import Foundation
import UIKit
extension CGRect {
    
    /// Returns a new `CGRect` instance scaled up or down, with the same center as the original `CGRect` instance.
    /// - Parameters:
    ///   - ratio: The ratio to scale the `CGRect` instance by.
    /// - Returns: A new instance of `CGRect` scaled by the given ratio and centered with the original rect.
    func scaleAndCenter(withRatio ratio: CGFloat) -> CGRect {
        let scaleTransform = CGAffineTransform(scaleX: ratio, y: ratio)
        let scaledRect = applying(scaleTransform)
        
        let translateTransform = CGAffineTransform(translationX: origin.x * (1 - ratio) + (width - scaledRect.width) / 2.0, y: origin.y * (1 - ratio) + (height - scaledRect.height) / 2.0)
        let translatedRect = scaledRect.applying(translateTransform)
        
        return translatedRect
    }
}

class ScannerController: DocumentScannerViewController {
    
    var imagePicker: ImagePicker!

//    var captureButton: UIButton! //circle.fill
    lazy private var shutterButton: ShutterButton = {
        let button = ShutterButton()
        button.translatesAutoresizingMaskIntoConstraints = false
        button.addTarget(self, action: #selector(captureImage(_:)), for: .touchUpInside)
        return button
    }()
    var didSavePhoto: (([UIImage]?) -> Void)?
    //xmark
    override public var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        return .portrait
    }
    
    override public var shouldAutorotate: Bool {
        return true
    }
    
    override public var preferredInterfaceOrientationForPresentation: UIInterfaceOrientation {
        return .portrait
    }
    
    lazy private var photoLibraryButton: UIButton = {
        let button = UIButton()
        button.setImage(UIImage(systemName: "photo.fill.on.rectangle.fill"), for: .normal)
        button.tintColor = .white
        button.translatesAutoresizingMaskIntoConstraints = false
        button.addTarget(self, action: #selector(openPhotoLibrary), for: .touchUpInside)
        return button
    }()
    
    lazy private var rapidCameraButton: UIButton = {
        let button = UIButton()
        button.setImage(UIImage(systemName: "camera.shutter.button.fill"), for: .selected)
        button.setImage(UIImage(systemName: "camera"), for: .normal)
        button.tintColor = .white
        button.translatesAutoresizingMaskIntoConstraints = false
        button.addTarget(self, action: #selector(toggleRapidFire), for: .touchUpInside)
        return button
    }()
    
    lazy private var cancelButton: UIBarButtonItem = {
        let button = UIBarButtonItem(image: UIImage(systemName: "multiply"), style: .done, target: self, action: #selector(cancelImageScannerController))
        button.tintColor = .white
        return button
    }()
    
    
    lazy private var flashButton: UIView = {
        let view = UIView(frame: CGRect(x: 0, y: 0, width: 40, height: 40))
        let button = UIButton(frame: CGRect(origin: CGPoint(x: 0, y: 0), size: CGSize(width: 35, height: 35)))
        
        button.setImage(UIImage(systemName: "flashlight.slash"), for: .normal)
        button.setImage(UIImage(systemName: "flashlight.on.fill"), for: .selected)
        button.addTarget(self, action: #selector(toggleFlash(_:)), for: .touchUpInside)
        button.tintColor = .white
        view.addSubview(button)
        return view
    }()
    
    lazy private var autoCaptureModeButton: UIButton = {
//        let view = UIView(frame: CGRect(x: 0, y: 0, width: 100, height: 40))
        let button = UIButton(frame: CGRect(origin: CGPoint(x: 0, y: 0), size: CGSize(width: 98, height: 35)))
        button.setTitle("Auto Capture: Off", for: .normal)
        button.setTitle("Auto Capture: On", for: .selected)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 11)
        button.addTarget(self, action: #selector(toggleAutoCapture(_:)), for: .touchUpInside)
        button.backgroundColor = .white
        button.setTitleColor(.black, for: .normal)
        button.layer.cornerRadius = 10
        button.layer.masksToBounds = true
//        view.addSubview(button)
        return button
    }()
    private var rectangleDetector1: ImageRectangleDetector = CIImageRectangleDetector()
    private var points: [CGPoint] = []
    
    override func viewDidLoad() {
        TrackView.fillColor = UIColor.white.withAlphaComponent(0.4)
        TrackView.lineColor = UIColor.white

		tapToFocus = true
		lowLightBoost = false
		cameraPosition = .back
		flashMode = .off
		preset = .hd4K3840x2160

		cameraDelegate = self
		scannerDelegate = self

        super.viewDidLoad()
        
       
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        self.imagePicker = ImagePicker(presentationController: self, delegate: self)
        rectangleDetector1 = VisionImageRectangleDetector()
        
        autoCaptureModeButton.isSelected = CaptureSession.current.isAutoCapture
        rapidCameraButton.isSelected = CaptureSession.current.isMultipleScan
        
        view.addSubview(shutterButton)
        view.addSubview(photoLibraryButton)
        view.addSubview(rapidCameraButton)
        navigationItem.setLeftBarButton(cancelButton, animated: false)
        navigationItem.titleView = flashButton
        navigationItem.rightBarButtonItem = UIBarButtonItem(customView: autoCaptureModeButton)
        
        if #available(iOS 13.0, *) {
            isModalInPresentation = false
        }

        setupConstraints()
    }
    
    
    private func setupConstraints() {
        var shutterButtonConstraints = [NSLayoutConstraint]()
        var photoLibraryConstraints = [NSLayoutConstraint]()
        var rapidFireButtonConstraints = [NSLayoutConstraint]()
        
        
        shutterButtonConstraints = [
            shutterButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            shutterButton.widthAnchor.constraint(equalToConstant: 65.0),
            shutterButton.heightAnchor.constraint(equalToConstant: 65.0)
        ]
        
        photoLibraryConstraints = [
            photoLibraryButton.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 25),
            photoLibraryButton.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: -35),
            photoLibraryButton.widthAnchor.constraint(equalToConstant: 50.0),
            photoLibraryButton.heightAnchor.constraint(equalToConstant: 50.0)
        ]
        
        rapidFireButtonConstraints = [
            rapidCameraButton.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -25),
            rapidCameraButton.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: -35),
            rapidCameraButton.widthAnchor.constraint(equalToConstant: 50.0),
            rapidCameraButton.heightAnchor.constraint(equalToConstant: 50.0)
        ]
        
        
        
        if #available(iOS 11.0, *) {
            let shutterButtonBottomConstraint = view.safeAreaLayoutGuide.bottomAnchor.constraint(equalTo: shutterButton.bottomAnchor, constant: 8.0)
            shutterButtonConstraints.append(shutterButtonBottomConstraint)
        } else {
            let shutterButtonBottomConstraint = view.bottomAnchor.constraint(equalTo: shutterButton.bottomAnchor, constant: 8.0)
            shutterButtonConstraints.append(shutterButtonBottomConstraint)
        }
        
        NSLayoutConstraint.activate(shutterButtonConstraints + photoLibraryConstraints + rapidFireButtonConstraints)
    }

    @objc func cancelButton(_ sender: UIButton) {
        dismiss(animated: true)
    }
    
    @objc func captureImage(_ sender: UIButton) {
		takePhoto()
	}

    @objc private func cancelImageScannerController() {
        self.dismiss(animated: true)
        if let didSavePhoto = didSavePhoto {
            didSavePhoto(CaptureSession.current.results)
        }
    }
    
    @objc private func toggleFlash(_ sender: UIButton) {
        
        guard let device = AVCaptureDevice.default(for: AVMediaType.video) else {
            return
        }
        if device.hasTorch {
            sender.isSelected = !sender.isSelected
            do {
                try device.lockForConfiguration()
                device.torchMode = sender.isSelected ? .on : .off
                device.unlockForConfiguration()
            } catch {
                print(error)
            }

        }
    }
    
    @objc private func toggleAutoCapture(_ sender: UIButton) {
        sender.isSelected = !sender.isSelected
        CaptureSession.current.isAutoScanEnabled = sender.isSelected
        
    }
    
    @objc private func openPhotoLibrary(_ sender: UIButton) {
        print(#function)
        self.imagePicker.present(from: sender)
    }
    
    @objc private func toggleRapidFire(_ sender: UIButton) {
        print(#function)
        sender.isSelected = !sender.isSelected
        CaptureSession.current.isMultipleScan = sender.isSelected
        print(CaptureSession.current.isMultipleScan)
    }
    
    
}

extension ScannerController: ImagePickerDelegate {

    func didSelect(image: UIImage?) {
        rectangleDetector1.detect(image: image!) { [weak self] quad in
            guard let this = self , let quad = quad else { return }
            let ciImage = CIImage(image: image!)
            CropHelper1.crop(ciImage: ciImage!, quad: quad.mirrorUp()!) { result in
                this.showToast()
                this.startAgain()
                let croppedImage = result.cropped ?? UIImage()
                CaptureSession.current.results.append(croppedImage )
                if let didSavePhoto = this.didSavePhoto {
                    didSavePhoto(CaptureSession.current.results)
                }
                this.dismiss(animated: true)
            }
        }
    }
}


extension UIViewController {
    func showToast() {
        let toast = ToastView(
            title: "Document Saved!",
            titleFont: .systemFont(ofSize: 15, weight: .regular),
            subtitle: "",
            subtitleFont: .systemFont(ofSize: 11, weight: .light),
            icon: UIImage(systemName: "applelogo"),
            iconSpacing: 16,
            position: .bottom,
            onTap: { print("Tapped!") }
        )
        toast.lightBackgroundColor = UIColor.lightGray
        toast.show()
    }
}

extension ScannerController: DocumentScannerViewControllerDelegate {
    
    
    func documentScanner(results: [Result]) {
        print(results.count)
        print(#function)
        
    }
    

	func documentScanner(result: Result) {
        print(#function)
        if CaptureSession.current.isAutoScanEnabled {
            showToast()
            startAgain()
            CaptureSession.current.results.append(result.cropped ?? UIImage())
        }
        if !CaptureSession.current.isMultipleScan {
            self.dismiss(animated: true)
            if let didSavePhoto = self.didSavePhoto {
                didSavePhoto(CaptureSession.current.results)
            }
        }
	}

}

extension ScannerController: CameraViewControllerDelegate {

	func cameraViewController(didFocus point: CGPoint) {
		print("focused point: \(point)")
	}

	func cameraViewController(update status: AVAuthorizationStatus) {
		print("status changed")
	}

	func cameraViewController(captured image: UIImage) {
        print(#function)
        
        rectangleDetector1.detect(image: image) { [weak self] quad in
            guard let this = self , let quad = quad else { return }
            let ciImage = CIImage(image: image)
            CropHelper1.crop(ciImage: ciImage!, quad: quad.mirrorUp()!) { result in
                this.showToast()
                this.startAgain()
                let croppedImage = result.cropped ?? UIImage()
                CaptureSession.current.results.append(croppedImage )
                if !CaptureSession.current.isMultipleScan {
                    this.dismiss(animated: true)
                    if let didSavePhoto = this.didSavePhoto {
                        didSavePhoto(CaptureSession.current.results)
                    }
                }
            }
        }
	}


}

import Vision
public struct CropHelper1 {

    public typealias Completion = (Result) -> Void

    static func crop(ciImage: CIImage, quad: Quad, completion: @escaping Completion) {
        DispatchQueue.global(qos: .userInteractive).async {
            let context = CIContext()

            guard let cgImage = context.createCGImage(ciImage, from: ciImage.extent) else { return }
            let image = UIImage(cgImage: cgImage, scale: 1, orientation: .right).fixOrientation()

            let size = ciImage.extent.size
            let width = Int(size.width)
            let height = Int(size.height)

            let points: [CGPoint]
            points = quad.points.map { $0.scaledAbsolute(size: size) }
            let converted = points.map { $0.cartesian(height: size.height) }

            let result: Result
            if let quad = Quad(clockwise: converted), let cropped = applyPersperpectiveCorrection(ciImage: ciImage, quad: quad) {
                result = Result(original: image, cropped: cropped, quad: quad)
            } else {
                result = Result(original: image, cropped: nil, quad: nil)
            }

            DispatchQueue.main.async {
                completion(result)
            }
        }
    }

    private static func applyPersperpectiveCorrection(ciImage: CIImage, quad: Quad) -> UIImage? {
        guard let filter = CIFilter(name: "CIPerspectiveCorrection") else { return nil }
        let context = CIContext(options: nil)

        filter.setValue(CIVector(cgPoint: quad.topLeft), forKey: "inputTopLeft")
        filter.setValue(CIVector(cgPoint: quad.topRight), forKey: "inputTopRight")
        filter.setValue(CIVector(cgPoint: quad.bottomLeft), forKey: "inputBottomLeft")
        filter.setValue(CIVector(cgPoint: quad.bottomRight), forKey: "inputBottomRight")
        filter.setValue(ciImage, forKey: kCIInputImageKey)

        guard let correctedImage = filter.outputImage, let cgImage = context.createCGImage(correctedImage, from: correctedImage.extent) else { return nil }
        return UIImage(cgImage: cgImage, scale: 1, orientation: .right)
    }

}
