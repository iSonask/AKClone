//
//  ListViewApp.swift
//  ListView
//
//  Created by Akash on 21/06/24.
//

import SwiftUI

@main
struct ListViewApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
