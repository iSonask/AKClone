//
//  ContentView.swift
//  ListView
//
//  Created by Akash on 21/06/24.
//

import SwiftUI
struct Menu: Hashable,Identifiable {
    let id: UUID
    let name: String
    let image: String
}

struct Bookmark: Identifiable {
    let id = UUID()
    let name: String
    let icon: String
    var items: [Bookmark]?

    // some example websites
    static let apple = Bookmark(name: "Apple", icon: "1.circle")
    static let bbc = Bookmark(name: "BBC", icon: "square.and.pencil")
    static let swift = Bookmark(name: "Swift", icon: "bolt.fill")
    static let twitter = Bookmark(name: "Twitter", icon: "mic")

    // some example groups
    static let example1 = Bookmark(name: "Favorites", icon: "star", items: [Bookmark.apple, Bookmark.bbc, Bookmark.swift, Bookmark.twitter])
    static let example2 = Bookmark(name: "Recent", icon: "timer", items: [Bookmark.apple, Bookmark.bbc, Bookmark.swift, Bookmark.twitter])
    static let example3 = Bookmark(name: "Recommended", icon: "hand.thumbsup", items: [Bookmark.apple, Bookmark.bbc, Bookmark.swift, Bookmark.twitter])
}


struct ContentView: View {
    let items: [Bookmark] = [.example1, .example2, .example3]

    let menus = [Menu(id: UUID(), name: "First", image: "applelogo"),
                 Menu(id: UUID(), name: "Second", image: "bell.fill"),
                 Menu(id: UUID(), name: "Third", image: "bell"),
                 Menu(id: UUID(), name: "Fourth", image: "bell.fill")]
    
    var body: some View {
        NavigationStack {
//            List {
//                ForEach(menus) { menu in
//                    HStack {
//                        Image(systemName:  menu.image)
//                        Text(menu.name)
//                    }
//                }
//            }
            List(items, children: \.items) { row in
                        HStack {
                            Image(systemName: row.icon)
                            Text(row.name)
                        }
                    }
            .navigationTitle("Home")
        }
    }
}

#Preview {
    ContentView()
}
