//
//  Root1DestinationView.swift
//  SwiftUINavigation
//
//  Created by Akash on 08/08/24.
//

import Foundation
import SwiftUI

struct Root1DestinationView: View {
    var body: some View {
        List {
            NavigationLink(value: Root1NavigationLikValues.destination2(title: "AAA")) {
                Text("Destination2View")
            }
        }.navigationTitle("Destination1View")
    }
}

#Preview {
    Root1DestinationView()
}
