//
//  SwiftUINavigationApp.swift
//  SwiftUINavigation
//
//  Created by Akash on 08/08/24.
//

import SwiftUI

@main
struct SwiftUINavigationApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
