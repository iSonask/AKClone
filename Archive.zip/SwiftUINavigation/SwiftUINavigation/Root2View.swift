//
//  Root2View.swift
//  SwiftUINavigation
//
//  Created by Akash on 08/08/24.
//

import Foundation
import SwiftUI

struct Root2View: View {
    
    var body: some View {
Text("TEST")
        
//        Button(action:
//                Root2DestinationView(title: "AAKASH")
//            .navigationlinkValues(NavigationLink)
//        ) {
//            Text("GO")
//        }
    }
}


#Preview {
    Root2View()
}
