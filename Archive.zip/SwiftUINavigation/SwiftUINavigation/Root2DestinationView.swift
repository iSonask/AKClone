//
//  Root2DestinationView.swift
//  SwiftUINavigation
//
//  Created by Akash on 08/08/24.
//

import Foundation
import SwiftUI

struct Root2DestinationView: View {
    let title: String
    var body: some View {
        Text("Heym, \(title)")
    }
}

#Preview {
    Root2DestinationView(title: "")
}
