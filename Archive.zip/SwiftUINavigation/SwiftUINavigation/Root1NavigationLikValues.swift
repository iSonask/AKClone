//
//  Root1NavigationLikValues.swift
//  SwiftUINavigation
//
//  Created by Akash on 08/08/24.
//

import SwiftUI

enum Root1NavigationLikValues: Hashable, View{
    
    case destination1
    case destination2(title: String)
    
    var body: some View {
        switch self {
        case .destination1:
            Root1DestinationView()
        case .destination2(let title):
            Root2DestinationView(title: title)
        }
    }
}
