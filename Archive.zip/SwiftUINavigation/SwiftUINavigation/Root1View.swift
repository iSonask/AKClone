//
//  Root1View.swift
//  SwiftUINavigation
//
//  Created by Akash on 08/08/24.
//

import Foundation
import SwiftUI

struct Root1View: View {
    var body: some View {
            List {
                NavigationLink(value: Root1NavigationLikValues.destination1) {
                    Text("Destination1View")
                }
            }
            .navigationTitle("Hey")
    }
}


#Preview {
    Root1View()
}
