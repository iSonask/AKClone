//
//  ContentView.swift
//  SwiftUINavigation
//
//  Created by Akash on 08/08/24.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        TabView{
//            NavigationStack {
//                Root1View()
//                    .navigationDestination(for: Root1NavigationLikValues.self, destination: { $0 })
//            }
            Root1View()
                .navigationlinkValues(Root1NavigationLikValues.self)
                .tabItem { Image(systemName: "1.circle") }
            
            Root2View()
                .tabItem { Image(systemName: "2.circle") }
        }
    }
}

#Preview {
    ContentView()
}
