//
//  View+.swift
//  SwiftUINavigation
//
//  Created by Akash on 08/08/24.
//

import Foundation
import SwiftUI

extension View {
    
    func navigationlinkValues<D>(_ data:D.Type) -> some View where D : Hashable & View {
        NavigationStack {
            self.navigationDestination(for: data, destination: { $0 })
        }
    }
}
