//
//  AttendanceVC.swift
//  AlignGroup
//
//  Created by SHANI SHAH on 22/02/19.
//  Copyright © 2019 SHANI SHAH. All rights reserved.
//

import UIKit

class ReportVC: UIViewController,MenuRedirectionProtocol {

    var dropDown = DropDown()
    
    @IBOutlet weak var segmentedView: TTSegmentedControl!
    @IBOutlet weak var searchButton: UIButton!
    @IBOutlet weak var searchTextField: UITextField!
    @IBOutlet weak var calendarContainerView: UIView!
    @IBOutlet weak var calenderView: CVCalendarView!
    @IBOutlet weak var attendanceTableView: UITableView!
    @IBOutlet weak var menuView: CVCalendarMenuView!
    
    private var randomNumberOfDotMarkersForDay = [Int]()
    private var shouldShowDaysOut = false
    private var animationFinished = true
    private var selectedDay: DayView1!
    private var currentCalendar: Calendar?
    
    var usersData = [["name":"Tony Stark","attendance":"present","image":"iconDashboard"],
                     ["name":"Thor","attendance":"present",
                      "image":"iconDashboard"],
                     ["name":"Hulk","attendance":"present",
                     "image":"iconDashboard"],
                     ["name":"Dr. Strange","attendance":"present",
                      "image":"iconDashboard"],
                     ["name":"Spider Man","attendance":"present",
                      "image":"iconDashboard"],
                     ["name":"Tony Stark","attendance":"present",
                      "image":"iconDashboard"],
                     ["name":"Tony Stark","attendance":"present",
                      "image":"iconDashboard"]]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Attendance"
        configure()
        updateNavigationBarButtons()
    }
    
    func updateNavigationBarButtons() {
        let notificationButton = UIBarButtonItem(image: UIImage(named: "iconNotification"), style: .done, target: self, action: #selector(handeNotificationAction))
        let addButton = UIBarButtonItem(image: UIImage(named: "iconAdd"), style: .done, target: self, action: #selector(handleAddAction))
        self.navigationItem.rightBarButtonItems = [addButton,notificationButton]
    }
    
    @objc func handeNotificationAction() {
        print("notification")
    }
    
    @objc func handleAddAction() {
        print("add")
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
       // calenderView.changeMode(.weekView)
        segmentedView.hasBounceAnimation = true
        self.navigationItem.backBarButtonItem = UIBarButtonItem(title:"", style:.plain, target:nil, action:nil)
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        self.navigationItem.backBarButtonItem = UIBarButtonItem(title:"", style:.plain, target:nil, action:nil)
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        calenderView.commitCalendarViewUpdate()
        menuView.commitMenuViewUpdate()
    }
    
    @IBAction func searchButtonAction(_ sender: UIButton) {
        
    }
    
    func configure()  {
        addImageToBackground(image: UIImage(named: "loginBg")!)
        view.backgroundColor = .clear
        calendarContainerView.backgroundColor = .clear
        
        searchTextField.placeholder = "Search"
        searchTextField.font = .custom(size: 10)
        
        segmentedView.itemTitles = ["Edit View","Expandalbe View"]
        segmentedView.defaultTextColor = UIColor.black
        segmentedView.selectedTextColor = UIColor.white
        segmentedView.defaultTextFont = .customBold(size: 10)
        segmentedView.selectedTextFont = .customBold(size: 10)
        segmentedView.thumbColor = .appColor
        segmentedView.selectItemAt(index: 0)
        
        segmentedView.didSelectItemWith = { (index, item) in
            if index == 0{
//                self.view.sendSubviewToBack(self.listView)
//                self.view.bringSubviewToFront(self.calendarContainerView)
            } else {
//                self.view.sendSubviewToBack(self.calendarContainerView)
//                self.view.bringSubviewToFront(self.listView)
            }
        }
        
        segmentedView.useShadow = true
        
        searchTextField.superview?.layer.cornerRadius = 15
        searchTextField.superview?.layer.masksToBounds = true
        searchTextField.superview?.layer.borderColor = UIColor.gray.cgColor
        searchTextField.superview?.layer.borderWidth = 0.7
        
        attendanceTableView.backgroundColor = .clear
        attendanceTableView.separatorStyle = .none
        
        dropDown.dataSource = ["first","second"]
        dropDown.width = 140
        dropDown.cellHeight = 30
        dropDown.textFont = .custom(size : 9)
        dropDown.backgroundColor = UIColor.appLightOrange
        dropDown.direction = .top
        dropDown.selectionAction = { [unowned self] (index: Int, item: String) in
            print("Selected item: \(item) at index: \(index)")
            self.dropDown.hide()
        }
    }
}

extension ReportVC: UITableViewDelegate,UITableViewDataSource{
    
//    func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
//        return UITableView.automaticDimension
//    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
            return 80
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return usersData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "EditViewCell", for: indexPath) as! EditViewCell
        cell.setupData(data: usersData[indexPath.row])
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
    }
}

extension ReportVC {
    
    func toggleMonthViewWithMonthOffset(offset: Int) {
        guard let currentCalendar = currentCalendar else { return }
        
        var components = Manager.componentsForDate(Date(), calendar: currentCalendar) // from today
        
        components.month! += offset
        let resultDate = currentCalendar.date(from: components)!
        self.calenderView.toggleViewWithDate(resultDate)
    }
    
    func didShowNextMonthView(_ date: Date) {
        guard let currentCalendar = currentCalendar else { return }
        
        let components = Manager.componentsForDate(date, calendar: currentCalendar) // from today
        print("Showing Month: \(components.month!)")
    }
    
    func didShowPreviousMonthView(_ date: Date) {
        guard let currentCalendar = currentCalendar else { return }
        
        let components = Manager.componentsForDate(date, calendar: currentCalendar) // from today
        print("Showing Month: \(components.month!)")
    }
    
    func didShowNextWeekView(from startDayView: DayView1, to endDayView: DayView1) {
        print("Showing Week: from \(startDayView.date.day) to \(endDayView.date.day)")
    }
    
    func didShowPreviousWeekView(from startDayView: DayView1, to endDayView: DayView1) {
        print("Showing Week: from \(startDayView.date.day) to \(endDayView.date.day)")
    }
    
}

extension ReportVC: CVCalendarViewDelegate, CVCalendarMenuViewDelegate {
    
    // MARK: Required methods
    
    func presentationMode() -> CalendarMode { return .monthView }
    func firstWeekday() -> Weekday { return .sunday }
    
    // MARK: Optional methods
    
    func calendar() -> Calendar? { return currentCalendar }
    
    func dayOfWeekTextColor(by weekday: Weekday) -> UIColor {
        return weekday == .sunday ? UIColor.appColor : UIColor.appColor
    }
    
    func shouldShowWeekdaysOut() -> Bool { return shouldShowDaysOut }
    
    // Defaults to true
    func shouldAnimateResizing() -> Bool { return true }
    
    private func shouldSelectDayView(dayView: DayView1) -> Bool {
        return arc4random_uniform(3) == 0 ? true : false
    }
    
    func shouldAutoSelectDayOnMonthChange() -> Bool { return false }
    
    func didSelectDayView(_ dayView: CVCalendarDayView, animationDidFinish: Bool) {
        print(dayView.date.convertedDate()!)
        selectedDay = dayView
    }
    
    func shouldSelectRange() -> Bool { return false }
    
    func didSelectRange(from startDayView: DayView1, to endDayView: DayView1) {
        print("RANGE SELECTED: \(startDayView.date.commonDescription) to \(endDayView.date.commonDescription)")
    }
    
    func presentedDateUpdated(_ date: CVDate) {
//        if monthLabel.text != date.globalDescription && self.animationFinished {
//            let updatedMonthLabel = UILabel()
//            updatedMonthLabel.textColor = monthLabel.textColor
//            updatedMonthLabel.font = .bold()
//            updatedMonthLabel.textAlignment = .center
//            updatedMonthLabel.text = date.globalDescription
//            updatedMonthLabel.sizeToFit()
//            updatedMonthLabel.alpha = 0
//            updatedMonthLabel.center = self.monthLabel.center
//
//            let offset = CGFloat(48)
//            updatedMonthLabel.transform = CGAffineTransform(translationX: 0, y: offset)
//            updatedMonthLabel.transform = CGAffineTransform(scaleX: 1, y: 0.1)
//
//            UIView.animate(withDuration: 0.35, delay: 0, options: UIView.AnimationOptions.curveEaseIn, animations: {
//                self.animationFinished = false
//                self.monthLabel.transform = CGAffineTransform(translationX: 0, y: -offset)
//                self.monthLabel.transform = CGAffineTransform(scaleX: 1, y: 0.1)
//                self.monthLabel.alpha = 0
//
//                updatedMonthLabel.alpha = 1
//                updatedMonthLabel.transform = CGAffineTransform.identity
//
//            }) { _ in
//
//                self.animationFinished = true
//                self.monthLabel.frame = updatedMonthLabel.frame
//                self.monthLabel.text = updatedMonthLabel.text
//                self.monthLabel.transform = CGAffineTransform.identity
//                self.monthLabel.alpha = 1
//                updatedMonthLabel.removeFromSuperview()
//            }
//
//            self.view.insertSubview(updatedMonthLabel, aboveSubview: self.monthLabel)
//        }
    }
    
    func topMarker(shouldDisplayOnDayView dayView: CVCalendarDayView) -> Bool { return false }
    
    func weekdaySymbolType() -> WeekdaySymbolType { return .short }
    
    func selectionViewPath() -> ((CGRect) -> (UIBezierPath)) {
        return { UIBezierPath(rect: CGRect(x: 0, y: 0, width: $0.width, height: $0.height)) }
    }
    
    func shouldShowCustomSingleSelection() -> Bool { return false }
    
    func preliminaryView(viewOnDayView dayView: DayView1) -> UIView {
        let circleView = CVAuxiliaryView(dayView: dayView, rect: dayView.frame, shape: CVShape.circle)
        circleView.fillColor = .colorFromCode(0xBBBBBB)
        return circleView
    }
    
    func preliminaryView(shouldDisplayOnDayView dayView: DayView1) -> Bool {
        if (dayView.isCurrentDay) {
            return true
        }
        return false
    }
    
    func disableScrollingBeforeDate() -> Date { return Date() }
    func maxSelectableRange() -> Int { return 14 }
    func earliestSelectableDate() -> Date { return Date() }
}


// MARK: - CVCalendarViewAppearanceDelegate

extension ReportVC: CVCalendarViewAppearanceDelegate {
    
    func dayLabelWeekdayDisabledColor() -> UIColor { return .appColor }
    
    func dayLabelPresentWeekdayInitallyBold() -> Bool { return false }
    
    func spaceBetweenDayViews() -> CGFloat { return 5 }
    
    func dayLabelFont(by weekDay: Weekday, status: CVStatus, present: CVPresent) -> UIFont { return .custom(size: 10) }
    
    func dayLabelColor(by weekDay: Weekday, status: CVStatus, present: CVPresent) -> UIColor? {
        switch (weekDay, status, present) {
        case (_, .selected, _), (_, .highlighted, _): return ColorsConfig.selectedText
        case (.sunday, .in, _): return ColorsConfig.sundayText
        case (.sunday, _, _): return ColorsConfig.sundayTextDisabled
        case (_, .in, _): return ColorsConfig.text
        default: return ColorsConfig.textDisabled
        }
    }
    
    func dayLabelBackgroundColor(by weekDay: Weekday, status: CVStatus, present: CVPresent) -> UIColor? {
        switch (weekDay, status, present) {
        case (.sunday, .selected, _), (.sunday, .highlighted, _): return ColorsConfig.sundaySelectionBackground
        case (_, .selected, _), (_, .highlighted, _): return ColorsConfig.selectionBackground
        default: return nil
        }
    }
}
