//
//  DashboardVC.swift
//  AlignGroup
//
//  Created by SHANI SHAH on 05/02/19.
//  Copyright © 2019 SHANI SHAH. All rights reserved.
//

import UIKit

class DashboardVC: UIViewController,StoryboardRedirectionProtocol {

    
    @IBOutlet weak var quickLinkView: UIView!
    @IBOutlet weak var barChartView: VCoreBarChart!
    @IBOutlet weak var calenderView: CVCalendarView!
    @IBOutlet weak var announcmentTableView: UITableView!
    @IBOutlet weak var menuView: CVCalendarMenuView!
    
    @IBOutlet weak var companyDetailTableView: UITableView!
    
    @IBOutlet weak var employeeTableView: UITableView!
    
    @IBOutlet weak var myTaskTableView: UITableView!
    
    @IBOutlet weak var monthLabel: UILabel!
    @IBOutlet weak var chartView: PieChart!
    
    private var randomNumberOfDotMarkersForDay = [Int]()
    private var shouldShowDaysOut = false
    private var animationFinished = true
    private var selectedDay: DayView1!
    private var currentCalendar: Calendar?
    
    // MARK: - Life cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        
        title = "Dashboard"
        
        employeeTableView.backgroundColor = .clear
        announcmentTableView.backgroundColor = .clear
        announcmentTableView.separatorStyle = .none
        myTaskTableView.backgroundColor = .clear
        companyDetailTableView.backgroundColor = .clear
        
        barChartView.dataSource = self
        barChartView.backgroundColor = .white
        
        self.monthLabel.text = CVDate(date: Date()).globalDescription

        
        addImageToBackground(image: UIImage(named: "loginBg")!)
        randomizeDotMarkers()
        updateNavigationBarButtons()
    }
    var notificationButton: MIBadgeButton = {
        let button = MIBadgeButton(type: .custom)
        button.setImage(UIImage(named: "iconNotification"), for: .normal)
        button.badgeTextColor = .appColor
        button.badgeBackgroundColor = .white
        button.badgeEdgeInsets = UIEdgeInsets(top: 4, left: 20, bottom: 0, right: 0)
        
        return button
    }()
    
    func updateNavigationBarButtons() {
        
        notificationButton.addAction(for: .touchUpInside) {
        }
        
        notificationButton.badgeString = "10"
        navigationItem.rightBarButtonItem = UIBarButtonItem(customView: notificationButton)
        navigationItem.leftBarButtonItem = UIBarButtonItem(image: UIImage(named: "iconMenu"), style: .done, target: self, action: #selector(toggleLeft))
    }
    
    @objc func handeNotificationAction() {
        print("notification")
    }
    
    @objc func handleAddAction() {
        print("add")
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        self.navigationItem.backBarButtonItem = UIBarButtonItem(title:"", style:.plain, target:nil, action:nil)
        chartView.layers = [createCustomViewsLayer(), createTextLayer()]
        chartView.delegate = self
        chartView.models = createModels() // order is important - models have to be set at the end
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.navigationItem.backBarButtonItem = UIBarButtonItem(title:"", style:.plain, target:nil, action:nil)
    }

    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        quickLinkView.roundTopCorners(radius: 5.0)
        quickLinkView.layoutSubviews()
        quickLinkView.layoutIfNeeded()
        calenderView.commitCalendarViewUpdate()
        menuView.commitMenuViewUpdate()
    }
 
    @IBAction func nextMonth(_ sender: UIButton){
        calenderView.loadNextView()
    }
    
    @IBAction func previousMonth(_ sender: UIButton){
        calenderView.loadPreviousView()
    }
    
    @IBAction func announcementButtonAction(_ sender: UIButton){
        
    }
    
    @IBAction func calendarButtonAction(_ sender: UIButton){
        let controller = CalendarVC.getViewController()
        navigationController?.pushViewController(controller, animated: true)
    }

    @IBAction func performanceButtonAction(_ sender: UIButton){
        
    }

    @IBAction func employeButtonAction(_ sender: UIButton){
        
    }

    @IBAction func myTasksButtonAction(_ sender: UIButton){
        let controller = ToDoVC.getViewController()
        navigationController?.pushViewController(controller, animated: true)
    }

    @IBAction func companyDetailButtonAction(_ sender: UIButton){
        
    }

    
}

// MARK: - Piechart methods

extension DashboardVC{
    
    private func randomizeDotMarkers() {
        randomNumberOfDotMarkersForDay = [Int]()
        //        for _ in 0...31 {
        //            randomNumberOfDotMarkersForDay.append(Int(arc4random_uniform(3) + 1))
        //        }
    }
    
    // MARK: - Models
    
    fileprivate func createModels() -> [PieSliceModel] {
        let alpha: CGFloat = 0.5
        
        return [
            PieSliceModel(value: 2.1, color: UIColor.yellow.withAlphaComponent(alpha)),
            PieSliceModel(value: 3, color: UIColor.blue.withAlphaComponent(alpha)),
            PieSliceModel(value: 1, color: UIColor.green.withAlphaComponent(alpha)),
            PieSliceModel(value: 4, color: UIColor.cyan.withAlphaComponent(alpha)),
            PieSliceModel(value: 2, color: UIColor.red.withAlphaComponent(alpha)),
            PieSliceModel(value: 1.5, color: UIColor.magenta.withAlphaComponent(alpha)),
            PieSliceModel(value: 0.5, color: UIColor.orange.withAlphaComponent(alpha))
        ]
    }
    
    // MARK: - Layers
    
    fileprivate func createCustomViewsLayer() -> PieCustomViewsLayer {
        let viewLayer = PieCustomViewsLayer()
        
        let settings = PieCustomViewsLayerSettings()
        settings.viewRadius = 135
        settings.hideOnOverflow = false
        viewLayer.settings = settings
        
        //        viewLayer.viewGenerator = createViewGenerator()
        
        return viewLayer
    }
    
    fileprivate func createTextLayer() -> PiePlainTextLayer {
        let textLayerSettings = PiePlainTextLayerSettings()
        textLayerSettings.viewRadius = 60
        textLayerSettings.hideOnOverflow = true
        textLayerSettings.label.font = UIFont.systemFont(ofSize: 12)
        
        //        change this if you need to change color
        textLayerSettings.label.textColor = .clear
        
        let formatter = NumberFormatter()
        formatter.maximumFractionDigits = 1
        textLayerSettings.label.textGenerator = {slice in
            return formatter.string(from: slice.data.percentage * 100 as NSNumber).map{"\($0)%"} ?? ""
        }
        
        let textLayer = PiePlainTextLayer()
        textLayer.settings = textLayerSettings
        return textLayer
    }
    
    fileprivate func createViewGenerator() -> (PieSlice, CGPoint) -> UIView {
        return {slice, center in
            
            let container = UIView()
            container.frame.size = CGSize(width: 100, height: 40)
            container.center = center
            let view = UIImageView()
            view.frame = CGRect(x: 30, y: 0, width: 40, height: 40)
            container.addSubview(view)
            
            if slice.data.id == 3 || slice.data.id == 0 {
                let specialTextLabel = UILabel()
                specialTextLabel.textAlignment = .center
                if slice.data.id == 0 {
                    specialTextLabel.text = "views"
                    specialTextLabel.font = UIFont.boldSystemFont(ofSize: 18)
                } else if slice.data.id == 3 {
                    specialTextLabel.textColor = UIColor.blue
                    specialTextLabel.text = "Custom"
                }
                specialTextLabel.sizeToFit()
                specialTextLabel.frame = CGRect(x: 0, y: 40, width: 100, height: 20)
                container.addSubview(specialTextLabel)
                container.frame.size = CGSize(width: 100, height: 60)
            }
            
            
            // src of images: www.freepik.com, http://www.flaticon.com/authors/madebyoliver
            let imageName: String? = {
                switch slice.data.id {
                case 0: return "fish"
                case 1: return "grapes"
                case 2: return "doughnut"
                case 3: return "water"
                case 4: return "chicken"
                case 5: return "beet"
                case 6: return "cheese"
                default: return nil
                }
            }()
            
            view.image = imageName.flatMap{UIImage(named: $0)}
            
            return container
        }
    }

}

extension DashboardVC: PieChartDelegate{
    
    func onSelected(slice: PieSlice, selected: Bool) {
        print("Selected: \(selected), slice: \(slice)")
    }
    
}

extension DashboardVC: CoreChartViewDataSource{
    
    func didTouch(entryData: CoreChartEntry) {
        print(entryData.barTitle)
    }
    
    func loadCoreChartData() -> [CoreChartEntry] {
        
        return getTurkeyFamouseCityList()
        
    }
    
    
    func getTurkeyFamouseCityList()->[CoreChartEntry] {
        var allCityData = [CoreChartEntry]()
        let cityNames = ["Istanbul","Antalya","Ankara","Trabzon","İzmir"]
        let plateNumber = [34,07,06,61,35]
        
        for index in 0..<cityNames.count {
            
            let newEntry = CoreChartEntry(id: "\(plateNumber[index])", barTitle: cityNames[index], barHeight: Double(plateNumber[index]), barColor: rainbowColor())
            allCityData.append(newEntry)
            
        }
        
        return allCityData
        
    }
}

// MARK: - CVCalendarViewDelegate & CVCalendarMenuViewDelegate

extension DashboardVC {
    
    func toggleMonthViewWithMonthOffset(offset: Int) {
        guard let currentCalendar = currentCalendar else { return }
        
        var components = Manager.componentsForDate(Date(), calendar: currentCalendar) // from today
        
        components.month! += offset
        
        let resultDate = currentCalendar.date(from: components)!
        
        self.calenderView.toggleViewWithDate(resultDate)
    }
    
    func didShowNextMonthView(_ date: Date) {
        guard let currentCalendar = currentCalendar else { return }
        
        let components = Manager.componentsForDate(date, calendar: currentCalendar) // from today
        
        print("Showing Month: \(components.month!)")
    }
    
    func didShowPreviousMonthView(_ date: Date) {
        guard let currentCalendar = currentCalendar else { return }
        
        let components = Manager.componentsForDate(date, calendar: currentCalendar) // from today
        
        print("Showing Month: \(components.month!)")
    }
    
    func didShowNextWeekView(from startDayView: DayView1, to endDayView: DayView1) {
        print("Showing Week: from \(startDayView.date.day) to \(endDayView.date.day)")
    }
    
    func didShowPreviousWeekView(from startDayView: DayView1, to endDayView: DayView1) {
        print("Showing Week: from \(startDayView.date.day) to \(endDayView.date.day)")
    }
    
}

extension DashboardVC: CVCalendarViewDelegate, CVCalendarMenuViewDelegate {
    
    // MARK: Required methods
    
    func presentationMode() -> CalendarMode { return .monthView }
    
    func firstWeekday() -> Weekday { return .sunday }
    
    // MARK: Optional methods
    
    func calendar() -> Calendar? { return currentCalendar }
    
    func dayOfWeekTextColor(by weekday: Weekday) -> UIColor {
        return weekday == .sunday ? UIColor.appColor : UIColor.appColor
    }
    
    func shouldShowWeekdaysOut() -> Bool { return shouldShowDaysOut }
    
    // Defaults to true
    func shouldAnimateResizing() -> Bool { return true }
    
    private func shouldSelectDayView(dayView: DayView1) -> Bool {
        return arc4random_uniform(3) == 0 ? true : false
    }
    
    func shouldAutoSelectDayOnMonthChange() -> Bool { return false }
    
    func didSelectDayView(_ dayView: CVCalendarDayView, animationDidFinish: Bool) {
        selectedDay = dayView
    }
    
    func shouldSelectRange() -> Bool { return false }
    
    func didSelectRange(from startDayView: DayView1, to endDayView: DayView1) {
        print("RANGE SELECTED: \(startDayView.date.commonDescription) to \(endDayView.date.commonDescription)")
    }
    
    func presentedDateUpdated(_ date: CVDate) {
        if monthLabel.text != date.globalDescription && self.animationFinished {
            let updatedMonthLabel = UILabel()
            updatedMonthLabel.textColor = monthLabel.textColor
            updatedMonthLabel.font = .bold()
            updatedMonthLabel.textAlignment = .center
            updatedMonthLabel.text = date.globalDescription
            updatedMonthLabel.sizeToFit()
            updatedMonthLabel.alpha = 0
            updatedMonthLabel.center = self.monthLabel.center
            
            let offset = CGFloat(48)
            updatedMonthLabel.transform = CGAffineTransform(translationX: 0, y: offset)
            updatedMonthLabel.transform = CGAffineTransform(scaleX: 1, y: 0.1)
            
            UIView.animate(withDuration: 0.35, delay: 0, options: UIView.AnimationOptions.curveEaseIn, animations: {
                self.animationFinished = false
                self.monthLabel.transform = CGAffineTransform(translationX: 0, y: -offset)
                self.monthLabel.transform = CGAffineTransform(scaleX: 1, y: 0.1)
                self.monthLabel.alpha = 0
                
                updatedMonthLabel.alpha = 1
                updatedMonthLabel.transform = CGAffineTransform.identity
                
            }) { _ in
                
                self.animationFinished = true
                self.monthLabel.frame = updatedMonthLabel.frame
                self.monthLabel.text = updatedMonthLabel.text
                self.monthLabel.transform = CGAffineTransform.identity
                self.monthLabel.alpha = 1
                updatedMonthLabel.removeFromSuperview()
            }
            
            self.view.insertSubview(updatedMonthLabel, aboveSubview: self.monthLabel)
        }
    }
    
    func topMarker(shouldDisplayOnDayView dayView: CVCalendarDayView) -> Bool { return false }
    
    func weekdaySymbolType() -> WeekdaySymbolType { return .short }
    
    func selectionViewPath() -> ((CGRect) -> (UIBezierPath)) {
        return { UIBezierPath(rect: CGRect(x: 0, y: 0, width: $0.width, height: $0.height)) }
    }
    
    func shouldShowCustomSingleSelection() -> Bool { return false }
    
    func preliminaryView(viewOnDayView dayView: DayView1) -> UIView {
        let circleView = CVAuxiliaryView(dayView: dayView, rect: dayView.frame, shape: CVShape.circle)
        circleView.fillColor = .colorFromCode(0xBBBBBB)
        return circleView
    }
    
    func preliminaryView(shouldDisplayOnDayView dayView: DayView1) -> Bool {
        if (dayView.isCurrentDay) {
            return true
        }
        return false
    }
    
//    func supplementaryView(viewOnDayView dayView: DayView) -> UIView {
//
//        dayView.setNeedsLayout()
//        dayView.layoutIfNeeded()
//
//        let π = Double.pi
//
//        let ringLayer = CAShapeLayer()
//        let ringLineWidth: CGFloat = 4.0
//        let ringLineColour = UIColor.blue
//
//        let newView = UIView(frame: dayView.frame)
//
//        let diameter = (min(newView.bounds.width, newView.bounds.height))
//        let radius = diameter / 2.0 - ringLineWidth
//
//        newView.layer.addSublayer(ringLayer)
//
//        ringLayer.fillColor = nil
//        ringLayer.lineWidth = ringLineWidth
//        ringLayer.strokeColor = ringLineColour.cgColor
//
//        let centrePoint = CGPoint(x: newView.bounds.width/2.0, y: newView.bounds.height/2.0)
//        let startAngle = CGFloat(-π/2.0)
//        let endAngle = CGFloat(π * 2.0) + startAngle
//        let ringPath = UIBezierPath(arcCenter: centrePoint,
//                                    radius: radius,
//                                    startAngle: startAngle,
//                                    endAngle: endAngle,
//                                    clockwise: true)
//
//        ringLayer.path = ringPath.cgPath
//        ringLayer.frame = newView.layer.bounds
//
//        return newView
//    }
//
//    func supplementaryView(shouldDisplayOnDayView dayView: DayView) -> Bool {
//        guard let currentCalendar = currentCalendar else { return false }
//
//        var components = Manager.componentsForDate(Foundation.Date(), calendar: currentCalendar)
//
//        /* For consistency, always show supplementaryView on the 3rd, 13th and 23rd of the current month/year.  This is to check that these expected calendar days are "circled". There was a bug that was circling the wrong dates. A fix was put in for #408 #411.
//
//         Other month and years show random days being circled as was done previously in the Demo code.
//         */
//        var shouldDisplay = false
//        if dayView.date.year == components.year &&
//            dayView.date.month == components.month {
//
//            if (dayView.date.day == 3 || dayView.date.day == 13 || dayView.date.day == 23)  {
//                print("Circle should appear on " + dayView.date.commonDescription)
//                shouldDisplay = true
//            }
//        } else if (Int(arc4random_uniform(3)) == 1) {
//            shouldDisplay = true
//        }
//
//        return shouldDisplay
//    }
    
    
    func disableScrollingBeforeDate() -> Date { return Date() }
    
    func maxSelectableRange() -> Int { return 14 }
    
    func earliestSelectableDate() -> Date { return Date() }
    
//    func latestSelectableDate() -> Date {
//        var dayComponents = DateComponents()
//        dayComponents.day = 70
//        let calendar = Calendar(identifier: .gregorian)
//        if let lastDate = calendar.date(byAdding: dayComponents, to: Date()) {
//            return lastDate
//        }
//        
//        return Date()
//    }
}


// MARK: - CVCalendarViewAppearanceDelegate

extension DashboardVC: CVCalendarViewAppearanceDelegate {
    
    func dayLabelWeekdayDisabledColor() -> UIColor { return .appColor }
    
    func dayLabelPresentWeekdayInitallyBold() -> Bool { return false }
    
    func spaceBetweenDayViews() -> CGFloat { return 5 }
    
    
    func dayLabelFont(by weekDay: Weekday, status: CVStatus, present: CVPresent) -> UIFont { return .custom(size: 9) }
    
    func dayLabelColor(by weekDay: Weekday, status: CVStatus, present: CVPresent) -> UIColor? {
        switch (weekDay, status, present) {
        case (_, .selected, _), (_, .highlighted, _): return ColorsConfig.selectedText
        case (.sunday, .in, _): return ColorsConfig.sundayText
        case (.sunday, _, _): return ColorsConfig.sundayTextDisabled
        case (_, .in, _): return ColorsConfig.text
        default: return ColorsConfig.textDisabled
        }
    }
    
    func dayLabelBackgroundColor(by weekDay: Weekday, status: CVStatus, present: CVPresent) -> UIColor? {
        switch (weekDay, status, present) {
        case (.sunday, .selected, _), (.sunday, .highlighted, _): return ColorsConfig.sundaySelectionBackground
        case (_, .selected, _), (_, .highlighted, _): return ColorsConfig.selectionBackground
        default: return nil
        }
    }
}

extension DashboardVC: UITableViewDelegate,UITableViewDataSource{
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if tableView == announcmentTableView{
            return 50
        } else {
            return 35
        }
        
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 10
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if tableView == announcmentTableView{
            let cell = tableView.dequeueReusableCell(withIdentifier: "AnnouncementCell", for: indexPath) as! AnnouncementCell
            cell.titleLabel.text = "hey there this is testing msg how you all doing \nhey there this is testing msg how you all doing"
            return cell
        } else if tableView == employeeTableView{
            let cell = tableView.dequeueReusableCell(withIdentifier: "EmployeeCell", for: indexPath) as! EmployeeCell
            cell.titleLabel.text = "Tony stark"
            return cell
        } else if tableView == myTaskTableView{
            let cell = tableView.dequeueReusableCell(withIdentifier: "TaskCell", for: indexPath) as! TaskCell
            cell.titleLabel.text = "Task 1"
            cell.detailLabel.text = "Detail text label"
            return cell
        }  else if tableView == companyDetailTableView{
            let cell = tableView.dequeueReusableCell(withIdentifier: "CompanyDetailCell", for: indexPath) as! CompanyDetailCell
            cell.titleLabel.text = "Departments"
            cell.colorLabel.backgroundColor = UIColor.red
            return cell
        } else {
            return UITableViewCell()
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if tableView == announcmentTableView{
            
        } else if tableView == employeeTableView{
            
        } else if tableView == myTaskTableView{
            let controller = ToDoVC.getViewController()
            navigationController?.pushViewController(controller, animated: true)
        }  else if tableView == companyDetailTableView{
            
        } else {
            
        }
    }
    
}

struct ColorsConfig {
    static let selectedText = UIColor.white
    static let text = UIColor.appColor
    static let textDisabled = UIColor.gray
    static let selectionBackground = UIColor.appColor//UIColor(red: 0.2, green: 0.2, blue: 1.0, alpha: 1.0)
    static let sundayText = UIColor.appColor//UIColor(red: 1.0, green: 0.2, blue: 0.2, alpha: 1.0)
    static let sundayTextDisabled = UIColor.gray//UIColor(red: 1.0, green: 0.6, blue: 0.6, alpha: 1.0)
    static let sundaySelectionBackground = sundayText
}
