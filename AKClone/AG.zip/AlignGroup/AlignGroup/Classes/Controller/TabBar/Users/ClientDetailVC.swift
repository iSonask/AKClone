//
//  ClientDetailVC.swift
//  AlignGroup
//
//  Created by Ample on 20/02/19.
//  Copyright © 2019 SHANI SHAH. All rights reserved.
//

import UIKit

class ClientDetailVC: UIViewController,UsersRedirectionProtocol {

    @IBOutlet weak var companyNameTextfld: FormTextField!
    @IBOutlet weak var companyDescriptionLabel: UILabel!
    @IBOutlet weak var companyDescriptionTextView: UITextView!
    @IBOutlet weak var locationTextfld: FormTextField!
    @IBOutlet weak var phoneNumberTextfld: FormTextField!
    @IBOutlet weak var emailAddressTextfld: FormTextField!
    @IBOutlet weak var passwordTextfld: FormTextField!
    @IBOutlet weak var subscriptionTextfld: FormTextField!
    @IBOutlet weak var numberOfUsersTextfld: FormTextField!
    
    @IBOutlet weak var resetButton: UIButton!
    @IBOutlet weak var chooseOtherButton: UIButton!
    @IBOutlet weak var moreDetailsButton: UIButton!
    var keyboard = Keyboard()
    @IBOutlet weak var scrollView: UIScrollView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        configure()
        updateNavigationBarButtons()
    }
    
    func updateNavigationBarButtons() {
        let saveButton = UIBarButtonItem(title: "Save", style: .done, target: self, action: #selector(saveButtonAction))
        self.navigationItem.rightBarButtonItem  = saveButton
    }
    
    @objc func saveButtonAction() {
        
    }
  
    @IBAction func onClickResetButtonAction(_ sender: UIButton) {
    }
    
    @IBAction func onClickChooseOtherButtonAction(_ sender: UIButton) {
    }
    
    @IBAction func onClickMoreDetailsButtonAction(_ sender: UIButton) {
    }
    
}

extension ClientDetailVC{
    func configure()  {
        title = "Client 1"
        self.view.backgroundColor = .appGray
        companyDescriptionLabel.textColor = .appColor
        chooseOtherButton.tintColor = .white
        chooseOtherButton.layer.cornerRadius = 5
        chooseOtherButton.layer.masksToBounds = true
        chooseOtherButton.backgroundColor = .appColor
        chooseOtherButton.layer.borderWidth = 1
        chooseOtherButton.layer.borderColor = UIColor.gray.cgColor
 
        keyboard.addInputView(companyNameTextfld)
        keyboard.addInputView(locationTextfld)
        keyboard.addInputView(phoneNumberTextfld)
        keyboard.addInputView(emailAddressTextfld)
        keyboard.addInputView(passwordTextfld)
        keyboard.addInputView(subscriptionTextfld)
        keyboard.addInputView(numberOfUsersTextfld)
        keyboard.addInputView(companyDescriptionTextView)
        keyboard.delegate = self
        
        companyNameTextfld.placeholder = "Company Name"
        companyNameTextfld.keyboardType = .default
        companyNameTextfld.backgroundColor = .white
        
        companyDescriptionTextView.keyboardType = .default
        
        locationTextfld.placeholder = "Location"
        locationTextfld.keyboardType = .default
        locationTextfld.backgroundColor = .white
        
        phoneNumberTextfld.placeholder = "Phone Number"
        phoneNumberTextfld.keyboardType = .phonePad
        phoneNumberTextfld.backgroundColor = .white
        
        emailAddressTextfld.placeholder = "Email Address"
        emailAddressTextfld.keyboardType = .emailAddress
        emailAddressTextfld.backgroundColor = .white

        passwordTextfld.placeholder = "Password"
        passwordTextfld.keyboardType = .default
        passwordTextfld.backgroundColor = .white

        subscriptionTextfld.placeholder = "Subscription"
        subscriptionTextfld.keyboardType = .default
        subscriptionTextfld.backgroundColor = .white

        numberOfUsersTextfld.placeholder = "No of Users"
        numberOfUsersTextfld.keyboardType = .phonePad
        numberOfUsersTextfld.backgroundColor = .white
    }
}

extension ClientDetailVC: KeyboardDelegate {
    
    func keyboard(_ keyboard: Keyboard, willShow notification: KeyboardNotification) {
        
        if let scrollView = scrollView {
            let contentInset = UIEdgeInsets(top: 0.0, left: 0.0, bottom: notification.frameEnd.height, right: 0.0)
            scrollView.contentInset = contentInset
            scrollView.scrollIndicatorInsets = contentInset
            
            // If active text field is hidden by keyboard, scroll it so it's visible
            // Your app might not need or want this behavior.
            var aRect = view.frame
            aRect.size.height -= notification.frameEnd.height
            
            if let inputView = keyboard.activeField {
                
                let frame = inputView.convert(inputView.frame, from: scrollView)
                if !aRect.contains(frame) {
                    scrollView.scrollRectToVisible(frame, animated: true)
                }
            }
        }
    }
    
    func keyboard(_ keyboard: Keyboard, willHide notification: KeyboardNotification) {
        if let scrollView = scrollView {
            let contentInset = UIEdgeInsets.zero
            scrollView.contentInset = contentInset
            scrollView.scrollIndicatorInsets = contentInset
        }
    }
    
    func keyboard(_ keyboard: Keyboard, didHide notification: KeyboardNotification) {
        if let scrollView = scrollView {
            let contentInset = UIEdgeInsets.zero
            scrollView.contentInset = contentInset
            scrollView.scrollIndicatorInsets = contentInset
        }
    }
}
