//
//  UserDetailVC.swift
//  AlignGroup
//
//  Created by Ample on 21/02/19.
//  Copyright © 2019 SHANI SHAH. All rights reserved.
//

import UIKit

class UserDetailVC: UIViewController,UsersRedirectionProtocol {

    @IBOutlet weak var userImageView: UIImageView!
    @IBOutlet weak var uploadPhotoButton: UIButton!
    @IBOutlet weak var employeeNoTextfld: FormTextField!
    @IBOutlet weak var fullNameTextfld: FormTextField!
    @IBOutlet weak var passwordTextfld: FormTextField!
    @IBOutlet weak var confirmPasswordTextfld: FormTextField!
    @IBOutlet weak var emailTextfld: FormTextField!
    @IBOutlet weak var departmentTextfld: FormTextField!
    @IBOutlet weak var telephoneNoTextfld: FormTextField!
    @IBOutlet weak var roleTextfld: FormTextField!
    @IBOutlet weak var AddressTextfld: FormTextField!
    @IBOutlet weak var maritalStatusTextfld: FormTextField!
    @IBOutlet weak var educationTextfld: FormTextField!
    @IBOutlet weak var skillSetTextfld: FormTextField!
    @IBOutlet weak var employeeTypeTextfld: FormTextField!
    @IBOutlet weak var designationTextfld: FormTextField!
    @IBOutlet weak var reportingToTextfld: FormTextField!
    @IBOutlet weak var countryTextfld: FormTextField!
    @IBOutlet weak var workPermitTextfld: FormTextField!
    @IBOutlet weak var genderTextfld: FormTextField!
    
    var keyboard = Keyboard()
    @IBOutlet weak var scrollView: UIScrollView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        configure()
        updateNavigationBarButtons()
    }
    
    func updateNavigationBarButtons() {
        let saveButton = UIBarButtonItem(title: "Save", style: .done, target: self, action: #selector(saveButtonAction))
        self.navigationItem.rightBarButtonItem  = saveButton
    }
    
    @objc func saveButtonAction() {
        
    }
    
    @IBAction func onClickUploadPhotoAction(_ sender: UIButton) {
        AttachmentHandler.shared.showAttachmentActionSheet(vc: self)
        AttachmentHandler.shared.imagePickedBlock = { (image) in
            /* get your image here */
            //sender.setImage(image, for: .normal)
            self.userImageView.image = image
        }
    }
    
}

extension UserDetailVC{
    func configure()  {
        title = "Users 1"
        self.view.backgroundColor = .appGray
        uploadPhotoButton.tintColor = .white
        uploadPhotoButton.layer.cornerRadius = 5
        uploadPhotoButton.layer.masksToBounds = true
        uploadPhotoButton.backgroundColor = .appColor
        uploadPhotoButton.layer.borderWidth = 1
        uploadPhotoButton.layer.borderColor = UIColor.gray.cgColor
        
        userImageView.backgroundColor = .white
        userImageView.layer.borderWidth = 1
        userImageView.layer.masksToBounds = false
        userImageView.layer.borderColor = UIColor.gray.cgColor
        userImageView.layer.cornerRadius = userImageView.frame.height/2
        userImageView.clipsToBounds = true
        
        keyboard.addInputView(employeeNoTextfld)
        keyboard.addInputView(fullNameTextfld)
        keyboard.addInputView(passwordTextfld)
        keyboard.addInputView(confirmPasswordTextfld)
        keyboard.addInputView(emailTextfld)
        keyboard.addInputView(departmentTextfld)
        keyboard.addInputView(telephoneNoTextfld)
        keyboard.addInputView(roleTextfld)
        keyboard.addInputView(AddressTextfld)
        keyboard.addInputView(maritalStatusTextfld)
        keyboard.addInputView(educationTextfld)
        keyboard.addInputView(skillSetTextfld)
        keyboard.addInputView(employeeTypeTextfld)
        keyboard.addInputView(designationTextfld)
        keyboard.addInputView(reportingToTextfld)
        keyboard.addInputView(countryTextfld)
        keyboard.addInputView(workPermitTextfld)
        keyboard.addInputView(genderTextfld)
        keyboard.delegate = self
        
        employeeNoTextfld.placeholder = "Employee No"
        employeeNoTextfld.keyboardType = .default
        employeeNoTextfld.backgroundColor = .white
        
        fullNameTextfld.placeholder = "Full Name"
        fullNameTextfld.keyboardType = .default
        fullNameTextfld.backgroundColor = .white
        
        passwordTextfld.placeholder = "Password"
        passwordTextfld.keyboardType = .default
        passwordTextfld.backgroundColor = .white
        
        confirmPasswordTextfld.placeholder = "Confirm Password"
        confirmPasswordTextfld.keyboardType = .default
        confirmPasswordTextfld.backgroundColor = .white
        
        emailTextfld.placeholder = "Email"
        emailTextfld.keyboardType = .emailAddress
        emailTextfld.backgroundColor = .white
        
        departmentTextfld.placeholder = "Department"
        departmentTextfld.keyboardType = .default
        departmentTextfld.backgroundColor = .white
        
        telephoneNoTextfld.placeholder = "Telephone No"
        telephoneNoTextfld.keyboardType = .phonePad
        telephoneNoTextfld.backgroundColor = .white
        
        roleTextfld.placeholder = "Role"
        roleTextfld.keyboardType = .default
        roleTextfld.backgroundColor = .white
        
        AddressTextfld.placeholder = "Address"
        AddressTextfld.keyboardType = .default
        AddressTextfld.backgroundColor = .white
        
        maritalStatusTextfld.placeholder = "Marital Status"
        maritalStatusTextfld.keyboardType = .phonePad
        maritalStatusTextfld.backgroundColor = .white
        
        educationTextfld.placeholder = "Education"
        educationTextfld.keyboardType = .default
        educationTextfld.backgroundColor = .white
        
        skillSetTextfld.placeholder = "Skill Set"
        skillSetTextfld.keyboardType = .default
        skillSetTextfld.backgroundColor = .white
        
        employeeTypeTextfld.placeholder = "Employee Type"
        employeeTypeTextfld.keyboardType = .default
        employeeTypeTextfld.backgroundColor = .white
        
        designationTextfld.placeholder = "Designation"
        designationTextfld.keyboardType = .default
        designationTextfld.backgroundColor = .white
        
        reportingToTextfld.placeholder = "Reporting To"
        reportingToTextfld.keyboardType = .default
        reportingToTextfld.backgroundColor = .white
        
        countryTextfld.placeholder = "Country"
        countryTextfld.keyboardType = .default
        countryTextfld.backgroundColor = .white
        
        workPermitTextfld.placeholder = "Work Permit"
        workPermitTextfld.keyboardType = .default
        workPermitTextfld.backgroundColor = .white
        
        genderTextfld.placeholder = "Gender"
        genderTextfld.keyboardType = .default
        genderTextfld.backgroundColor = .white
    }
}

extension UserDetailVC: KeyboardDelegate {
    
    func keyboard(_ keyboard: Keyboard, willShow notification: KeyboardNotification) {
        
        if let scrollView = scrollView {
            let contentInset = UIEdgeInsets(top: 0.0, left: 0.0, bottom: notification.frameEnd.height, right: 0.0)
            scrollView.contentInset = contentInset
            scrollView.scrollIndicatorInsets = contentInset
            
            // If active text field is hidden by keyboard, scroll it so it's visible
            // Your app might not need or want this behavior.
            var aRect = view.frame
            aRect.size.height -= notification.frameEnd.height
            
            if let inputView = keyboard.activeField {
                
                let frame = inputView.convert(inputView.frame, from: scrollView)
                if !aRect.contains(frame) {
                    scrollView.scrollRectToVisible(frame, animated: true)
                }
            }
        }
    }
    
    func keyboard(_ keyboard: Keyboard, willHide notification: KeyboardNotification) {
        if let scrollView = scrollView {
            let contentInset = UIEdgeInsets.zero
            scrollView.contentInset = contentInset
            scrollView.scrollIndicatorInsets = contentInset
        }
    }
    
    func keyboard(_ keyboard: Keyboard, didHide notification: KeyboardNotification) {
        if let scrollView = scrollView {
            let contentInset = UIEdgeInsets.zero
            scrollView.contentInset = contentInset
            scrollView.scrollIndicatorInsets = contentInset
        }
    }
}
