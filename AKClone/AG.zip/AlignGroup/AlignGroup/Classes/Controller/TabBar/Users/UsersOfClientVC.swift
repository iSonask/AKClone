//
//  UsersOfClientVC.swift
//  AlignGroup
//
//  Created by Ample on 19/02/19.
//  Copyright © 2019 SHANI SHAH. All rights reserved.
//

import UIKit

class UsersOfClientVC: UIViewController,UsersRedirectionProtocol {
    
    @IBOutlet weak var searchButton: UIButton!
    @IBOutlet weak var searchView: UIView!
    @IBOutlet weak var searchTextField: UITextField!
    @IBOutlet weak var usersTableview: UITableView!
    let cellSpacingHeight: CGFloat = 6
    
    var usersData = [["name":"Tony Stark","designation":"IRON MAN","image":"iconDashboard"],
                               ["name":"Thor","designation":"God of Thunder","image":"iconDashboard"],
                               ["name":"Hulk","designation":"Increadible Hulk","image":"iconDashboard"],
                               ["name":"Dr. Strange","designation":"Steven Strange","image":"iconDashboard"],
                               ["name":"Spider Man","designation":"Tom holland","image":"iconDashboard"],
                               ["name":"Tony Stark","designation":"IRON MAN","image":"iconDashboard"],
                               ["name":"Tony Stark","designation":"IRON MAN","image":"iconDashboard"]]
    
    override func viewDidLoad() {
        super.viewDidLoad()

        title = "Users of Client 1"
        configure()
        updateNavigationBarButtons()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        self.navigationItem.backBarButtonItem = UIBarButtonItem(title:"", style:.plain, target:nil, action:nil)
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        self.navigationItem.backBarButtonItem = UIBarButtonItem(title:"", style:.plain, target:nil, action:nil)
    }
    
    func updateNavigationBarButtons() {
        let saveButton = UIBarButtonItem(title: "Save", style: .done, target: self, action: #selector(saveButtonAction))
        self.navigationItem.rightBarButtonItem  = saveButton
    }
    
    @objc func saveButtonAction() {
      
    }
}

extension UsersOfClientVC{
    
    func configure()  {
        self.view.backgroundColor = .appGray
        usersTableview.backgroundColor = .appGray
        usersTableview.separatorStyle = .none
        
        searchButton.setImage(UIImage(named: "iconSearch"), for: .normal)
        searchTextField.placeholder = "Search"
        searchTextField.font = .regular()
        searchTextField.textColor = .black
        searchView.layer.cornerRadius = 10
        searchView.layer.masksToBounds = true
        searchView.layer.borderColor = UIColor.gray.cgColor
        searchView.layer.borderWidth = 0.7
    }
}

extension UsersOfClientVC: UITableViewDelegate,UITableViewDataSource{
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 80
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return usersData.count
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        if section == 0{
           return 0
        }
        return cellSpacingHeight
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "UsersOfClientsCell", for: indexPath) as! UsersOfClientsCell
        cell.setupData(data: usersData[indexPath.section])
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let controller = UserDetailVC.getViewController()
        navigationController?.pushViewController(controller, animated: true)
    }
}
