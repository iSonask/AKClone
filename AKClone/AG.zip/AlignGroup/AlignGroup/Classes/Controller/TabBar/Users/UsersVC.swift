//
//  UsersVC.swift
//  AlignGroup
//
//  Created by Ample on 20/02/19.
//  Copyright © 2019 SHANI SHAH. All rights reserved.
//

import UIKit

class UsersVC: UIViewController,UsersRedirectionProtocol {

    @IBOutlet weak var searchButton: UIButton!
    @IBOutlet weak var searchView: UIView!
    @IBOutlet weak var searchTextField: UITextField!
    @IBOutlet weak var usersCollectionView: UICollectionView!
    
    var clientNameArr = ["Client 1","Client 2","Client 3"]
    var clientImageArr = ["alignLogo"," "," "]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Users"
        configure()
        updateNavigationBarButtons()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        self.navigationItem.backBarButtonItem = UIBarButtonItem(title:"", style:.plain, target:nil, action:nil)
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        self.navigationItem.backBarButtonItem = UIBarButtonItem(title:"", style:.plain, target:nil, action:nil)
    }
    
    var notificationButton: MIBadgeButton = {
        let button = MIBadgeButton(type: .custom)
        button.setImage(UIImage(named: "iconNotification"), for: .normal)
        button.badgeTextColor = .appColor
        button.badgeBackgroundColor = .white
        button.badgeEdgeInsets = UIEdgeInsets(top: 4, left: 20, bottom: 0, right: 0)
        
        return button
    }()
    
    
    func updateNavigationBarButtons() {
        
        notificationButton.addAction(for: .touchUpInside) {
            let controller = UsersOfClientVC.getViewController()
            self.navigationController?.pushViewController(controller, animated: true)
        }
        
        notificationButton.badgeString = "10"
        let button = UIBarButtonItem(customView: notificationButton)
        let settingButton = UIBarButtonItem(image: UIImage(named: "iconSetting"),  style: .plain, target: self, action: #selector(handeSettingAction))
        
        navigationItem.rightBarButtonItems = [settingButton,button]
    }
    
    @objc func handeSettingAction() {
        
    }
}

extension UsersVC{
    func configure()  {
        self.view.backgroundColor = .appGray
        usersCollectionView.backgroundColor = .clear
        
        searchButton.setImage(UIImage(named: "iconSearch"), for: .normal)
        searchTextField.placeholder = "Search"
        searchTextField.font = .regular()
        searchTextField.textColor = .black
        searchView.layer.cornerRadius = 10
        searchView.layer.masksToBounds = true
        searchView.layer.borderColor = UIColor.gray.cgColor
        searchView.layer.borderWidth = 0.7
    }
}

extension UsersVC : UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout{
    
    func collectionView(_ collectionView: UICollectionView,layout collectionViewLayout: UICollectionViewLayout,
                        sizeForItemAt indexPath: IndexPath) -> CGSize{
            return CGSize(width: (collectionView.frame.width / 3 ) - 5, height: (collectionView.frame.width / 3 ) - 5)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 5
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 15
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return clientNameArr.count + 1
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        if indexPath.row == clientNameArr.count{
            let cell:AddClientCell = collectionView.dequeueReusableCell(withReuseIdentifier: "AddClientCell", for: indexPath) as! AddClientCell
            
            return cell
        }else{
            let cell:UsersCollectionViewCell = collectionView.dequeueReusableCell(withReuseIdentifier: "UsersCollectionViewCell", for: indexPath) as! UsersCollectionViewCell
            
            cell.clientNameLabel.text = clientNameArr[indexPath.row]
            cell.clientImageView.image = UIImage(named: clientImageArr[indexPath.row])
            
            return cell
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        if indexPath.row != clientNameArr.count{
            let controller = ClientDetailVC.getViewController()
            navigationController?.pushViewController(controller, animated: true)
        }
    }
}
