//
//  PerformanceVC.swift
//  AlignGroup
//
//  Created by SHANI SHAH on 06/02/19.
//  Copyright © 2019 SHANI SHAH. All rights reserved.
//

import UIKit

class PerformanceVC: UIViewController,StoryboardRedirectionProtocol {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

   
}
