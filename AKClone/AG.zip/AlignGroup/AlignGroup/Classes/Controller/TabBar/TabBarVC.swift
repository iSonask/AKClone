//
//  TabBarVC.swift
//  AlignGroup
//
//  Created by SHANI SHAH on 06/02/19.
//  Copyright © 2019 SHANI SHAH. All rights reserved.
//

import UIKit

class TabBarVC: UITabBarController ,StoryboardRedirectionProtocol{

    override func viewDidLoad() {
        super.viewDidLoad()
        UITabBar.appearance().barTintColor = .appGray
        tabBar.layer.shadowColor = UIColor.black.cgColor
        tabBar.layer.shadowOffset = CGSize(width: 0.0, height: 1.0)
        tabBar.layer.shadowRadius = 5
        tabBar.layer.shadowOpacity = 1
        tabBar.layer.masksToBounds = false

        for item in (tabBar.items)!{
            if item.title == "Dashboard"{
                
                item.image = UIImage(named: "iconDashboard")//?.withRenderingMode(.alwaysOriginal)
                item.selectedImage = UIImage(named: "iconDashboard")//?.withRenderingMode(.alwaysOriginal)
            } else if item.title == "Goal"{
                item.image = UIImage(named: "iconGoal")?.withRenderingMode(.alwaysOriginal)
                item.selectedImage = UIImage(named: "iconGoal")?.withRenderingMode(.alwaysOriginal)
            } else if item.title == "Performance"{
                item.image = UIImage(named: "iconPerformance")?.withRenderingMode(.alwaysOriginal)
                item.selectedImage = UIImage(named: "iconPerformance")?.withRenderingMode(.alwaysOriginal)
            } else if item.title == "My Profile"{
                item.image = UIImage(named: "iconMyProfile")?.withRenderingMode(.alwaysOriginal)
                item.selectedImage = UIImage(named: "iconMyProfile")?.withRenderingMode(.alwaysOriginal)
            } else if item.title == "Team"{
                item.image = UIImage(named: "iconTeam")?.withRenderingMode(.alwaysOriginal)
                item.selectedImage = UIImage(named: "iconTeam")?.withRenderingMode(.alwaysOriginal)
            }
        }
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
    }

}
