//
//  MenuVC.swift
//  AlignGroup
//
//  Created by SHANI SHAH on 07/02/19.
//  Copyright © 2019 SHANI SHAH. All rights reserved.
//

import UIKit

class MenuVC: UIViewController,StoryboardRedirectionProtocol {
    
    @IBOutlet weak var userImageView: UIImageView!
    @IBOutlet weak var userNameLabel: UILabel!
    @IBOutlet weak var userEmailAddressLabel: UILabel!
    @IBOutlet weak var userDesignationLabel: UILabel!
    
    @IBOutlet weak var menuTableView: UITableView!
    @IBOutlet weak var logoutButton: UIButton!
    
    var usersData = [["name":"Home","image":"iconDashboard"],
                     ["name":"Users Profile","image":"iconDashboard"],
                     ["name":"Organization Chart","image":"iconDashboard"],
                     ["name":"Tasks","image":"iconDashboard"],
                     ["name":"Performance","image":"iconDashboard"],
                     ["name":"Attendance","image":"iconDashboard"],
                     ["name":"Communication","image":"iconDashboard"],
                     ["name":"Report","image":"iconDashboard"]]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        configure()
    }
    
    @IBAction func onClickLogoutBtnAction(_ sender: UIButton) {
    }
    
}

extension MenuVC{
    func configure(){
        self.menuTableView.backgroundColor = .black
        menuTableView.separatorStyle = .none
        menuTableView.bounces = false
        
        logoutButton.superview?.backgroundColor = .black
        logoutButton.setTitle("Logout", for: .normal)
        logoutButton.tintColor = .white
        logoutButton.titleLabel?.font = .custom(size: 16)
        
        userImageView.layer.borderWidth = 1
        userImageView.layer.masksToBounds = false
        userImageView.layer.borderColor = UIColor.gray.cgColor
        userImageView.layer.cornerRadius = userImageView.frame.height/2
        userImageView.clipsToBounds = true
        
        userNameLabel.text = "Mr.Employee 1"
        userNameLabel.font = .customBold(size: 14)
        
        userEmailAddressLabel.text = "Employee1@gmail.com"
        userEmailAddressLabel.font = .regular()
        
        userDesignationLabel.text = "Designation"
        userDesignationLabel.font = .regular()
    }
}

extension MenuVC: UITableViewDelegate,UITableViewDataSource{
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 60
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return usersData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "MenuCell", for: indexPath) as! MenuCell
        cell.setupData(data: usersData[indexPath.row])
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        if indexPath.row == 7{
            let navController = UINavigationController(rootViewController: ReportVC.getViewController())
            navController.navigationBar.tintColor = .black
            slideMenuController()?.changeMainViewController(navController, close: true)
        }
    }
}

