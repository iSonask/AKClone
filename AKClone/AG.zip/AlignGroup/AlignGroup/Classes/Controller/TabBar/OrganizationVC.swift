//
//  OrganizationVC.swift
//  AlignGroup
//
//  Created by SHANI SHAH on 02/02/19.
//  Copyright © 2019 SHANI SHAH. All rights reserved.
//

import UIKit
import RATreeView

class OrganizationVC: UIViewController,RATreeViewDelegate, RATreeViewDataSource ,StoryboardRedirectionProtocol{
    @IBOutlet weak var filterButton: UIButton!
    
    @IBOutlet weak var containerView: UIView!
    @IBOutlet weak var searchButton: UIButton!
    @IBOutlet weak var searchView: UIView!
    @IBOutlet weak var searchTextField: UITextField!
    var treeView : RATreeView!
    var data : [DataObject] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib. view.backgroundColor = .white
        data = OrganizationVC.commonInit()
        navigationItem.title = "Organization Chart"
        setupTreeView()
        updateNavigationBarButtons()
        addImageToBackground(image: UIImage(named: "loginBg")!)
//        let value =  UIInterfaceOrientation.landscapeLeft.rawValue
//        UIDevice.current.setValue(value, forKey: "orientation")
//        UIViewController.attemptRotationToDeviceOrientation()
        configure()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        self.navigationItem.backBarButtonItem = UIBarButtonItem(title:"", style:.plain, target:nil, action:nil)
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        self.navigationItem.backBarButtonItem = UIBarButtonItem(title:"", style:.plain, target:nil, action:nil)
    }
    
    func configure() {
        
        containerView.backgroundColor = .clear
        searchButton.setImage(UIImage(named: "iconSearch"), for: .normal)
        searchTextField.placeholder = "Search"
        searchTextField.font = .regular()
        searchTextField.textColor = .black
        searchView.layer.cornerRadius = 10
        searchView.layer.masksToBounds = true
        searchView.layer.borderColor = UIColor.gray.cgColor
        searchView.layer.borderWidth = 0.7
        
        filterButton.setImage(UIImage(named: "iconFilter"), for: .normal)
    }
    
    @IBAction func filterButtonAction(_ sender: UIButton){
        print("filterButton")
    }
    
    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        super.viewWillTransition(to: size, with: coordinator)
        if UIDevice.current.orientation.isPortrait {
            print("portrait")
             navigationItem.leftBarButtonItem = nil
        } else {
            print("Landscape")
            let doneButton = UIBarButtonItem(title: "Done", style: .done, target: self, action: #selector(handleDone))
            
            navigationItem.leftBarButtonItem = doneButton
         
        }
    }

    
    @objc func handleDone(){
        let value =  UIInterfaceOrientation.portrait.rawValue
        UIDevice.current.setValue(value, forKey: "orientation")
        UIViewController.attemptRotationToDeviceOrientation()
    }
    
    func setupTreeView() -> Void {
        treeView = RATreeView(frame: containerView.bounds)
        treeView.register(UINib(nibName: String(describing: TreeTableViewCell.self), bundle: nil), forCellReuseIdentifier: String(describing: TreeTableViewCell.self))
        treeView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        treeView.delegate = self
        treeView.dataSource = self
        treeView.treeFooterView = UIView()
        treeView.expandsChildRowsWhenRowExpands = true
        treeView.separatorStyle = RATreeViewCellSeparatorStyleNone
        treeView.backgroundColor = UIColor.clear
        containerView.addSubview(treeView)
        
        for object in data{
            treeView.expandRow(forItem: object)
        }
    }
    var notificationButton: MIBadgeButton = {
        let button = MIBadgeButton(type: .custom)
        button.setImage(UIImage(named: "iconNotification"), for: .normal)
        button.badgeTextColor = .appColor
        button.badgeBackgroundColor = .white
        button.badgeEdgeInsets = UIEdgeInsets(top: 4, left: 20, bottom: 0, right: 0)
        
        return button
    }()
    
    
    func updateNavigationBarButtons() {
        
        notificationButton.addAction(for: .touchUpInside) {
            let controller = UsersVC.getViewController()
            self.navigationController?.pushViewController(controller, animated: true)
        }
        
        notificationButton.badgeString = "10"
        navigationItem.rightBarButtonItem = UIBarButtonItem(customView: notificationButton)
        navigationItem.leftBarButtonItem = UIBarButtonItem(image: UIImage(named: "iconMenu"), style: .done, target: self, action: #selector(toggleLeft))
    }
    
    
    //MARK: RATreeView data source
    
    func treeView(_ treeView: RATreeView, canEditRowForItem item: Any) -> Bool {
        return false
    }
    
    func treeView(_ treeView: RATreeView, heightForRowForItem item: Any) -> CGFloat {
        return 55
    }
    
    func treeView(_ treeView: RATreeView, numberOfChildrenOfItem item: Any?) -> Int {
        if let item = item as? DataObject {
            return item.children.count
        } else {
            return self.data.count
        }
    }
    
    func treeView(_ treeView: RATreeView, child index: Int, ofItem item: Any?) -> Any {
        if let item = item as? DataObject {
            return item.children[index]
        } else {
            return data[index] as AnyObject
        }
    }
    
    func treeView(_ treeView: RATreeView, cellForItem item: Any?) -> UITableViewCell {
        let cell = treeView.dequeueReusableCell(withIdentifier: String(describing: TreeTableViewCell.self)) as! TreeTableViewCell
        let item = item as! DataObject
        cell.backgroundColor = .clear
        let level = treeView.levelForCell(forItem: item)
        let detailsText = "\(item.children.count)"
        cell.selectionStyle = .none
        cell.setup(withTitle: item.name, detailsText: detailsText, level: level, additionalButtonHidden: false)
        cell.deleteButtonActionBlock = { [weak  treeView] cell in
            guard let treeView = treeView else {
                return
            }
            let item = item as! DataObject
            let parent = treeView.parent(forItem: item) as? DataObject
            
            let index: Int
            if let parent = parent {
                index = parent.children.index(where: { dataObject in
                    return dataObject === item
                })!
                parent.removeChild(item)
                
            } else {
                index = self.data.index(where: { dataObject in
                    return dataObject === item
                })!
                self.data.remove(at: index)
            }
            
            self.treeView.deleteItems(at: IndexSet(integer: index), inParent: parent, with: RATreeViewRowAnimationRight)
            if let parent = parent {
                self.treeView.reloadRows(forItems: [parent], with: RATreeViewRowAnimationNone)
            }
        }
        cell.additionButtonActionBlock = { [weak treeView] cell in
            guard let treeView = treeView else {
                return;
            }
            let alert = UIAlertController(title: "Add", message: "Child Data", preferredStyle: .alert)
            
            //2. Add the text field. You can configure it however you need.
            alert.addTextField { (textField) in
                textField.placeholder = "Enter child"
            }
            
            // 3. Grab the value from the text field, and print it when the user clicks OK.
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: { [weak alert] (_) in
                
                let textField = alert!.textFields![0] // Force unwrapping because we know it exists.
                                
                let item = treeView.item(for: cell) as! DataObject
                let newItem = DataObject(name: textField.text!)
                item.addChild(newItem)
                treeView.insertItems(at: IndexSet(integer: item.children.count-1), inParent: item, with: RATreeViewRowAnimationNone);
                treeView.reloadRows(forItems: [item], with: RATreeViewRowAnimationNone)

            }))
            
            // 4. Present the alert.
            self.present(alert, animated: true, completion: nil)

        }
        return cell
    }
    
    //MARK: RATreeView delegate
    
   // func treeView(_ treeView: RATreeView, commit editingStyle: UITableViewCell.EditingStyle, forRowForItem item: Any) {
   //     guard editingStyle == .delete else { return; }
        
   // }
}


private extension OrganizationVC {
    
    static func commonInit() -> [DataObject] {
        let phone1 = DataObject(name: "Phone 1")
        let phone2 = DataObject(name: "Phone 2")
        let phone3 = DataObject(name: "Phone 3")
        let phone4 = DataObject(name: "Phone 4")
        let phones = DataObject(name: "Phones", children: [phone1, phone2, phone3, phone4])
        
        let notebook1 = DataObject(name: "Notebook 1")
        let notebook2 = DataObject(name: "Notebook 2")
        
        let computer1 = DataObject(name: "Computer 1", children: [notebook1, notebook2])
        let computer2 = DataObject(name: "Computer 2")
        let computer3 = DataObject(name: "Computer 3")
        let computers = DataObject(name: "Computers", children: [computer1, computer2, computer3])
        
        let cars = DataObject(name: "Cars")
        let bikes = DataObject(name: "Bikes")
        let houses = DataObject(name: "Houses")
        let flats = DataObject(name: "Flats")
        let motorbikes = DataObject(name: "motorbikes")
        let drinks = DataObject(name: "Drinks")
        let food = DataObject(name: "Food")
        let sweets = DataObject(name: "Sweets")
        let watches = DataObject(name: "Watches")
        let walls = DataObject(name: "Walls")
        
        return [phones, computers, cars, bikes, houses, flats, motorbikes, drinks, food, sweets, watches, walls]
    }
    
}


