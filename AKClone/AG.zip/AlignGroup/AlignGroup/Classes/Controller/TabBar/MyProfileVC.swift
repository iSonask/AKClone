//
//  MyProfileVC.swift
//  AlignGroup
//
//  Created by SHANI SHAH on 06/02/19.
//  Copyright © 2019 SHANI SHAH. All rights reserved.
//

import UIKit

class MyProfileVC: UIViewController,StoryboardRedirectionProtocol {

    @IBOutlet weak var constHeightColorView: NSLayoutConstraint!
    
    @IBOutlet weak var colorView: ThreeColorsGradientView!
    
    @IBOutlet weak var profilePicButton: UIButton!
    @IBOutlet weak var orgChartButton: UIButton!
    @IBOutlet weak var changePasswordButton: UIButton!
    
    @IBOutlet weak var nameTextField: FormTextField!
    @IBOutlet weak var emailTextField: FormTextField!
    @IBOutlet weak var contactNoTextField: FormTextField!
    @IBOutlet weak var emergencyNoTextField: FormTextField!
    @IBOutlet weak var maritalTextField: FormTextField!
    @IBOutlet weak var employementTextField: FormTextField!
    @IBOutlet weak var designationTextField: FormTextField!
    @IBOutlet weak var departmentTextField: FormTextField!
    @IBOutlet weak var educationTextField: FormTextField!
    @IBOutlet weak var pastExpTextField: FormTextField!
    @IBOutlet weak var skillTextField: FormTextField!
    @IBOutlet weak var genderTextField: FormTextField!
    @IBOutlet weak var dobTextField: FormTextField!
    
    @IBOutlet weak var scrollView: UIScrollView!
    var keyboard = Keyboard()
    var editItems = ["Edit","Delete","Logout"]
    var dropDown = DropDown()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        configure()
        self.navigationController?.navigationBar.shadowImage = UIImage()// UIColor.red.as1ptImage()
        self.navigationController?.navigationBar.setBackgroundImage(UIImage(), for: .default)
        
        // Will set a custom width instead of the anchor view width
    }
    
    @IBAction func organizationCharButtonAction(_ sender: UIButton){
        tabBarController?.selectedIndex = 0
    }
    
    @IBAction func changePasswordButtonAction(_ sender: UIButton){
        
    }
    
    @IBAction func profilePicButtonAction(_ sender: UIButton){
        AttachmentHandler.shared.showAttachmentActionSheet(vc: self)
        AttachmentHandler.shared.imagePickedBlock = { (image) in
            /* get your image here */
            sender.setImage(image, for: .normal)
        }
    }
}

extension MyProfileVC {
    
    func configure() {
        
        title = "My Profile"
        
        keyboard.addInputView(nameTextField)
        keyboard.addInputView(emailTextField)
        keyboard.addInputView(contactNoTextField)
        keyboard.addInputView(emergencyNoTextField)
        keyboard.addInputView(maritalTextField)
        keyboard.addInputView(employementTextField)
        keyboard.addInputView(designationTextField)
        keyboard.addInputView(departmentTextField)
        keyboard.addInputView(educationTextField)
        keyboard.addInputView(pastExpTextField)
        keyboard.addInputView(skillTextField)
        keyboard.addInputView(genderTextField)
        keyboard.addInputView(dobTextField)
        keyboard.delegate = self
        
        changePasswordButton.backgroundColor = .appLightOrange
        changePasswordButton.titleLabel?.numberOfLines = 2
        changePasswordButton.titleLabel?.textAlignment = .center
        changePasswordButton.setTitle("Change\nPassword", for: .normal)
        changePasswordButton.titleLabel?.font = .bold()
        changePasswordButton.setTitleColor(.black, for: .normal)
        changePasswordButton.layer.cornerRadius = 5
        
        orgChartButton.layer.cornerRadius = 5
        orgChartButton.backgroundColor = .appLightOrange
        orgChartButton.titleLabel?.numberOfLines = 2
        orgChartButton.titleLabel?.textAlignment = .center
        orgChartButton.setTitle("Organization\nChart", for: .normal)
        orgChartButton.titleLabel?.font = .bold()
        orgChartButton.setTitleColor(.black, for: .normal)
        
        colorView.bounds.origin.x = -(view.frame.width / 2)
        constHeightColorView.constant = view.frame.width
        colorView.layer.cornerRadius = view.frame.width / 2
        colorView.layer.masksToBounds = true
        
        profilePicButton.layer.cornerRadius = profilePicButton.frame.width / 2
        profilePicButton.layer.masksToBounds = true
        profilePicButton.layer.borderColor = UIColor.black.cgColor
        profilePicButton.layer.borderWidth = 1.0
        profilePicButton.backgroundColor = .white
        
        let editButton = UIBarButtonItem(image: UIImage(named: "iconEdit"), style: .done, target: self, action: #selector(handeEditAction))
        self.navigationItem.rightBarButtonItem = editButton
        
        dropDown.dataSource = editItems
        dropDown.width = 140
        dropDown.textFont = .regular()
//        dropDown.bottomOffset = CGPoint(x: 0, y:(navigationItem.rightBarButtonItem.bounds.height)!)

        dropDown.direction = .bottom
        dropDown.anchorView = editButton
        
        dropDown.selectionAction = { [unowned self] (index: Int, item: String) in
            print("Selected item: \(item) at index: \(index)")
            self.dropDown.hide()
        }
        
        navigationItem.leftBarButtonItem = UIBarButtonItem(image: UIImage(named: "iconMenu"), style: .done, target: self, action: #selector(toggleLeft))
        
        nameTextField.placeholder = "Name"
        nameTextField.keyboardType = .default
        
        emailTextField.placeholder = "Email"
        emailTextField.keyboardType = .emailAddress
        
        contactNoTextField.placeholder = "Contact Number"
        contactNoTextField.keyboardType = .phonePad
        
        emergencyNoTextField.placeholder = "Emergency Contact Number"
        emergencyNoTextField.keyboardType = .phonePad
        
        maritalTextField.placeholder = "Marital Status"
        maritalTextField.keyboardType = .default
        
        employementTextField.placeholder = "Employement Type"
        employementTextField.keyboardType = .default
        
        designationTextField.placeholder = "Designation"
        designationTextField.keyboardType = .default
        
        departmentTextField.placeholder = "Department"
        departmentTextField.keyboardType = .default
        
        educationTextField.placeholder = "Education"
        educationTextField.keyboardType = .default
        
        pastExpTextField.placeholder = "Past Experience"
        pastExpTextField.keyboardType = .default
        
        skillTextField.placeholder = "Skills"
        skillTextField.keyboardType = .default
        
        genderTextField.placeholder = "Gender"
        genderTextField.keyboardType = .default
        
        dobTextField.placeholder = "Date of Birth"
        dobTextField.keyboardType = .default
    }
    
    @objc func handeEditAction() {
        print("edit")
        dropDown.show()
    }
    
//    fileprivate func validateLoginForm() -> Bool {
//        hideActivity()
//        var inputView: Any?
//        var message: String?
//        
//        if emailTextField.text!.isEmpty {
//            
//            inputView = emailTextField
//            message = "Email can not be empty"
//            
//        }else if !emailTextField.text!.isValidEmail {
//            
//            inputView = emailTextField
//            message = "Email not valid"
//            
//        }else if passwordTextField.text!.isEmpty {
//            
//            inputView = passwordTextField
//            message = "Password can not be empty"
//            
//        }else{
//            
//            inputView = nil
//            message = nil
//        }
//        
//        if let message = message {
//            
//            let alert = UIAlertController(title: "Error", message: message, preferredStyle: .alert)
//            
//            alert.addAction(UIAlertAction(title:"Ok", style: .cancel, handler: { (action) in
//                
//                if let textField = inputView as! UITextField? {
//                    textField.becomeFirstResponder()
//                }
//                
//            }))
//            
//            present(alert, animated: true, completion: nil)
//            
//            return false
//        }else{
//            return true
//        }
//        
//    }
}

extension MyProfileVC: KeyboardDelegate {
    
    func keyboard(_ keyboard: Keyboard, willShow notification: KeyboardNotification) {
        
        if let scrollView = scrollView {
            let contentInset = UIEdgeInsets(top: 0.0, left: 0.0, bottom: notification.frameEnd.height, right: 0.0)
            scrollView.contentInset = contentInset
            scrollView.scrollIndicatorInsets = contentInset
            
            // If active text field is hidden by keyboard, scroll it so it's visible
            // Your app might not need or want this behavior.
            var aRect = view.frame
            aRect.size.height -= notification.frameEnd.height
            
            if let inputView = keyboard.activeField {
                
                let frame = inputView.convert(inputView.frame, from: scrollView)
                if !aRect.contains(frame) {
                    scrollView.scrollRectToVisible(frame, animated: true)
                }
            }
        }
    }
    
    func keyboard(_ keyboard: Keyboard, willHide notification: KeyboardNotification) {
        if let scrollView = scrollView {
            let contentInset = UIEdgeInsets.zero
            scrollView.contentInset = contentInset
            scrollView.scrollIndicatorInsets = contentInset
        }
    }
    
    func keyboard(_ keyboard: Keyboard, didHide notification: KeyboardNotification) {
        if let scrollView = scrollView {
            let contentInset = UIEdgeInsets.zero
            scrollView.contentInset = contentInset
            scrollView.scrollIndicatorInsets = contentInset
        }
    }
}
