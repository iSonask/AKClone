//
//  CalendarVC.swift
//  AlignGroup
//
//  Created by SHANI SHAH on 13/02/19.
//  Copyright © 2019 SHANI SHAH. All rights reserved.
//

import UIKit
import CalendarKit
import DateToolsSwift

class CalendarVC: UIViewController,CalendarRedirectionProtocol{
    
    @IBOutlet weak var calendarDayView: DayView!
    var data = [["Breakfast at Tiffany's",
                 "New York, 5th avenue"],
                
                ["Workout",
                 "Tufteparken"],
                
                ["Meeting with Alex",
                 "Home",
                 "Oslo, Tjuvholmen"],
                
                ["Beach Volleyball",
                 "Ipanema Beach",
                 "Rio De Janeiro"],
                
                ["WWDC",
                 "Moscone West Convention Center",
                 "747 Howard St"],
                
                ["Google I/O",
                 "Shoreline Amphitheatre",
                 "One Amphitheatre Parkway"],
                
                ["✈️️ to Svalbard ❄️️❄️️❄️️❤️️",
                 "Oslo Gardermoen"],
                
                ["💻📲 Developing CalendarKit",
                 "🌍 Worldwide"],
                
                ["Software Development Lecture",
                 "Mikpoli MB310",
                 "Craig Federighi"],
                
                ]
    
    var colors = [UIColor.blue,
                  UIColor.yellow,
                  UIColor.green,
                  UIColor.red]
    var currentStyle = SelectedStyle.Light
    
    @IBOutlet weak var tasksLabel: UILabel!
    var isEmptyEvent = false
    @IBOutlet weak var constHeightCalendarView: NSLayoutConstraint!
    @IBOutlet weak var meetingTableView: UITableView!
    @IBOutlet weak var categoryButton: UIButton!

    var selectedEvents = ["Upcoming","Completed / Cancelled / Declined","Send","Follow Up Tasks"]
    var dropDown = DropDown()
    
    @IBOutlet weak var meetingButton: UIButton!
    @IBOutlet weak var calendarButton: UIButton!
    @IBOutlet weak var monthLabel: UILabel!
    @IBOutlet weak var calendarContainerView: UIView!
    @IBOutlet weak var calenderView: CVCalendarView!
    @IBOutlet weak var eventTableView: UITableView!
    @IBOutlet weak var menuView: CVCalendarMenuView!
    @IBOutlet weak var monthButton: UIButton!
    @IBOutlet weak var dayButton: UIButton!
    @IBOutlet weak var weekButton: UIButton!
    @IBOutlet weak var scheduleButton: UIButton!
    
    private var randomNumberOfDotMarkersForDay = [Int]()
    private var shouldShowDaysOut = false
    private var animationFinished = true
    private var selectedDay: DayView1!
    private var currentCalendar: Calendar?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Calendar"
        configure()
        
        updateNavigationBarButtons()
    }
    
    func updateNavigationBarButtons() {
        let notificationButton = UIBarButtonItem(image: UIImage(named: "iconNotification"), style: .done, target: self, action: #selector(handeNotificationAction))
        let addButton = UIBarButtonItem(image: UIImage(named: "iconAdd"), style: .done, target: self, action: #selector(handleAddAction))
        self.navigationItem.rightBarButtonItems = [addButton,notificationButton]
       
    }
    
    @objc func handeNotificationAction() {
        print("notification")
    }
    
    @objc func handleAddAction() {
        print("add")
        let controller = BookaMeetingVC.getViewController() as! BookaMeetingVC
        controller.titleString = "Add Meeting"
        navigationController?.pushViewController(controller, animated: true)
    }

    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        self.navigationItem.backBarButtonItem = UIBarButtonItem(title:"", style:.plain, target:nil, action:nil)

    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        self.navigationItem.backBarButtonItem = UIBarButtonItem(title:"", style:.plain, target:nil, action:nil)
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        
        calenderView.commitCalendarViewUpdate()
        menuView.commitMenuViewUpdate()
    }
    
    @IBAction func weekButtonAction(_ sender: UIButton) {
        weekButton.backgroundColor = .appLightOrange
        weekButton.setTitleColor(.black, for: .normal)
        dayButton.backgroundColor = .white
        dayButton.setTitleColor(.appColor, for: .normal)
        monthButton.backgroundColor = .white
        monthButton.setTitleColor(.appColor, for: .normal)
        scheduleButton.backgroundColor = .white
        scheduleButton.setTitleColor(.appColor, for: .normal)
        calenderView.changeMode(.weekView)
        constHeightCalendarView = constHeightCalendarView.setMultiplier(multiplier: 0.20)
        calendarDayView.isHidden = false
        eventTableView.isHidden = true
        changeData(date: Date())
    }
    
    @IBAction func dayButtonAction(_ sender: UIButton) {
        weekButton.backgroundColor = .white
        weekButton.setTitleColor(.appColor, for: .normal)
        dayButton.backgroundColor = .appLightOrange
        dayButton.setTitleColor(.black, for: .normal)
        monthButton.backgroundColor = .white
        monthButton.setTitleColor(.appColor, for: .normal)
        scheduleButton.backgroundColor = .white
        scheduleButton.setTitleColor(.appColor, for: .normal)
        calenderView.changeMode(.weekView)
        constHeightCalendarView = constHeightCalendarView.setMultiplier(multiplier: 0.20)
        calendarDayView.isHidden = false
        eventTableView.isHidden = true
        changeData(date: Date())
    }
    
    @IBAction func monthButtonAction(_ sender: UIButton) {
        weekButton.backgroundColor = .white
        weekButton.setTitleColor(.appColor, for: .normal)
        dayButton.backgroundColor = .white
        dayButton.setTitleColor(.appColor, for: .normal)
        monthButton.backgroundColor = .appLightOrange
        monthButton.setTitleColor(.black, for: .normal)
        scheduleButton.backgroundColor = .white
        scheduleButton.setTitleColor(.appColor, for: .normal)
        calenderView.changeMode(.monthView)
        constHeightCalendarView = constHeightCalendarView.setMultiplier(multiplier: 0.4)
        calendarDayView.isHidden = true
        eventTableView.isHidden = false
        isEmptyEvent = false
        eventTableView.reloadData()
    }
    
    @IBAction func scheduleButtonAction(_ sender: UIButton) {
        constHeightCalendarView = constHeightCalendarView.setMultiplier(multiplier: 0.4)
        weekButton.backgroundColor = .white
        weekButton.setTitleColor(.appColor, for: .normal)
        dayButton.backgroundColor = .white
        dayButton.setTitleColor(.appColor, for: .normal)
        monthButton.backgroundColor = .white
        monthButton.setTitleColor(.appColor, for: .normal)
        scheduleButton.backgroundColor = .appLightOrange
        scheduleButton.setTitleColor(.black, for: .normal)
        changeData(date: Date())
        calenderView.changeMode(.monthView)
        calendarDayView.isHidden = true
        eventTableView.isHidden = false
        isEmptyEvent = true
        eventTableView.reloadData()
    }
    
    @IBAction func calendarButtonAction(_ sender: UIButton) {
        calendarButton.backgroundColor = .black
        calendarButton.setTitle("Calendar", for: .normal)
        calendarButton.setTitleColor(.white, for: .normal)
        
        meetingButton.backgroundColor = .white
        meetingButton.setTitle("Meeting", for: .normal)
        meetingButton.setTitleColor(.appColor, for: .normal)
        view.sendSubviewToBack(eventTableView)
        eventTableView.isHidden = true
        calendarContainerView.isHidden = false
        view.bringSubviewToFront(calendarContainerView)
    }
    
    @IBAction func meetingButtonAction(_ sender: UIButton) {
        calendarButton.backgroundColor = .white
        calendarButton.setTitle("Calendar", for: .normal)
        calendarButton.setTitleColor(.appColor, for: .normal)
        
        meetingButton.backgroundColor = .black
        meetingButton.setTitle("Meeting", for: .normal)
        meetingButton.setTitleColor(.white, for: .normal)
        view.sendSubviewToBack(calendarContainerView)
        view.bringSubviewToFront(eventTableView)
        eventTableView.isHidden = false
        calendarContainerView.isHidden = true
    }
    
    @IBAction func categoryButtonAction(_ sender: UIButton) {
        dropDown.show()
        dropDown.selectionAction = { [unowned self] (index: Int, item: String) in
            print("Selected item: \(item) at index: \(index)")
            sender.setTitle(item, for: .normal)
            self.dropDown.hide()
        }
        
    }
    
    func configure()  {
        tasksLabel.text = "1 tasks are over due >"
        tasksLabel.font = .regular()
        
        
        calendarButton.backgroundColor = .black
        calendarButton.setTitle("Calendar", for: .normal)
        calendarButton.setTitleColor(.white, for: .normal)
        calendarButton.roundBottomCorners(radius: 5)
        
        meetingButton.backgroundColor = .white
        meetingButton.setTitle("Meeting", for: .normal)
        meetingButton.setTitleColor(.appColor, for: .normal)
        meetingButton.roundBottomCorners(radius: 5)
        
        meetingTableView.backgroundColor = .appGray
        meetingTableView.separatorStyle = .none
        meetingTableView.contentOffset = .zero
        meetingTableView.tableFooterView = UIView()
        
        
        eventTableView.separatorStyle = .none
        eventTableView.tableFooterView = UIView()
        eventTableView.contentOffset = .zero
        
        monthLabel.text = CVDate(date: Date()).commonDescription
        calendarDayView.dataSource = self
        calendarDayView.delegate = self
        calendarDayView.isHeaderViewVisible = false
        
        weekButton.setTitle("By Week", for: .normal)
        monthButton.setTitle("By Month", for: .normal)
        dayButton.setTitle("By Day", for: .normal)
        scheduleButton.setTitle("By Schedule", for: .normal)
        
        constHeightCalendarView = constHeightCalendarView.setMultiplier(multiplier: 0.4)
        weekButton.titleLabel?.font = .custom(size: 10)
        dayButton.titleLabel?.font = .custom(size: 10)
        monthButton.titleLabel?.font = .custom(size: 10)
        scheduleButton.titleLabel?.font = .custom(size: 10)
        
        weekButton.backgroundColor = .white
        weekButton.setTitleColor(.appColor, for: .normal)
        dayButton.backgroundColor = .white
        dayButton.setTitleColor(.appColor, for: .normal)
        monthButton.backgroundColor = .appLightOrange
        monthButton.setTitleColor(.black, for: .normal)
        scheduleButton.backgroundColor = .white
        scheduleButton.setTitleColor(.appColor, for: .normal)
        
        
        
        view.bringSubviewToFront(calendarContainerView)
        
        calendarDayView.isHidden = true
        eventTableView.isHidden = false
        view.sendSubviewToBack(eventTableView)
        view.bringSubviewToFront(calendarContainerView)
        
        calendarContainerView.backgroundColor = .white
        
        // Do any additional setup after loading the view.
//        listTableView.backgroundColor = .clear
//        listTableView.tableFooterView = UIView()
//        listTableView.contentOffset = .zero
//        listTableView.separatorStyle = .none
        
        eventTableView.backgroundColor = .clear
        eventTableView.tableFooterView = UIView()
        eventTableView.contentOffset = .zero
        eventTableView.separatorStyle = .none
        
        addImageToBackground(image: UIImage(named: "loginBg")!)
        view.backgroundColor = .clear
        
        categoryButton.setImage(UIImage(named: "iconDown")?.maskWithColor(color: .appGreen), for: .normal)
        categoryButton.setTitle("Upcoming", for: .normal)
        categoryButton.setTitleColor(.appGreen, for: .normal)
        categoryButton.titleLabel?.font = .custom(size : 10)
        
        dropDown.anchorView = categoryButton
        dropDown.dataSource = selectedEvents
        dropDown.width = meetingTableView.frame.width
        dropDown.cellHeight = 30
        dropDown.textFont = .custom(size : 12)
        dropDown.backgroundColor = UIColor.white
        dropDown.textColor = .appGreen
        dropDown.direction = .bottom
        
        meetingButton.superview?.addBottomShadow()
        
        eventTableView.isHidden = true
        calendarContainerView.isHidden = false
    }
    
    //CalendarKIT
    func reloadData() {
        calendarDayView.reloadData()
    }
    
    func updateStyle(_ newStyle: CalendarStyle) {
        calendarDayView.updateStyle(newStyle)
    }
    
    @objc func changeStyle() {
        var style: CalendarStyle!
        
        if currentStyle == .Dark {
            currentStyle = .Light

            style = StyleGenerator.defaultStyle()
        } else {

            style = StyleGenerator.darkStyle()
            currentStyle = .Dark
        }
        updateStyle(style)
        reloadData()
    }
    
    func changeData(date: Date) {
        calendarDayView.state?.move(to: date)
    }
    
    private func textColorForEventInDarkTheme(baseColor: UIColor) -> UIColor {
        var h: CGFloat = 0, s: CGFloat = 0, b: CGFloat = 0, a: CGFloat = 0
        baseColor.getHue(&h, saturation: &s, brightness: &b, alpha: &a)
        return UIColor(hue: h, saturation: s * 0.3, brightness: b, alpha: a)
    }
    
}

extension CalendarVC: UITableViewDelegate,UITableViewDataSource{
    
    func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if tableView == eventTableView{
            return 120
        } else {
            return 190
        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if tableView == eventTableView{
            return 1
        } else {
            return 19
        }
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if tableView == eventTableView{
            
            if isEmptyEvent{
                let cell = tableView.dequeueReusableCell(withIdentifier: "EmptyEventCell", for: indexPath) as! EmptyEventCell
                
                cell.titleLabel.text = "Set Up Your to-do List"
                
                return cell
            } else {
                let cell = tableView.dequeueReusableCell(withIdentifier: "EventCell", for: indexPath) as! EventCell
                cell.timeDescription.text = "Another event to attend"
                cell.timeLabel.text = "\(Date().format(with: "HH:mm"))\n\(Date().format(with: "HH:mm"))"
                
                cell.currentTimeLabel.text = "\(Date().format(with: "HH:mm"))"
                cell.dayDescriptionLabel.text = "Daily Call with employee"
                return cell
            }
        } else {
            let cell = tableView.dequeueReusableCell(withIdentifier: "MeetingCell", for: indexPath) as! MeetingCell
            
            cell.setupData()
            
            return cell
        }
    
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
    }
}

extension CalendarVC: EventDataSource,DayViewDelegate{
    
    func dayView(dayView: DayView, willMoveTo date: Date) {
        print(date)
    }
    
    func dayView(dayView: DayView, didMoveTo date: Date) {
        print(date)
        calenderView.toggleViewWithDate(date)
    }
    
    
    func eventsForDate(_ date: Date) -> [EventDescriptor] {
        
        var date = date.add(TimeChunk.dateComponents(hours: Int(arc4random_uniform(10) + 5)))
        var events = [Event]()
        
        for i in 0...4 {
            let event = Event()
            let duration = Int(arc4random_uniform(160) + 60)
            let datePeriod = TimePeriod(beginning: date,
                                        chunk: TimeChunk.dateComponents(minutes: duration))
            
            event.startDate = datePeriod.beginning!
            event.endDate = datePeriod.end!
            
            var info = data[Int(arc4random_uniform(UInt32(data.count)))]
            
            let timezone = TimeZone.ReferenceType.default
            info.append(datePeriod.beginning!.format(with: "dd.MM.YYYY", timeZone: timezone))
            info.append("\(datePeriod.beginning!.format(with: "HH:mm", timeZone: timezone)) - \(datePeriod.end!.format(with: "HH:mm", timeZone: timezone))")
            event.text = info.reduce("", {$0 + $1 + "\n"})
            event.color = colors[Int(arc4random_uniform(UInt32(colors.count)))]
            event.isAllDay = Int(arc4random_uniform(2)) % 2 == 0
            
            // Event styles are updated independently from CalendarStyle
            // hence the need to specify exact colors in case of Dark style
            if currentStyle == .Dark {
                event.textColor = textColorForEventInDarkTheme(baseColor: event.color)
                event.backgroundColor = event.color.withAlphaComponent(0.6)
            }
            
            events.append(event)
            
            let nextOffset = Int(arc4random_uniform(250) + 40)
            date = date.add(TimeChunk.dateComponents(minutes: nextOffset))
            event.userInfo = String(i)
        }
        
        return events
    }
    
    func dayViewDidLongPressTimelineAtHour(_ hour: Int) {
        print(hour)
    }
    
    func dayViewDidSelectEventView(_ eventView: EventView) {
        guard let descriptor = eventView.descriptor as? Event else {
            return
        }
        print("Event has been selected: \(descriptor) \(String(describing: descriptor.userInfo))")
    }
    
    func dayViewDidLongPressEventView(_ eventView: EventView) {
        guard let descriptor = eventView.descriptor as? Event else {
            return
        }
        print("Event has been longPressed: \(descriptor) \(String(describing: descriptor.userInfo))")
    }
    
}

extension CalendarVC {
    
    func toggleMonthViewWithMonthOffset(offset: Int) {
        guard let currentCalendar = currentCalendar else { return }
        
        var components = Manager.componentsForDate(Date(), calendar: currentCalendar) // from today
        
        components.month! += offset
        
        let resultDate = currentCalendar.date(from: components)!
        
        self.calenderView.toggleViewWithDate(resultDate)
    }
    
    func didShowNextMonthView(_ date: Date) {
        guard let currentCalendar = currentCalendar else { return }
        
        let components = Manager.componentsForDate(date, calendar: currentCalendar) // from today
        
        print("Showing Month: \(components.month!)")
    }
    
    func didShowPreviousMonthView(_ date: Date) {
        guard let currentCalendar = currentCalendar else { return }
        
        let components = Manager.componentsForDate(date, calendar: currentCalendar) // from today
        
        print("Showing Month: \(components.month!)")
    }
    
    func didShowNextWeekView(from startDayView: DayView1, to endDayView: DayView1) {
        print("Showing Week: from \(startDayView.date.day) to \(endDayView.date.day)")
    }
    
    func didShowPreviousWeekView(from startDayView: DayView1, to endDayView: DayView1) {
        print("Showing Week: from \(startDayView.date.day) to \(endDayView.date.day)")
    }
    
}

extension CalendarVC: CVCalendarViewDelegate, CVCalendarMenuViewDelegate {
    
    // MARK: Required methods
    
    func presentationMode() -> CalendarMode { return .monthView }
    
    func firstWeekday() -> Weekday { return .sunday }
    
    // MARK: Optional methods
    
    func calendar() -> Calendar? { return currentCalendar }
    
    func dayOfWeekTextColor(by weekday: Weekday) -> UIColor {
        return weekday == .sunday ? UIColor.appColor : UIColor.appColor
    }
    
    func shouldShowWeekdaysOut() -> Bool { return shouldShowDaysOut }
    
    // Defaults to true
    func shouldAnimateResizing() -> Bool { return true }
    
    private func shouldSelectDayView(dayView: DayView) -> Bool {
        return arc4random_uniform(3) == 0 ? true : false
    }
    
    func shouldAutoSelectDayOnMonthChange() -> Bool { return false }
    
    func didSelectDayView(_ dayView: CVCalendarDayView, animationDidFinish: Bool) {
        print(dayView.date.convertedDate()!)
        changeData(date: dayView.date.convertedDate()!)
        selectedDay = dayView
    }
    
    func shouldSelectRange() -> Bool { return false }
    
    func didSelectRange(from startDayView: DayView1, to endDayView: DayView1) {
        print("RANGE SELECTED: \(startDayView.date.commonDescription) to \(endDayView.date.commonDescription)")
    }
    
    func presentedDateUpdated(_ date: CVDate) {
        if monthLabel.text != date.globalDescription && self.animationFinished {
            let updatedMonthLabel = UILabel()
            updatedMonthLabel.textColor = .appColor
            updatedMonthLabel.font = .bold()
            updatedMonthLabel.textAlignment = .center
            updatedMonthLabel.text = date.globalDescription
            updatedMonthLabel.sizeToFit()
            updatedMonthLabel.alpha = 0
            updatedMonthLabel.center = self.monthLabel.center
            
            let offset = CGFloat(48)
            updatedMonthLabel.transform = CGAffineTransform(translationX: 0, y: offset)
            updatedMonthLabel.transform = CGAffineTransform(scaleX: 1, y: 0.1)
            
            UIView.animate(withDuration: 0.35, delay: 0, options: UIView.AnimationOptions.curveEaseIn, animations: {
                self.animationFinished = false
                self.monthLabel.transform = CGAffineTransform(translationX: 0, y: -offset)
                self.monthLabel.transform = CGAffineTransform(scaleX: 1, y: 0.1)
                self.monthLabel.alpha = 0
                
                updatedMonthLabel.alpha = 1
                updatedMonthLabel.transform = CGAffineTransform.identity
                
            }) { _ in
                
                self.animationFinished = true
                self.monthLabel.frame = updatedMonthLabel.frame
                self.monthLabel.text = updatedMonthLabel.text
                self.monthLabel.transform = CGAffineTransform.identity
                self.monthLabel.alpha = 1
                updatedMonthLabel.removeFromSuperview()
            }
            
            self.view.insertSubview(updatedMonthLabel, aboveSubview: self.monthLabel)
        }
    }
    
    func topMarker(shouldDisplayOnDayView dayView: CVCalendarDayView) -> Bool { return false }
    
    func weekdaySymbolType() -> WeekdaySymbolType { return .short }
    
    func selectionViewPath() -> ((CGRect) -> (UIBezierPath)) {
        return { UIBezierPath(rect: CGRect(x: 0, y: 0, width: $0.width, height: $0.height)) }
    }
    
    func shouldShowCustomSingleSelection() -> Bool { return false }
    
    func preliminaryView(viewOnDayView dayView: DayView1) -> UIView {
        let circleView = CVAuxiliaryView(dayView: dayView, rect: dayView.frame, shape: CVShape.circle)
        circleView.fillColor = .colorFromCode(0xBBBBBB)
        return circleView
    }
    
    func preliminaryView(shouldDisplayOnDayView dayView: DayView1) -> Bool {
        if (dayView.isCurrentDay) {
            return true
        }
        return false
    }
    
    //    func supplementaryView(viewOnDayView dayView: DayView) -> UIView {
    //
    //        dayView.setNeedsLayout()
    //        dayView.layoutIfNeeded()
    //
    //        let π = Double.pi
    //
    //        let ringLayer = CAShapeLayer()
    //        let ringLineWidth: CGFloat = 4.0
    //        let ringLineColour = UIColor.blue
    //
    //        let newView = UIView(frame: dayView.frame)
    //
    //        let diameter = (min(newView.bounds.width, newView.bounds.height))
    //        let radius = diameter / 2.0 - ringLineWidth
    //
    //        newView.layer.addSublayer(ringLayer)
    //
    //        ringLayer.fillColor = nil
    //        ringLayer.lineWidth = ringLineWidth
    //        ringLayer.strokeColor = ringLineColour.cgColor
    //
    //        let centrePoint = CGPoint(x: newView.bounds.width/2.0, y: newView.bounds.height/2.0)
    //        let startAngle = CGFloat(-π/2.0)
    //        let endAngle = CGFloat(π * 2.0) + startAngle
    //        let ringPath = UIBezierPath(arcCenter: centrePoint,
    //                                    radius: radius,
    //                                    startAngle: startAngle,
    //                                    endAngle: endAngle,
    //                                    clockwise: true)
    //
    //        ringLayer.path = ringPath.cgPath
    //        ringLayer.frame = newView.layer.bounds
    //
    //        return newView
    //    }
    //
    //    func supplementaryView(shouldDisplayOnDayView dayView: DayView) -> Bool {
    //        guard let currentCalendar = currentCalendar else { return false }
    //
    //        var components = Manager.componentsForDate(Foundation.Date(), calendar: currentCalendar)
    //
    //        /* For consistency, always show supplementaryView on the 3rd, 13th and 23rd of the current month/year.  This is to check that these expected calendar days are "circled". There was a bug that was circling the wrong dates. A fix was put in for #408 #411.
    //
    //         Other month and years show random days being circled as was done previously in the Demo code.
    //         */
    //        var shouldDisplay = false
    //        if dayView.date.year == components.year &&
    //            dayView.date.month == components.month {
    //
    //            if (dayView.date.day == 3 || dayView.date.day == 13 || dayView.date.day == 23)  {
    //                print("Circle should appear on " + dayView.date.commonDescription)
    //                shouldDisplay = true
    //            }
    //        } else if (Int(arc4random_uniform(3)) == 1) {
    //            shouldDisplay = true
    //        }
    //
    //        return shouldDisplay
    //    }
    
    
    func disableScrollingBeforeDate() -> Date { return Date() }
    
    func maxSelectableRange() -> Int { return 14 }
    
    func earliestSelectableDate() -> Date { return Date() }
    
    //    func latestSelectableDate() -> Date {
    //        var dayComponents = DateComponents()
    //        dayComponents.day = 70
    //        let calendar = Calendar(identifier: .gregorian)
    //        if let lastDate = calendar.date(byAdding: dayComponents, to: Date()) {
    //            return lastDate
    //        }
    //
    //        return Date()
    //    }
}


// MARK: - CVCalendarViewAppearanceDelegate

extension CalendarVC: CVCalendarViewAppearanceDelegate {
    
    func dayLabelWeekdayDisabledColor() -> UIColor { return .appColor }
    
    func dayLabelPresentWeekdayInitallyBold() -> Bool { return false }
    
    func spaceBetweenDayViews() -> CGFloat { return 5 }
    
    
    func dayLabelFont(by weekDay: Weekday, status: CVStatus, present: CVPresent) -> UIFont { return .custom(size: 9) }
    
    func dayLabelColor(by weekDay: Weekday, status: CVStatus, present: CVPresent) -> UIColor? {
        switch (weekDay, status, present) {
        case (_, .selected, _), (_, .highlighted, _): return ColorsConfig.selectedText
        case (.sunday, .in, _): return ColorsConfig.sundayText
        case (.sunday, _, _): return ColorsConfig.sundayTextDisabled
        case (_, .in, _): return ColorsConfig.text
        default: return ColorsConfig.textDisabled
        }
    }
    
    func dayLabelBackgroundColor(by weekDay: Weekday, status: CVStatus, present: CVPresent) -> UIColor? {
        switch (weekDay, status, present) {
        case (.sunday, .selected, _), (.sunday, .highlighted, _): return ColorsConfig.sundaySelectionBackground
        case (_, .selected, _), (_, .highlighted, _): return ColorsConfig.selectionBackground
        default: return nil
        }
    }
}
