//
//  MeetingSelectDatePopup.swift
//  CircleOnet
//
//  Created by sameer on 21/08/18.
//  Copyright © 2018 Ample-Arch. All rights reserved.
//

import UIKit


protocol MeetingSelectDatePopupDelegate {
    func selectedDateTime(date: Date, time: String, isStart: Bool)
}

class MeetingSelectDatePopup: UIViewController,CalendarRedirectionProtocol ,FSCalendarDelegate,FSCalendarDataSource{
    
    @IBOutlet var subView: UIView!
    @IBOutlet var lineUpLabel: UILabel!
    @IBOutlet var saveButton: UIButton!
    @IBOutlet var cancelButton: UIButton!
    @IBOutlet var timeButton: UIButton!
    @IBOutlet var lineBottom: UILabel!
    
    @IBOutlet weak var calendarView: FSCalendar!
    
    fileprivate lazy var dateFormatter2: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd"
        return formatter
    }()
    
    fileprivate let formatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy/MM/dd"
        return formatter
    }()
    
    var startDate: Date!
    var endDate: Date!
    var dropDown = DropDown()
    var selectedTime: String!
    var selectedDate: Date!
    var minimumSelectedTime: String!
    var isFromStartDate: Bool!
    var selectedStartDate: Date!
    var selectedStartTime: String!
    
    var delegate: MeetingSelectDatePopupDelegate!
    
    fileprivate let gregorian: NSCalendar! = NSCalendar(calendarIdentifier:NSCalendar.Identifier.gregorian)
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setUpUI()
    }
    
    func setUpUI() {
        
        subView.backgroundColor = UIColor.appGray
        timeButton.backgroundColor = UIColor.white
        lineUpLabel.backgroundColor = UIColor.appColor
        lineBottom.backgroundColor = lineUpLabel.backgroundColor
        saveButton.backgroundColor = UIColor.clear
        cancelButton.backgroundColor = UIColor.clear
        
        timeButton.setImage(UIImage(named: "iconRightArrow")?.maskWithColor(color: .appColor), for: .normal)
        timeButton.imageView?.contentMode = .scaleAspectFit
        
        if isFromStartDate {
            if Utilities.dateWithoutTime(date: selectedDate) == Utilities.dateWithoutTime(date: Date()) {
                minimumSelectedTime = selectedTime
            } else {
                minimumSelectedTime = ""
            }
        }
        timeButton.setTitle(selectedTime, for: .normal)
        saveButton.setTitle("Save", for: .normal)
        cancelButton.setTitle("Cancel", for: .normal)
        
        timeButton.titleLabel?.textAlignment = .left
        
        timeButton.setTitleColor(UIColor.black, for: .normal)
        saveButton.setTitleColor(UIColor.black, for: .normal)
        cancelButton.setTitleColor(UIColor.black, for: .normal)
        
        timeButton.titleLabel?.font = .regular()
        saveButton.titleLabel?.font = .regular()
        cancelButton.titleLabel?.font = .regular()
        
        timeButton.layoutIfNeeded()
        saveButton.layoutIfNeeded()
        cancelButton.layoutIfNeeded()
        timeButton.titleEdgeInsets = UIEdgeInsets(top: 0, left: 16, bottom: 0, right: 0)
        timeButton.imageEdgeInsets = UIEdgeInsets(top: 0, left: (timeButton.frame.size.width-70), bottom: 0, right: 0)
        
        timeButton.roundCorners([.bottomLeft,.topRight], radius: timeButton.frame.size.height/2)
        saveButton.roundCorners([.bottomRight], radius: timeButton.frame.size.height/2)
        cancelButton.roundCorners([.bottomLeft], radius: timeButton.frame.size.height/2)
        
        calendarView.layer.cornerRadius = 5
        calendarView.layer.masksToBounds = true
        
        setUpCalendar()
        dropDown.dataSource = ["01:00", "02:00","03:00","04:00","05:00","06:00","07:00","08:00","09:00","10:00","11:00","12:00","13:00","14:00","15:00","16:00","17:00","18:00","19:00","20:00","21:00","22:00","23:00","24:00"]
        
    }
    
    func setUpCalendar() {
        
        //        let scopeGesture = UIPanGestureRecognizer(target: self.calendar, action: #selector(self.calendarView.handleScopeGesture(_:)))
        //        self.calendarView.addGestureRecognizer(scopeGesture)
        self.calendarView.accessibilityIdentifier = "calendar"
        calendarView.allowsMultipleSelection = false
        self.calendarView.appearance.weekdayTextColor = UIColor.appColor
        self.calendarView.appearance.headerTitleColor = UIColor.appColor
        self.calendarView.appearance.eventDefaultColor = UIColor.appColor
        self.calendarView.appearance.selectionColor = UIColor.appColor
        self.calendarView.superview?.layer.cornerRadius = 10.0
        self.calendarView.superview?.addBottomShadow()
        self.calendarView.select(selectedDate)
    }
    
    func minimumDate(for calendar: FSCalendar) -> Date {
        return Date()
    }
    
    @IBAction func timeButtonClicked(_ sender: Any) {
        
        dropDown.anchorView = calendarView
        dropDown.tintColor = UIColor(red:50.0/255.0, green:170.0/255.0, blue:95.0/255.0, alpha: 1.0)
        dropDown.selectionAction = { [unowned self] (index: Int, item: String) in
            print("Selected item: \(item) at index: \(index)")
            self.dropDown.hide()
            self.selectedTime = item
            self.timeButton.setTitle(self.selectedTime, for: .normal)
        }
        dropDown.cellHeight = 35
        dropDown.show()
    }
    
    @IBAction func saveButtonTouchDown(_ sender: Any) {
        
        saveButton.backgroundColor = UIColor.appColor
        
    }
    
    @IBAction func saveButtonClicked(_ sender: Any) {
        saveButton.backgroundColor = UIColor.clear
        if validate() {
            self.delegate.selectedDateTime(date: selectedDate, time: selectedTime, isStart: isFromStartDate)
            hideSubView()
        }
    }
    
    
    @IBAction func cancelButtonTouchDown(_ sender: Any) {
        
        cancelButton.backgroundColor = UIColor.appColor
    }
    
    @IBAction func cancelButtonClicked(_ sender: Any) {
        
        cancelButton.backgroundColor = UIColor.clear
        hideSubView()
    }
    
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
        hideSubView()
    }
    
    
    // MARK:- FSCalendarDelegate
    
    func calendarCurrentPageDidChange(_ calendar: FSCalendar) {
        print("change page to \(self.formatter.string(from: calendar.currentPage))")
    }
    
    func calendar(_ calendar: FSCalendar, didSelect date: Date, at monthPosition: FSCalendarMonthPosition) {
        print("calendar did select date \(self.formatter.string(from: date))")
        if monthPosition == .previous || monthPosition == .next {
            calendar.setCurrentPage(date, animated: true)
        }
        selectedDate = date
    }
    
    
    func hideSubView() {
        var frame = view.frame
        frame.origin.y = 0
        view.frame = frame
        
        UIView.animate(withDuration: 0.40, delay: 0.0, options: [], animations: {
            
            var frame = self.view.frame
            frame.origin.y = -self.view.frame.size.height
            self.view.frame = frame
            
        }, completion: { (finished: Bool) in
            self.willMove(toParent: nil)
            self.view.removeFromSuperview()
            self.removeFromParent()
            
        })
    }
    
    // MARK: - Validation
    fileprivate func validate() -> Bool {
        
        var message: String?
        if selectedTime == "00:00" {
            message = "please select time"
            
        } else if isFromStartDate && (Utilities.dateWithoutTime(date: selectedDate) == Utilities.dateWithoutTime(date: Date())) {
            if Utilities.getIntFromTimeFormat(str: selectedTime) < Utilities.getIntFromTimeFormat(str: minimumSelectedTime) {
                message = "meeting selected time should not be passed or it should not be near 1 hour from current time"
            }
        } else if !isFromStartDate {
            if Utilities.dateWithoutTime(date: selectedDate) < Utilities.dateWithoutTime(date: selectedStartDate) {
                message = "meeting end date should not be less than start date"
            } else if Utilities.dateWithoutTime(date:selectedDate) == Utilities.dateWithoutTime(date: selectedStartDate) {
                if Utilities.getIntFromTimeFormat(str:selectedTime) <= Utilities.getIntFromTimeFormat(str:selectedStartTime) {
                    message = "meeting end time should not be less than or equal to start time"
                }
            }
        }
        else{
            message = nil
        }
        
        if let message = message {
            
            let alert = UIAlertController(title: NSLocalizedString("error", comment: ""), message: message, preferredStyle: .alert)
            alert.view.tintColor = UIColor.appColor
            alert.addAction(UIAlertAction(title:NSLocalizedString("ok", comment: ""), style: .cancel, handler: { (action) in
                
                
            }))
            present(alert, animated: true, completion: nil)
            return false
        }else{
            return true
        }
        
    }
}
extension UIView {
    func roundCorners(_ corners:UIRectCorner, radius: CGFloat) {
        let path = UIBezierPath(roundedRect: self.bounds, byRoundingCorners: corners, cornerRadii: CGSize(width: radius, height: radius))
        let mask = CAShapeLayer()
        mask.path = path.cgPath
        self.layer.mask = mask
    }
    
}
