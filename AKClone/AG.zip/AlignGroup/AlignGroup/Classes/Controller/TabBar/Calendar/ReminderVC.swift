//
//  ReminderVC.swift
//  CircleOnet
//
//  Created by Ample on 21/08/18.
//  Copyright © 2018 Ample-Arch. All rights reserved.
//

import UIKit

protocol RemindarVCDelegate {
    func remindarSelected(remindText1: String)
}
class ReminderVC: UIViewController,CalendarRedirectionProtocol {
    
    @IBOutlet weak var doNotRemindCheckbox: UIImageView!
    @IBOutlet weak var startofMeetingCheckbox: UIImageView!
    
    @IBOutlet weak var doNotRemindButton: UIButton!
    @IBOutlet weak var startOfMeetingButton: UIButton!
    @IBOutlet weak var saveBtn: UIButton!
    
    @IBOutlet var min5Button: UIButton!
    @IBOutlet var min5ImageView: UIImageView!
    
    @IBOutlet var min15Button: UIButton!
    @IBOutlet var min15ImageView: UIImageView!
    
    @IBOutlet var min30Button: UIButton!
    @IBOutlet var min30ImageView: UIImageView!
    
    @IBOutlet var hour1Button: UIButton!
    @IBOutlet var hour1ImageView: UIImageView!
    
    @IBOutlet var day1Button: UIButton!
    @IBOutlet var day1ImageView: UIImageView!
    
    @IBOutlet var reminderLabel: UILabel!
    
    @IBOutlet var viewAppSms: UIView!
    @IBOutlet var appButton: UIButton!
    @IBOutlet var smsButton: UIButton!
    
    var remindText: String!
    var delegate: RemindarVCDelegate!
    var isChangeFromDoNotRemind: Bool!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        title = "Reminder"
        saveBtn.layer.cornerRadius = 10
        saveBtn.layer.masksToBounds = true
        
        reminderLabel.textColor = UIColor.appColor
        viewAppSms.backgroundColor = UIColor.appColor
        
        doNotRemindCheckbox.image =  UIImage(named: "iconRightArrowArrow")?.maskWithColor(color: .appColor)
        startofMeetingCheckbox.image =   UIImage(named: "iconRightArrow")?.maskWithColor(color: .appColor)
        min5ImageView.image =  UIImage(named: "iconRightArrow")?.maskWithColor(color: .appColor)
        min15ImageView.image =  UIImage(named: "iconRightArrow")?.maskWithColor(color: .appColor)
        min30ImageView.image =  UIImage(named: "iconRightArrow")?.maskWithColor(color: .appColor)
        hour1ImageView.image =  UIImage(named: "iconRightArrow")?.maskWithColor(color: .appColor)
        day1ImageView.image =  UIImage(named: "iconRightArrow")?.maskWithColor(color: .appColor)
        
        viewAppSms.layer.borderWidth = 1
        viewAppSms.layer.borderColor = UIColor.appColor.cgColor
        // setReminderWithLocalnotification()
        
        if remindText == "Do Not Remind" {
            doNotRemindButton.tag = 1
            startOfMeetingButton.tag = 0
            min5Button.tag = 0
            min15Button.tag = 0
            min30Button.tag = 0
            hour1Button.tag = 0
            day1Button.tag = 0
        } else if remindText == "Start of Meeting" {
            doNotRemindButton.tag = 0
            startOfMeetingButton.tag = 1
            min5Button.tag = 0
            min15Button.tag = 0
            min30Button.tag = 0
            hour1Button.tag = 0
            day1Button.tag = 0
        } else if remindText == "5 mins before" {
            doNotRemindButton.tag = 0
            startOfMeetingButton.tag = 0
            min5Button.tag = 1
            min15Button.tag = 0
            min30Button.tag = 0
            hour1Button.tag = 0
            day1Button.tag = 0
        } else if remindText == "15 mins before" {
            doNotRemindButton.tag = 0
            startOfMeetingButton.tag = 0
            min5Button.tag = 0
            min15Button.tag = 1
            min30Button.tag = 0
            hour1Button.tag = 0
            day1Button.tag = 0
        } else if remindText == "30 mins before" {
            doNotRemindButton.tag = 0
            startOfMeetingButton.tag = 0
            min5Button.tag = 0
            min15Button.tag = 0
            min30Button.tag = 1
            hour1Button.tag = 0
            day1Button.tag = 0
        } else if remindText == "1 hour before" {
            doNotRemindButton.tag = 0
            startOfMeetingButton.tag = 0
            min5Button.tag = 0
            min15Button.tag = 0
            min30Button.tag = 0
            hour1Button.tag = 1
            day1Button.tag = 0
        } else if remindText == "1 day before" {
            doNotRemindButton.tag = 0
            startOfMeetingButton.tag = 0
            min5Button.tag = 0
            min15Button.tag = 0
            min30Button.tag = 0
            hour1Button.tag = 0
            day1Button.tag = 1
        }
        minSelectionChanges()
    }
    
    func appSmsSelectionChanges() -> Void {
        if appButton.tag == 0 && smsButton.tag == 0 {
            appButton.backgroundColor = UIColor.white
            smsButton.backgroundColor = UIColor.white
            
            appButton.setTitleColor(UIColor.darkGray, for: .normal)
            smsButton.setTitleColor(UIColor.darkGray, for: .normal)
            
        } else if appButton.tag == 1 {
            appButton.backgroundColor = UIColor.appColor
            smsButton.backgroundColor = UIColor.white
            
            appButton.setTitleColor(UIColor.white, for: .normal)
            smsButton.setTitleColor(UIColor.darkGray, for: .normal)
            
        } else if smsButton.tag == 1 {
            appButton.backgroundColor = UIColor.white
            smsButton.backgroundColor = UIColor.appColor
            
            appButton.setTitleColor(UIColor.darkGray, for: .normal)
            smsButton.setTitleColor(UIColor.white, for: .normal)
        }
    }
    
    @IBAction func onClickSaveBtn(_ sender: UIButton) {
        delegate.remindarSelected(remindText1: remindText)
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func minSelectionButtonClicked(_ sender: UIButton) {
        
        if sender == doNotRemindButton {
            doNotRemindButton.tag = 1
            startOfMeetingButton.tag = 0
            min5Button.tag = 0
            min15Button.tag = 0
            min30Button.tag = 0
            hour1Button.tag = 0
            day1Button.tag = 0
        } else if sender == startOfMeetingButton {
            doNotRemindButton.tag = 0
            startOfMeetingButton.tag = 1
            min5Button.tag = 0
            min15Button.tag = 0
            min30Button.tag = 0
            hour1Button.tag = 0
            day1Button.tag = 0
        }
        if sender == min5Button {
            doNotRemindButton.tag = 0
            startOfMeetingButton.tag = 0
            min5Button.tag = 1
            min15Button.tag = 0
            min30Button.tag = 0
            hour1Button.tag = 0
            day1Button.tag = 0
        } else if sender == min15Button {
            doNotRemindButton.tag = 0
            startOfMeetingButton.tag = 0
            min5Button.tag = 0
            min15Button.tag = 1
            min30Button.tag = 0
            hour1Button.tag = 0
            day1Button.tag = 0
        } else if sender == min30Button {
            doNotRemindButton.tag = 0
            startOfMeetingButton.tag = 0
            min5Button.tag = 0
            min15Button.tag = 0
            min30Button.tag = 1
            hour1Button.tag = 0
            day1Button.tag = 0
        } else if sender == hour1Button {
            doNotRemindButton.tag = 0
            startOfMeetingButton.tag = 0
            min5Button.tag = 0
            min15Button.tag = 0
            min30Button.tag = 0
            hour1Button.tag = 1
            day1Button.tag = 0
        } else if sender == day1Button {
            doNotRemindButton.tag = 0
            startOfMeetingButton.tag = 0
            min5Button.tag = 0
            min15Button.tag = 0
            min30Button.tag = 0
            hour1Button.tag = 0
            day1Button.tag = 1
        }
        minSelectionChanges()
    }
    
    func minSelectionChanges() -> Void {
        
        if appButton.tag == 0 && smsButton.tag == 0 && doNotRemindButton.tag == 0 {
            appButton.isUserInteractionEnabled = true
            smsButton.isUserInteractionEnabled = true
            
            appButton.tag = 1
            smsButton.tag = 0
            appSmsSelectionChanges()
        }
        
        if doNotRemindButton.tag == 1 {
            
            doNotRemindButton.setTitleColor(UIColor.appColor, for: .normal)
            startOfMeetingButton.setTitleColor(UIColor.darkGray, for: .normal)
            min5Button.setTitleColor(UIColor.darkGray, for: .normal)
            min15Button.setTitleColor(UIColor.darkGray, for: .normal)
            min30Button.setTitleColor(UIColor.darkGray, for: .normal)
            hour1Button.setTitleColor(UIColor.darkGray, for: .normal)
            day1Button.setTitleColor(UIColor.darkGray, for: .normal)
            
            doNotRemindCheckbox.isHidden = false
            startofMeetingCheckbox.isHidden = true
            min5ImageView.isHidden = true
            min15ImageView.isHidden = true
            min30ImageView.isHidden = true
            hour1ImageView.isHidden = true
            day1ImageView.isHidden = true
            
            appButton.isUserInteractionEnabled = false
            smsButton.isUserInteractionEnabled = false
            
            appButton.tag = 0
            smsButton.tag = 0
            appSmsSelectionChanges()
            remindText = "Do Not Remind"
        }
        else if startOfMeetingButton.tag == 1 {
            
            doNotRemindButton.setTitleColor(UIColor.darkGray, for: .normal)
            startOfMeetingButton.setTitleColor(UIColor.appColor, for: .normal)
            min5Button.setTitleColor(UIColor.darkGray, for: .normal)
            min15Button.setTitleColor(UIColor.darkGray, for: .normal)
            min30Button.setTitleColor(UIColor.darkGray, for: .normal)
            hour1Button.setTitleColor(UIColor.darkGray, for: .normal)
            day1Button.setTitleColor(UIColor.darkGray, for: .normal)
            
            doNotRemindCheckbox.isHidden = true
            startofMeetingCheckbox.isHidden = false
            min5ImageView.isHidden = true
            min15ImageView.isHidden = true
            min30ImageView.isHidden = true
            hour1ImageView.isHidden = true
            day1ImageView.isHidden = true
            
            remindText = "Start of Meeting"
        } else if min5Button.tag == 1 {
            
            doNotRemindButton.setTitleColor(UIColor.darkGray, for: .normal)
            startOfMeetingButton.setTitleColor(UIColor.darkGray, for: .normal)
            min5Button.setTitleColor(UIColor.appColor, for: .normal)
            min15Button.setTitleColor(UIColor.darkGray, for: .normal)
            min30Button.setTitleColor(UIColor.darkGray, for: .normal)
            hour1Button.setTitleColor(UIColor.darkGray, for: .normal)
            day1Button.setTitleColor(UIColor.darkGray, for: .normal)
            
            doNotRemindCheckbox.isHidden = true
            startofMeetingCheckbox.isHidden = true
            min5ImageView.isHidden = false
            min15ImageView.isHidden = true
            min30ImageView.isHidden = true
            hour1ImageView.isHidden = true
            day1ImageView.isHidden = true
            
            remindText = "5 mins before"
        }
        else if min15Button.tag == 1 {
            
            doNotRemindButton.setTitleColor(UIColor.darkGray, for: .normal)
            startOfMeetingButton.setTitleColor(UIColor.darkGray, for: .normal)
            min5Button.setTitleColor(UIColor.darkGray, for: .normal)
            min15Button.setTitleColor(UIColor.appColor, for: .normal)
            min30Button.setTitleColor(UIColor.darkGray, for: .normal)
            hour1Button.setTitleColor(UIColor.darkGray, for: .normal)
            day1Button.setTitleColor(UIColor.darkGray, for: .normal)
            
            doNotRemindCheckbox.isHidden = true
            startofMeetingCheckbox.isHidden = true
            min5ImageView.isHidden = true
            min15ImageView.isHidden = false
            min30ImageView.isHidden = true
            hour1ImageView.isHidden = true
            day1ImageView.isHidden = true
            
            remindText = "15 mins before"
        } else if min30Button.tag == 1 {
            
            doNotRemindButton.setTitleColor(UIColor.darkGray, for: .normal)
            startOfMeetingButton.setTitleColor(UIColor.darkGray, for: .normal)
            min5Button.setTitleColor(UIColor.darkGray, for: .normal)
            min15Button.setTitleColor(UIColor.darkGray, for: .normal)
            min30Button.setTitleColor(UIColor.appColor, for: .normal)
            hour1Button.setTitleColor(UIColor.darkGray, for: .normal)
            day1Button.setTitleColor(UIColor.darkGray, for: .normal)
            
            doNotRemindCheckbox.isHidden = true
            startofMeetingCheckbox.isHidden = true
            min5ImageView.isHidden = true
            min15ImageView.isHidden = true
            min30ImageView.isHidden = false
            hour1ImageView.isHidden = true
            day1ImageView.isHidden = true
            
            remindText = "30 mins before"
        } else if hour1Button.tag == 1 {
            
            doNotRemindButton.setTitleColor(UIColor.darkGray, for: .normal)
            startOfMeetingButton.setTitleColor(UIColor.darkGray, for: .normal)
            min5Button.setTitleColor(UIColor.darkGray, for: .normal)
            min15Button.setTitleColor(UIColor.darkGray, for: .normal)
            min30Button.setTitleColor(UIColor.darkGray, for: .normal)
            hour1Button.setTitleColor(UIColor.appColor, for: .normal)
            day1Button.setTitleColor(UIColor.darkGray, for: .normal)
            
            doNotRemindCheckbox.isHidden = true
            startofMeetingCheckbox.isHidden = true
            min5ImageView.isHidden = true
            min15ImageView.isHidden = true
            min30ImageView.isHidden = true
            hour1ImageView.isHidden = false
            day1ImageView.isHidden = true
            
            remindText = "1 hour before"
        } else if day1Button.tag == 1 {
            
            doNotRemindButton.setTitleColor(UIColor.darkGray, for: .normal)
            startOfMeetingButton.setTitleColor(UIColor.darkGray, for: .normal)
            min5Button.setTitleColor(UIColor.darkGray, for: .normal)
            min15Button.setTitleColor(UIColor.darkGray, for: .normal)
            min30Button.setTitleColor(UIColor.darkGray, for: .normal)
            hour1Button.setTitleColor(UIColor.darkGray, for: .normal)
            day1Button.setTitleColor(UIColor.appColor, for: .normal)
            
            doNotRemindCheckbox.isHidden = true
            startofMeetingCheckbox.isHidden = true
            min5ImageView.isHidden = true
            min15ImageView.isHidden = true
            min30ImageView.isHidden = true
            hour1ImageView.isHidden = true
            day1ImageView.isHidden = false
            
            remindText = "1 day before"
        }
    }
    
    @IBAction func appButtonClicked(_ sender: Any) {
        appButton.tag = 1
        smsButton.tag = 0
        appSmsSelectionChanges()
    }
    
    @IBAction func smsButtonClicked(_ sender: Any) {
        appButton.tag = 0
        smsButton.tag = 1
        appSmsSelectionChanges()
    }
    
    @IBAction func onClickBackBtn(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    
}
