//
//  BookaMeetingVC.swift
//  CircleOnet
//
//  Created by Ample on 20/08/18.
//  Copyright © 2018 Ample-Arch. All rights reserved.
//

import UIKit
import UserNotifications
import UserNotificationsUI

protocol BookaMeetingVCDelegate {
    func meetingBooked()
}

protocol GroupDetailVCDelegate {
    func selectedAttendencesGroup(arr: NSMutableArray, isAttendence: Bool)
}


class BookaMeetingVC: UIViewController,UITextViewDelegate, GroupDetailVCDelegate , CalendarRedirectionProtocol ,RemindarVCDelegate, MeetingSelectDatePopupDelegate{
    
    @IBOutlet weak var svLbl: UILabel!
    @IBOutlet weak var sv1Lbl: UILabel!
    @IBOutlet weak var ssLbl: UILabel!
    @IBOutlet weak var kvLbl: UILabel!
    @IBOutlet weak var attendeesLbl: UILabel!
    @IBOutlet weak var meLbl: UILabel!
    @IBOutlet weak var btnDone: UIButton!
    
    @IBOutlet weak var starDateLabel: UILabel!
    @IBOutlet weak var endDateLabel: UILabel!
    @IBOutlet weak var startTimeLabel: UILabel!
    @IBOutlet weak var endTimeLabel: UILabel!
    
    @IBOutlet weak var topicTextView: UITextView!
    @IBOutlet weak var reminderTextLabel: UILabel!
    
    @IBOutlet weak var attachedLabel: UILabel!
    @IBOutlet weak var addLocationTextField: UITextField!
    
    var startDateString = String()
    var endDateString = String()
    var selectedStartDate: Date!
    var selectedEndDate: Date!
    var selectedStartTime: String!
    var selectedEndTime: String!
    var remindText: String!
    //  var attachedImage: UIImage!
    
    var uploadDocumentName: String!
    
    var attendencesArr = NSMutableArray()
    var meetingOwnerArr = NSMutableArray()
    
    var delegate: BookaMeetingVCDelegate!
    var titleString: String?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        title = titleString
        
        svLbl.layer.cornerRadius = svLbl.frame.size.height/2
        svLbl.layer.masksToBounds = true
        svLbl.font = .custom(size:10)
        
        sv1Lbl.layer.cornerRadius = sv1Lbl.frame.size.height/2
        sv1Lbl.layer.masksToBounds = true
        sv1Lbl.font = .custom(size:10)
        
        ssLbl.layer.cornerRadius = ssLbl.frame.size.height/2
        ssLbl.layer.masksToBounds = true
        sv1Lbl.font = .custom(size:10)
        
        kvLbl.layer.cornerRadius = kvLbl.frame.size.height/2
        kvLbl.layer.masksToBounds = true
        kvLbl.font = .custom(size:10)
        
        attendeesLbl.layer.cornerRadius = attendeesLbl.frame.size.height/2
        attendeesLbl.layer.masksToBounds = true
        attendeesLbl.font = .custom(size:10)
        topicTextView.text = " Please enter a meeting topic..."
        topicTextView.textColor = UIColor.gray
        topicTextView.font = .custom(size:10)
        attachedLabel.text = "attached"
        attachedLabel.isHidden = true
        attachedLabel.font = .custom(size:10)
        
        btnDone.titleLabel?.font = .bold()
        btnDone.layer.cornerRadius = 10
        btnDone.layer.masksToBounds = true
        selectedStartDate = Date()
        selectedEndDate = Date()
        
        let startDateTuple: (st1: String, st2: String) =  Utilities.dateFormatBookMeeting(date: selectedStartDate)
        let calendar = Calendar.current
        selectedEndDate = calendar.date(byAdding: .hour, value: 1, to: selectedEndDate)
        let endDateTuple: (st1: String, st2: String) =  Utilities.dateFormatBookMeeting(date: selectedEndDate)
        
        startDateString = startDateTuple.st1
        endDateString = endDateTuple.st1
        
        starDateLabel.text = startDateString
        starDateLabel.font = .regular()
        
        endDateLabel.text = endDateString
        endDateLabel.font = .regular()
        
        selectedStartTime = startDateTuple.st2
        selectedEndTime = endDateTuple.st2
        
        startTimeLabel.text = selectedStartTime
        startTimeLabel.font = .regular()
        
        endTimeLabel.text = selectedEndTime
        endTimeLabel.font = .regular()
        remindText = "Start of Meeting"
        reminderTextLabel.text = remindText
        reminderTextLabel.font = .regular()
        meLbl.text = ""
        
        attendencesArr = NSMutableArray()
        meetingOwnerArr = NSMutableArray()
        showAttendenceLabel()
        showMeetingOwnerLabel()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        self.navigationItem.backBarButtonItem = UIBarButtonItem(title:"", style:.plain, target:nil, action:nil)
        
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        self.navigationItem.backBarButtonItem = UIBarButtonItem(title:"", style:.plain, target:nil, action:nil)
    }
    
    
    @IBAction func onClickAttatchment(_ sender: UIButton) {
        
        //        let imagePicker = UIImagePickerController()
        //        imagePicker.delegate = self
        //        imagePicker.allowsEditing = true
        //        imagePicker.sourceType = .photoLibrary
        //        imagePicker.mediaTypes = UIImagePickerController.availableMediaTypes(for: .photoLibrary)!
        //        present(imagePicker, animated: true, completion: nil)
        
        let documentPicker = UIDocumentPickerViewController(documentTypes: ["public.text","public.content","public.data"], in: .import)//UIDocumentMenuViewController(documentTypes: ["public.text","public.content","public.data"], in: .import)
        documentPicker.delegate = self
        documentPicker.modalPresentationStyle = .formSheet
        self.present(documentPicker, animated: true, completion: nil)
    }
    
    @IBAction func onClickStartDateSelection(_ sender: UIButton) {
        showDateSelectorPopUp(date: selectedStartDate, time: selectedStartTime, isStartDate: true)
    }
    
    func showDateSelectorPopUp(date: Date, time: String, isStartDate: Bool)  {

        let controller = MeetingSelectDatePopup.getViewController() as! MeetingSelectDatePopup
        controller.delegate = self
        controller.selectedDate = date
        controller.selectedTime = time
        controller.isFromStartDate = isStartDate
        if !isStartDate {
            controller.selectedStartDate = selectedEndDate
            controller.selectedStartTime = selectedStartTime

        }
        self.addChild(controller)
        controller.view.frame = CGRect(x: 0, y: 0, width: self.view.frame.size.width, height: self.view.frame.size.height)
        controller.view.backgroundColor = UIColor(white: 0.5, alpha: 0.5)
        self.view.addSubview((controller.view)!)
        self.navigationController?.view.addSubview(controller.view)
        controller.didMove(toParent: self)

        var frame = controller.view.frame
        frame.origin.y = -self.view.frame.size.height
        controller.view.frame = frame

        UIView.animate(withDuration: 0.40, delay: 0.0, options: [], animations: {

            var frame = controller.view.frame
            frame.origin.y = 0
            controller.view.frame = frame

        }, completion: { (finished: Bool)  in

        })
    }
    
    func selectedDateTime(date: Date, time: String, isStart: Bool) {
        if isStart {
            selectedStartDate = date
            selectedStartTime = time
            
            let startDateTuple: (st1: String, st2: String) =  Utilities.dateFormatBookMeeting(date: selectedStartDate)
            startDateString = startDateTuple.st1
            starDateLabel.text = startDateString
            startTimeLabel.text = selectedStartTime
            
        } else {
            selectedEndDate = date
            selectedEndTime = time
            
            let startDateTuple: (st1: String, st2: String) =  Utilities.dateFormatBookMeeting(date: selectedEndDate)
            endDateString = startDateTuple.st1
            endDateLabel.text = endDateString
            endTimeLabel.text = selectedEndTime
        }
    }
    
    @IBAction func onClickEndDateSelection(_ sender: UIButton) {
        showDateSelectorPopUp(date: selectedEndDate, time: selectedEndTime, isStartDate: false)
    }
    
    @IBAction func onclickMeetingMinutesOwner(_ sender: UIButton) {
        let controller = TaskSharingListVC.getViewController()
        navigationController?.pushViewController(controller, animated: true)
        
//        let SecondView = self.storyboard?.instantiateViewController(withIdentifier: "GroupDetailVC") as! GroupDetailVC
//        SecondView.meetingOwnerArr = meetingOwnerArr
//        SecondView.delegate = self
//        SecondView.isFromAttendence = false
//        self.navigationController?.pushViewController(SecondView, animated: true)
    }
    
    @IBAction func onClickAttendees(_ sender: UIButton) {
        let controller = AttendanceVC.getViewController()
        navigationController?.pushViewController(controller, animated: true)

//        let SecondView = self.storyboard?.instantiateViewController(withIdentifier: "GroupDetailVC") as! GroupDetailVC
//        SecondView.attendencesArr = attendencesArr
//        SecondView.delegate = self
//        SecondView.isFromAttendence = true
//        self.navigationController?.pushViewController(SecondView, animated: true)
    }
    
    func selectedAttendencesGroup(arr: NSMutableArray, isAttendence: Bool) {
        
        if isAttendence {
            attendencesArr = NSMutableArray()
            for ob in arr {
                if !(attendencesArr.contains(ob)) {
                    attendencesArr.add(ob)
                }
            }
            if attendencesArr.count > 0 {
                //            - attendance lbl
                //                - kv lbl
                //                    - ss lbl
                //                        - sv1 lbl
            }
            showAttendenceLabel()
            
        } else {
            meetingOwnerArr = NSMutableArray()
            for ob in arr {
                if !(meetingOwnerArr.contains(ob)) {
                    meetingOwnerArr.add(ob)
                }
                
            }
            showMeetingOwnerLabel()
            
        }
    }
    func showAttendenceLabel() -> Void {
        
        attendeesLbl.isHidden = true
        kvLbl.isHidden = true
        ssLbl.isHidden = true
        sv1Lbl.isHidden = true
        //print(attendencesArr)
        if attendencesArr.count == 1 {
            attendeesLbl.isHidden = false
            attendeesLbl.text = GetFirstCharOfFirstLastName(index: 0)
        } else if attendencesArr.count == 2 {
            attendeesLbl.isHidden = false
            attendeesLbl.text = GetFirstCharOfFirstLastName(index: 1)
            kvLbl.isHidden = false
            kvLbl.text = GetFirstCharOfFirstLastName(index: 0)
        } else if attendencesArr.count == 3 {
            attendeesLbl.isHidden = false
            attendeesLbl.text = GetFirstCharOfFirstLastName(index: 2)
            kvLbl.isHidden = false
            kvLbl.text = GetFirstCharOfFirstLastName(index: 1)
            ssLbl.isHidden = false
            ssLbl.text = GetFirstCharOfFirstLastName(index: 0)
        } else if attendencesArr.count == 4 {
            attendeesLbl.isHidden = false
            attendeesLbl.text = GetFirstCharOfFirstLastName(index: 3)
            kvLbl.isHidden = false
            kvLbl.text = GetFirstCharOfFirstLastName(index: 2)
            ssLbl.isHidden = false
            ssLbl.text = GetFirstCharOfFirstLastName(index: 1)
            sv1Lbl.isHidden = false
            sv1Lbl.text = GetFirstCharOfFirstLastName(index: 0)
        } else if attendencesArr.count >= 5 {
            attendeesLbl.isHidden = false
            attendeesLbl.text = "4+"
            kvLbl.isHidden = false
            kvLbl.text = GetFirstCharOfFirstLastName(index: 2)
            ssLbl.isHidden = false
            ssLbl.text = GetFirstCharOfFirstLastName(index: 1)
            sv1Lbl.isHidden = false
            sv1Lbl.text = GetFirstCharOfFirstLastName(index: 0)
        }
    }
    
    func showMeetingOwnerLabel() -> Void {
        if meetingOwnerArr.count == 0 {
            meLbl.text = "Me"
            svLbl.isHidden = true
        } else {
            meLbl.text = ""
            svLbl.isHidden = false
            svLbl.text = GetFirstCharOfFirstLastName1(index: 0)
        }
    }
    
    func GetFirstCharOfFirstLastName(index: Int) -> String {
        let dic: [String: Any] = attendencesArr.object(at: index) as! [String : Any]
        let str1: String = dic["FirstName"] as? String ?? ""
        let str2: String = dic["LastName"] as? String ?? ""
        let str = String(str1.prefix(1)) + String(str2.prefix(1))
        return str
    }
    
    func GetFirstCharOfFirstLastName1(index: Int) -> String {
        let dic: [String: Any] = meetingOwnerArr.object(at: index) as! [String : Any]
        let str1: String = dic["FirstName"] as? String ?? ""
        let str2: String = dic["LastName"] as? String ?? ""
        let str = String(str1.prefix(1)) + String(str2.prefix(1))
        return str
    }
    
    @IBAction func onClickReminderBtn(_ sender: UIButton) {
        let controller = ReminderVC.getViewController() as! ReminderVC
        controller.delegate = self
        controller.remindText = remindText
        self.navigationController?.pushViewController(controller, animated: true)
    }
    
    func remindarSelected(remindText1: String) {
        remindText = remindText1
        reminderTextLabel.text = remindText
        print(remindText)
    }
    
    func textViewDidBeginEditing(_ textView: UITextView) {
        if topicTextView.text != "" && topicTextView.text == " Please enter a meeting topic..." {
            topicTextView.text = ""
            topicTextView.textColor = UIColor.black
        }
    }
    
    func textViewDidEndEditing(_ textView: UITextView) {
        if topicTextView.text == "" {
            topicTextView.text = " Please enter a meeting topic..."
            topicTextView.textColor = UIColor.gray
        }
    }
    
    @IBAction func doneButtonClicked(_ sender: UIButton) {
        
        if validate() {
//            bookAMeetingAPICall()
//            self.setReminderWithLocalnotification(start: strStart)
        }
    }
    
    @IBAction func onClickBackBtn(_ sender: UIButton) {
        // self.dismiss(animated: true, completion: nil)
        self.navigationController?.popViewController(animated: true)
    }
    
}

// MARK: - Book Meeting API call
extension BookaMeetingVC{
    
    fileprivate func validate() -> Bool {
        
        var message: String? = ""
        if topicTextView.text.isEmpty || topicTextView.text == " Please enter a meeting topic..."{
            message = "meeting topic should not be empty"
        } else if selectedStartDate == nil {
            message = "start date should not be empty"
        } else if selectedEndDate == nil {
            message = "end date should not be empty"
        } else if selectedStartTime == "" || selectedStartTime == "00" {
            message = "start time should not be empty"
        } else if  selectedEndTime == "" || selectedEndTime == "00" {
            message = "end time should not be empty"
        } else if Utilities.dateWithoutTime(date: selectedEndDate) < Utilities.dateWithoutTime(date: selectedStartDate) {
            message = "meeting end date should not be less than start date"
        } else if Utilities.dateWithoutTime(date:selectedEndDate) == Utilities.dateWithoutTime(date: selectedStartDate) {
            if Utilities.getIntFromTimeFormat(str:selectedEndTime) <= Utilities.getIntFromTimeFormat(str:selectedStartTime) {
                message = "meeting end time should not be less than or equal to start time"
            }
        }
        if (addLocationTextField.text?.isEmpty)! {
            message = Utilities.nextLine(msg: message!)
            message =  message! + "meeting location should not be empty"
        }
        if (attendencesArr.count == 0) {
            message = Utilities.nextLine(msg: message!)
            message = message! + "please select atleast one attendence"
        }
        if (meetingOwnerArr.count > 1) {
            message = Utilities.nextLine(msg: message!)
            message = message! + "You can't select meeting minutes owner more than one"
        }
        
        
        if message != "" {
            let alert = UIAlertController(title: NSLocalizedString("error", comment: ""), message: message, preferredStyle: .alert)
            alert.view.tintColor = UIColor.appColor
            alert.addAction(UIAlertAction(title:NSLocalizedString("ok", comment: ""), style: .cancel, handler: { (action) in
                
                
            }))
            present(alert, animated: true, completion: nil)
            return false
        }else{
            return true
        }
        
    }
    
    func setReminderWithLocalnotification(start: String)  {
        
        //MM-dd-yyyy HH:mm:ss
        if start != "" {
            let valueArr: [String] = start.components(separatedBy: " ")
            if valueArr.count > 0 {
                
                let valueDate: [String] = valueArr[0].components(separatedBy: "-")
                let valueTime: [String] = valueArr[1].components(separatedBy: ":")
                
                if valueDate.count == 3  && valueTime.count >= 2 {
                    
                    let calendar = Calendar.current
                    let components = DateComponents(year: Int(valueDate[2]), month: Int(valueDate[0]), day: Int(valueDate[1]), hour: Int(valueTime[0]), minute: Int(valueTime[1])) // Set the date here when you want Notification
                    var date = calendar.date(from: components)
                    
                    if (remindText == "5 mins before") {
                        date = calendar.date(byAdding: .minute, value: -5, to: date!)
                    } else if (remindText == "15 mins before") {
                        date = calendar.date(byAdding: .minute, value: -15, to: date!)
                    } else if (remindText == "30 mins before") {
                        date = calendar.date(byAdding: .minute, value: -30, to: date!)
                    } else if (remindText == "1 hour before") {
                        date = calendar.date(byAdding: .hour, value: -1, to: date!)
                    } else if (remindText == "1 day before") {
                        date = calendar.date(byAdding: .day, value: -1, to: date!)
                    }
                    
                    let comp2 = calendar.dateComponents([.year,.month,.day,.hour,.minute], from: date!)
                    let trigger = UNCalendarNotificationTrigger(dateMatching: comp2, repeats: true)
                    
                    let content = UNMutableNotificationContent()
                    content.title = String(topicTextView.text)
                    content.subtitle = ""
                    content.body = ""
                    
                    let currentDateTime1 = Date()
                    let dateFormat1 = DateFormatter()
                    dateFormat1.dateFormat = "dd-MM-yyyy HH:mm:ss"
                    let strIdenti = dateFormat1.string(from: currentDateTime1)
                    
                    let request = UNNotificationRequest(
                        identifier: "\(String(strIdenti))_\(String(topicTextView.text))", //"identifier",
                        content: content,
                        trigger: trigger
                    )
                    
                    UNUserNotificationCenter.current().add(request, withCompletionHandler: { error in
                        if error != nil {
                            //handle error
                        } else {
                            //notification set up successfully
                        }
                    })
                }
            }
        }
    }
    
    func deletePerticularLocalNotificaiton(idString: String)  {
        
        UNUserNotificationCenter.current().getPendingNotificationRequests { (notificationRequests) in
            var identifiers: [String] = []
            for notification:UNNotificationRequest in notificationRequests {
                if notification.identifier == idString{ //"identifierCancel" {
                    identifiers.append(notification.identifier)
                }
            }
            UNUserNotificationCenter.current().removePendingNotificationRequests(withIdentifiers: identifiers)
        }
        
    }
}

//extension BookaMeetingVC: UIImagePickerControllerDelegate, UINavigationControllerDelegate {
//
//    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
//        if let pickedImage = info[UIImagePickerControllerEditedImage] as? UIImage {
//            attachedImage = pickedImage
//            attachedLabel.isHidden = false
//            dismiss(animated: true, completion: nil)
//        }
//    }
//
//    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
//        dismiss(animated: true, completion: nil)
//    }
//}

extension BookaMeetingVC: UIDocumentPickerDelegate {
    
    
    public func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentAt url: URL) {
        
        if controller.documentPickerMode == UIDocumentPickerMode.import {
            // let filePath = try? String(contentsOfFile: url.path)
            //   let fileurl = url
            let tempfileName = url.lastPathComponent
            self.uploadDocumentName = tempfileName.replacingOccurrences(of: " ", with: "")
            attachedLabel.isHidden = false
            
        }
        
        do {
            let resources = try url.resourceValues(forKeys:[.fileSizeKey])
            let fileSize = resources.fileSize!
            print ("\(fileSize)")
            
            let countBytes = ByteCountFormatter()
            countBytes.allowedUnits = [.useMB]
            countBytes.countStyle = .file
            let fileSizeinMb = countBytes.string(fromByteCount: Int64(fileSize))
            //            let fileSizeinMbInt = Int(fileSizeinMb)
            //            print("File size: \(fileSizeinMb)")
            
            var fileValue = ""
            let string = fileSizeinMb
            if let range = string.range(of: " ") {
                fileValue = String(string[(string.startIndex)..<range.lowerBound])
                print(fileValue)
                
                let fileVal = Float(fileValue)
                
                if(fileVal! > 3){
                    self.uploadDocumentName = ""
                    
                    let alert = UIAlertController(title: "Attach file", message: "Sorry! : Please select a file not more than 3MB", preferredStyle: UIAlertController.Style.alert)
                    alert.addAction(UIAlertAction(title: "Ok", style: UIAlertAction.Style.default, handler: nil))
                    self.present(alert, animated: true, completion: nil)
                }else{
                    //                    let fileData = try Data.init(contentsOf: url)
                    //                    base64String = fileData.base64EncodedString(options: .lineLength64Characters)
                    //                    print(base64String)
                }
            }
        }catch {
            self.uploadDocumentName = ""
            print("Error: \(error)")
        }
    }
//    func documentMenu(_ documentMenu: UIDocumentMenuViewController, didPickDocumentPicker documentPicker: UIDocumentPickerViewController) {
//        documentPicker.delegate = self
//        present(documentPicker, animated: true, completion: nil)
//    }
    

    
    func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) {
        print("cancelled")
        dismiss(animated: true, completion: nil)
    }
    
}
