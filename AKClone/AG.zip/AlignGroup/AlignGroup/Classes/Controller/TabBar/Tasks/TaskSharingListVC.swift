//
//  TaskSharingListVC.swift
//  AlignGroup
//
//  Created by sameer on 18/02/19.
//  Copyright © 2019 SHANI SHAH. All rights reserved.
//

import UIKit

class TaskSharingListVC: UIViewController,TaskRedirectionProtocol {

    @IBOutlet weak var taskSharingAddMore: UIButton!
    @IBOutlet weak var taskSharingListTableView: UITableView!
    @IBOutlet weak var searchTextField: UITextField!
    
    @IBOutlet weak var taskNumberLabel: UILabel!
    @IBOutlet weak var taskShareLabel: UILabel!
    @IBOutlet weak var searchButton: UIButton!
    
    var taskSharingListData = [["name":"Tony Stark","designation":"IRON MAN","image":"iconDashboard"],
                          ["name":"Thor","designation":"God of Thunder","image":"iconDashboard"],
                          ["name":"Hulk","designation":"Increadible Hulk","image":"iconDashboard"],
                          ["name":"Dr. Strange","designation":"Steven Strange","image":"iconDashboard"],
                          ["name":"Spider Man","designation":"Tom holland","image":"iconDashboard"],
                          ["name":"Tony Stark","designation":"IRON MAN","image":"iconDashboard"],
                          ["name":"Tony Stark","designation":"IRON MAN","image":"iconDashboard"],
                          ["name":"Tony Stark","designation":"IRON MAN","image":"iconDashboard"],
                          ["name":"Tony Stark","designation":"IRON MAN","image":"iconDashboard"],
                          ["name":"Tony Stark","designation":"IRON MAN","image":"iconDashboard"],
                          ["name":"Tony Stark","designation":"IRON MAN","image":"iconDashboard"]]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Task Sharing List"
        configure()
    }
    
    @IBAction func taskSharingAddMoreAction(_ sender: Any) {
        
    }
}

extension TaskSharingListVC{
    
    func configure()  {
        taskNumberLabel.font = UIFont.boldBig()
        taskNumberLabel.text = "Task 1"
        taskNumberLabel.textColor = UIColor.orange
        
        taskSharingAddMore.setTitle("Add More to List", for: .normal)
        taskSharingAddMore.setTitleColor(.white, for: .normal)
        taskSharingAddMore.backgroundColor = .black
        taskSharingAddMore.layer.cornerRadius = 5
        taskSharingAddMore.layer.masksToBounds = true
        taskSharingAddMore.titleLabel?.font = .bold()
        
        taskShareLabel.font = .custom(size: 10)
        taskShareLabel.text = "Tasks shared with:"
        searchTextField.placeholder = "Search"
        searchTextField.font = .regular()
        
        searchTextField.superview?.backgroundColor = .appGray
        searchTextField.superview?.layer.cornerRadius = 5
        searchTextField.keyboardType = .default
        searchTextField.returnKeyType = .search
        
        taskSharingListTableView.tableFooterView = UIView()
        taskSharingListTableView.contentOffset = .zero
        taskSharingListTableView.separatorStyle = .none
    }
}

extension TaskSharingListVC: UITableViewDelegate,UITableViewDataSource{
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 80
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return taskSharingListData.count
    }
    
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "TaskSharingListCell", for: indexPath) as! TaskSharingListCell
        cell.setupData(data: taskSharingListData[indexPath.row])
        return cell
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete{
            let alert = UIAlertController(title: "Alert", message: "Are you sure", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Yes", style: .destructive, handler: { (alert) in
                
                self.taskSharingListData.remove(at: indexPath.row)
                self.taskSharingListTableView.reloadData()
            }))
            alert.addAction(UIAlertAction(title: "No", style: .default, handler: { (alert) in
                
            }))
            self.present(alert, animated: true, completion: nil)
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
    }
}
