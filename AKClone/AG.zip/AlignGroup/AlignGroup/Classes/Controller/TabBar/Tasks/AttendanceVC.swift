//
//  AttendanceVCViewController.swift
//  AlignGroup
//
//  Created by Shani Shah on 13/2/19.
//  Copyright © 2019 SHANI SHAH. All rights reserved.
//

import UIKit

class AttendanceVC: UIViewController, TaskRedirectionProtocol{

    @IBOutlet weak var attendanceAddMore: UIButton!
    @IBOutlet weak var attendanceTableView: UITableView!
    @IBOutlet weak var searchTextField: UITextField!
    
    @IBOutlet weak var taskShareLabel: UILabel!
    @IBOutlet weak var searchButton: UIButton!
    
    var attendanceData = [["name":"Tony Stark","designation":"IRON MAN","image":"iconDashboard"],
                          ["name":"Thor","designation":"God of Thunder","image":"iconDashboard"],
                          ["name":"Hulk","designation":"Increadible Hulk","image":"iconDashboard"],
                          ["name":"Dr. Strange","designation":"Steven Strange","image":"iconDashboard"],
                          ["name":"Spider Man","designation":"Tom holland","image":"iconDashboard"],
                          ["name":"Tony Stark","designation":"IRON MAN","image":"iconDashboard"],
                          ["name":"Tony Stark","designation":"IRON MAN","image":"iconDashboard"],
                          ["name":"Tony Stark","designation":"IRON MAN","image":"iconDashboard"],
                          ["name":"Tony Stark","designation":"IRON MAN","image":"iconDashboard"],
                          ["name":"Tony Stark","designation":"IRON MAN","image":"iconDashboard"],
                          ["name":"Tony Stark","designation":"IRON MAN","image":"iconDashboard"]]
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Attendance List"
        configure()
        
    }

    @IBAction func attendanceAddMoreAction(_ sender: Any) {
        
    }
    
    
}

extension AttendanceVC{
    
    func configure()  {
        attendanceAddMore.setTitle("Add More to List", for: .normal)
        attendanceAddMore.setTitleColor(.white, for: .normal)
        attendanceAddMore.backgroundColor = .black
        attendanceAddMore.layer.cornerRadius = 5
        attendanceAddMore.layer.masksToBounds = true
        attendanceAddMore.titleLabel?.font = .bold()
        
        taskShareLabel.font = .custom(size: 10)
        taskShareLabel.text = "Tasks shared with:"
        searchTextField.placeholder = "Search"
        searchTextField.font = .regular()
        
        searchTextField.superview?.backgroundColor = .appGray
        searchTextField.superview?.layer.cornerRadius = 5
        searchTextField.keyboardType = .default
        searchTextField.returnKeyType = .search
        
        attendanceTableView.tableFooterView = UIView()
        attendanceTableView.contentOffset = .zero
        attendanceTableView.separatorStyle = .none
    }
}



extension AttendanceVC: UITableViewDelegate,UITableViewDataSource{
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 80
        
        
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return attendanceData.count
    }
    
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "AttendanceCell", for: indexPath) as! AttendanceCell
        cell.setupData(data: attendanceData[indexPath.row])
        return cell
        
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete{
            let alert = UIAlertController(title: "Alert", message: "Are you sure", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Yes", style: .destructive, handler: { (alert) in
                
                self.attendanceData.remove(at: indexPath.row)
                
                self.attendanceTableView.reloadData()
            }))
            alert.addAction(UIAlertAction(title: "No", style: .default, handler: { (alert) in
                
            }))
            self.present(alert, animated: true, completion: nil)
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
    }
    
}
