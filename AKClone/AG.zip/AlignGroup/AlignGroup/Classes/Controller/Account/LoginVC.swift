//
//  LoginVC.swift
//  AlignGroup
//
//  Created by SHANI SHAH on 06/02/19.
//  Copyright © 2019 SHANI SHAH. All rights reserved.
//

import UIKit

class LoginVC: UIViewController,StoryboardRedirectionProtocol {

    @IBOutlet weak var logoImageView: UIImageView!
    
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var showPassword: UIButton!
    
    @IBOutlet weak var rememberButton: UIButton!
    @IBOutlet weak var forgotPasswordButton: UIButton!
    @IBOutlet weak var loginButton: UIButton!
    @IBOutlet weak var registerButton: UIButton!
    @IBOutlet weak var registerLabel: UILabel!
    
    @IBOutlet weak var scrollView: UIScrollView!
    var keyboard = Keyboard()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        configure()
        self.navigationItem.backBarButtonItem = UIBarButtonItem(title:"", style:.plain, target:nil, action:nil)
        self.navigationItem.setHidesBackButton(true, animated: true)
        

        let timezone = TimeZone.ReferenceType.default
        
         let parameters = ["start_datetime": "02-26-2019 10:00:00", "participants_userid": ["86"], "meeting_owner_userid": "16", "note": "test", "userid": "16", "reminder_flag": "Y", "event_description": "test", "end_datetime": "02-28-2019 08:00:00"] as APIParameters
        
//        let parameters = [ "numofrecords": "100","pageno": "1", "userid": "16" ,"Type": "asc"]
        APIManager.postRequest(apiName: .meetingSchedule, parameter: parameters, success: { response in
            print(response)
        })
        
    }

    @IBAction func showPasswordButtonAction(_ sender: UIButton) {
        sender.isSelected = !sender.isSelected
        if sender.isSelected{
            passwordTextField.isSecureTextEntry = false
        } else {
            passwordTextField.isSecureTextEntry = true
        }
    }
    
    @IBAction func rememberMeButtonAction(_ sender: UIButton) {
        sender.isSelected = !sender.isSelected
    }
    
    @IBAction func forgotButtonAction(_ sender: UIButton) {
        
    }
    
    @IBAction func loginButtonAction(_ sender: UIButton) {
//        if validateLoginForm(){
//            print("valid")
//        }
        setHome()
    }
    
    @IBAction func registerButtonAction(_ sender: UIButton) {
        let controller = RegisterVC.getViewController()
        navigationController?.pushViewController(controller, animated: true)
    }
   
}

extension LoginVC{
    
    fileprivate func setHome()  {
        
        let menu = MenuVC.getViewController()
        let dashboard = TabBarVC.getViewController()
        
        let leftMenu = SlideMenuController(mainViewController: dashboard, leftMenuViewController: menu)
        let window = (UIApplication.shared.delegate as! AppDelegate).window
        UIApplication.shared.switchRootViewController(window, rootViewController: leftMenu, animation: .none) {
            print("done")
        }
    }
    
    func configure() {
        title = "Login"
        keyboard.addInputView(emailTextField)
        keyboard.addInputView(passwordTextField)
        keyboard.delegate = self
        
        showPassword.setImage(UIImage(named: "iconEye"), for: .normal)
        
        logoImageView.image = UIImage(named: "alignLogo")
        logoImageView.contentMode = .scaleAspectFit
        
        emailTextField.backgroundColor = UIColor(white: 1.0, alpha: 0.8)
        emailTextField.layer.borderColor = UIColor.appColor.cgColor
        emailTextField.layer.borderWidth = 0.6
        emailTextField.placeholder = "Email Address"
        emailTextField.font = .regular()
        emailTextField.keyboardType = .emailAddress
        emailTextField.textColor = .black
        
        passwordTextField.backgroundColor = UIColor(white: 1.0, alpha: 0.8)
        passwordTextField.layer.borderColor = UIColor.appColor.cgColor
        passwordTextField.layer.borderWidth = 0.6
        passwordTextField.placeholder = "Password"
        passwordTextField.font = .regular()
        passwordTextField.keyboardType = .default
        passwordTextField.isSecureTextEntry = true
        passwordTextField.textColor = .black
        
        forgotPasswordButton.setTitle("Forgot Password?", for: .normal)
        forgotPasswordButton.setTitleColor(.black, for: .normal)
        forgotPasswordButton.titleLabel?.font = .custom(size: 11)
        
        addImageToBackground(image: UIImage(named: "loginBg")!)
        
        rememberButton.setImage(UIImage(named: "iconSelected"), for: .selected)
        rememberButton.setImage(UIImage(named: "iconDeSelected"), for: .normal)
        rememberButton.setTitleColor(.black, for: .normal)
        rememberButton.setTitle("Remember Password", for: .normal)
        rememberButton.titleLabel?.font = .custom(size: 11)
        
        loginButton.setTitleColor(.black, for: .normal)
        loginButton.setTitle("Login", for: .normal)
        loginButton.titleLabel?.font = .big()
        loginButton.backgroundColor = .white
        
        registerLabel.text = "Don't have an account?"
        registerLabel.font = .regular()
        
        registerButton.setTitleColor(.white, for: .normal)
        registerButton.setTitle("Register", for: .normal)
        registerButton.titleLabel?.font = .boldBig()
        registerButton.backgroundColor = .appColor
        registerButton.layer.cornerRadius = registerButton.frame.height / 2
        registerButton.layer.masksToBounds = true
    }
    
    fileprivate func validateLoginForm() -> Bool {
        hideActivity()
        var inputView: Any?
        var message: String?
        
        if emailTextField.text!.isEmpty {
            inputView = emailTextField
            message = "Email can not be empty"
        }else if !emailTextField.text!.isValidEmail {
            inputView = emailTextField
            message = "Email not valid"
        }else if passwordTextField.text!.isEmpty {
            inputView = passwordTextField
            message = "Password can not be empty"
        }else{
            inputView = nil
            message = nil
        }
        
        if let message = message {
            
            let alert = UIAlertController(title: "Error", message: message, preferredStyle: .alert)
            
            alert.addAction(UIAlertAction(title:"Ok", style: .cancel, handler: { (action) in
                
                if let textField = inputView as! UITextField? {
                    textField.becomeFirstResponder()
                }
            }))
                present(alert, animated: true, completion: nil)
            return false
        }else{
            return true
        }
    }
}

extension LoginVC: KeyboardDelegate {
    
    func keyboard(_ keyboard: Keyboard, willShow notification: KeyboardNotification) {
        
        if let scrollView = scrollView {
            let contentInset = UIEdgeInsets(top: 0.0, left: 0.0, bottom: notification.frameEnd.height, right: 0.0)
            scrollView.contentInset = contentInset
            scrollView.scrollIndicatorInsets = contentInset
            
            // If active text field is hidden by keyboard, scroll it so it's visible
            // Your app might not need or want this behavior.
            var aRect = view.frame
            aRect.size.height -= notification.frameEnd.height
            
            if let inputView = keyboard.activeField {
                
                let frame = inputView.convert(inputView.frame, from: scrollView)
                if !aRect.contains(frame) {
                    scrollView.scrollRectToVisible(frame, animated: true)
                }
            }
        }
    }
    
    func keyboard(_ keyboard: Keyboard, willHide notification: KeyboardNotification) {
        if let scrollView = scrollView {
            let contentInset = UIEdgeInsets.zero
            scrollView.contentInset = contentInset
            scrollView.scrollIndicatorInsets = contentInset
        }
    }
    
    func keyboard(_ keyboard: Keyboard, didHide notification: KeyboardNotification) {
        if let scrollView = scrollView {
            let contentInset = UIEdgeInsets.zero
            scrollView.contentInset = contentInset
            scrollView.scrollIndicatorInsets = contentInset
        }
    }
}
