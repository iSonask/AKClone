//
//  RegisterVC.swift
//  AlignGroup
//
//  Created by SHANI SHAH on 06/02/19.
//  Copyright © 2019 SHANI SHAH. All rights reserved.
//

import UIKit

class RegisterVC: UIViewController,StoryboardRedirectionProtocol {

    
    @IBOutlet weak var logoImageView: UIImageView!
    @IBOutlet weak var companyNameTextField: UITextField!
    @IBOutlet weak var phoneNoTextField: UITextField!
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var confirmPasswordTextField: UITextField!
    @IBOutlet weak var countryTextField: UITextField!
    
    
    @IBOutlet weak var termsAndConditionButton: UIButton!
    @IBOutlet weak var pdpaButton: UIButton!
    @IBOutlet weak var loginButton: UIButton!
    @IBOutlet weak var registerButton: UIButton!
    @IBOutlet weak var loginLabel: UILabel!
    
    @IBOutlet weak var scrollView: UIScrollView!
    var keyboard = Keyboard()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        configure()
        
    }
    
    @IBAction func termsAndConditionButtonAction(_ sender: UIButton) {
        sender.isSelected = !sender.isSelected
    }
    
    @IBAction func pdpaButtonAction(_ sender: UIButton) {
        sender.isSelected = !sender.isSelected
    }
    
    @IBAction func loginButtonAction(_ sender: UIButton) {
        let controller = LoginVC.getViewController()
        navigationController?.pushViewController(controller, animated: true)
    }
    
    @IBAction func registerButtonAction(_ sender: UIButton) {
//        if validateRegisterForm(){
//                print("valid")
//        }
        setHome()
        
    }
    
    
}

extension RegisterVC{
    
    func configure() {
        
        self.navigationItem.backBarButtonItem = UIBarButtonItem(title:"", style:.plain, target:nil, action:nil)
        self.navigationItem.setHidesBackButton(true, animated: true)
        
        title = "Register"
        keyboard.addInputView(companyNameTextField)
        keyboard.addInputView(emailTextField)
        keyboard.addInputView(phoneNoTextField)
        keyboard.addInputView(passwordTextField)
        keyboard.addInputView(confirmPasswordTextField)
        keyboard.addInputView(countryTextField)
        keyboard.delegate = self
        
        
        
        logoImageView.image = UIImage(named: "alignLogo")
        logoImageView.contentMode = .scaleAspectFit
        
        
        companyNameTextField.backgroundColor = UIColor(white: 1.0, alpha: 0.8)
        companyNameTextField.layer.borderColor = UIColor.appColor.cgColor
        companyNameTextField.layer.borderWidth = 0.6
        companyNameTextField.placeholder = "Company Name*"
        companyNameTextField.font = .regular()
        companyNameTextField.keyboardType = .default
        companyNameTextField.textColor = .black
        
        emailTextField.backgroundColor = UIColor(white: 1.0, alpha: 0.8)
        emailTextField.layer.borderColor = UIColor.appColor.cgColor
        emailTextField.layer.borderWidth = 0.6
        emailTextField.placeholder = "Email Address*"
        emailTextField.font = .regular()
        emailTextField.keyboardType = .emailAddress
        emailTextField.textColor = .black
        
        phoneNoTextField.backgroundColor = UIColor(white: 1.0, alpha: 0.8)
        phoneNoTextField.layer.borderColor = UIColor.appColor.cgColor
        phoneNoTextField.layer.borderWidth = 0.6
        phoneNoTextField.placeholder = "Phone Number*"
        phoneNoTextField.font = .regular()
        phoneNoTextField.keyboardType = .phonePad
        phoneNoTextField.textColor = .black
        
        passwordTextField.backgroundColor = UIColor(white: 1.0, alpha: 0.8)
        passwordTextField.layer.borderColor = UIColor.appColor.cgColor
        passwordTextField.layer.borderWidth = 0.6
        passwordTextField.placeholder = "Password"
        passwordTextField.font = .regular()
        passwordTextField.keyboardType = .default
        passwordTextField.isSecureTextEntry = true
        passwordTextField.textColor = .black
        
        confirmPasswordTextField.backgroundColor = UIColor(white: 1.0, alpha: 0.8)
        confirmPasswordTextField.layer.borderColor = UIColor.appColor.cgColor
        confirmPasswordTextField.layer.borderWidth = 0.6
        confirmPasswordTextField.placeholder = "Confirm Password"
        confirmPasswordTextField.font = .regular()
        confirmPasswordTextField.keyboardType = .default
        confirmPasswordTextField.isSecureTextEntry = true
        confirmPasswordTextField.textColor = .black
        
        
        countryTextField.backgroundColor = UIColor(white: 1.0, alpha: 0.8)
        countryTextField.layer.borderColor = UIColor.appColor.cgColor
        countryTextField.layer.borderWidth = 0.6
        countryTextField.placeholder = "Country"
        countryTextField.font = .regular()
        countryTextField.keyboardType = .default
        countryTextField.textColor = .black
        
        addImageToBackground(image: UIImage(named: "loginBg")!)
        
        termsAndConditionButton.setImage(UIImage(named: "iconSelected"), for: .selected)
        termsAndConditionButton.setImage(UIImage(named: "iconDeSelected"), for: .normal)
        termsAndConditionButton.setTitleColor(.black, for: .normal)
        termsAndConditionButton.setTitle("Terms & Conditions", for: .normal)
        termsAndConditionButton.titleLabel?.font = .custom(size: 11)
        
        pdpaButton.setImage(UIImage(named: "iconSelected"), for: .selected)
        pdpaButton.setImage(UIImage(named: "iconDeSelected"), for: .normal)
        pdpaButton.setTitleColor(.black, for: .normal)
        pdpaButton.setTitle("PDPA (Personal Data) Content", for: .normal)
        pdpaButton.titleLabel?.font = .custom(size: 11)
        
        registerButton.setTitleColor(.black, for: .normal)
        registerButton.setTitle("Create Account", for: .normal)
        registerButton.titleLabel?.font = .big()
        registerButton.backgroundColor = .white
        
        loginLabel.text = "Already registered? Sign-in Here.."
        loginLabel.font = .regular()
        
        loginButton.setTitleColor(.white, for: .normal)
        loginButton.setTitle("Sign in", for: .normal)
        loginButton.titleLabel?.font = .boldBig()
        loginButton.backgroundColor = .appColor
        loginButton.layer.cornerRadius = registerButton.frame.height / 2
        loginButton.layer.masksToBounds = true
    }
    
    fileprivate func validateRegisterForm() -> Bool {
        
        var inputView: Any?
        var message: String?
        
        if companyNameTextField.text!.isEmpty{
            
            inputView = companyNameTextField
            message = "Company Name can not be empty"
            
        }else if emailTextField.text!.isEmpty {
            
            inputView = emailTextField
            message = "Email can not be empty"
            
        }else if !emailTextField.text!.isValidEmail {
            
            inputView = emailTextField
            message = "Email not valid"
            
        }else if phoneNoTextField.text!.isEmpty {
            
            inputView = phoneNoTextField
            message = "Phone Number can not be empty"
            
        }else if passwordTextField.text!.isEmpty {
            
            inputView = passwordTextField
            message = "Password can not be empty"
            
        }else if confirmPasswordTextField.text!.isEmpty {
            
            inputView = confirmPasswordTextField
            message = "ConfirmPassword can not be empty"
            
        }else if passwordTextField.text != confirmPasswordTextField.text {
            
            inputView = passwordTextField
            message = "Password must be same"
            
        }else if countryTextField.text!.isEmpty {
            
            inputView = countryTextField
            message = "Country can not be empty"
            
        }else if !termsAndConditionButton.isSelected{
            inputView = nil
            message = "Please Agree to Terms & Conditions"
        }else if !pdpaButton.isSelected{
            inputView = nil
            message = "Please Agree to PDPA (Personal Data) Content"
        }else{
            
            inputView = nil
            message = nil
        }
        
        if let message = message {
            
            let alert = UIAlertController(title: "Error", message: message, preferredStyle: .alert)
            
            alert.addAction(UIAlertAction(title:"Ok", style: .cancel, handler: { (action) in
                
                if let textField = inputView as! UITextField? {
                    textField.becomeFirstResponder()
                }
                
            }))
            
            present(alert, animated: true, completion: nil)
            
            return false
        }else{
            return true
        }
        
    }
    
    func setHome()  {
        
        let menu = MenuVC.getViewController()
        let dashboard = TabBarVC.getViewController()
        let leftMenu = SlideMenuController(mainViewController: dashboard, leftMenuViewController: menu)
        let window = (UIApplication.shared.delegate as! AppDelegate).window
        UIApplication.shared.switchRootViewController(window, rootViewController: leftMenu, animation: .none) {
            print("done")
        }
    }
    
}

extension RegisterVC: KeyboardDelegate {
    
    func keyboard(_ keyboard: Keyboard, willShow notification: KeyboardNotification) {
        
        if let scrollView = scrollView {
            let contentInset = UIEdgeInsets(top: 0.0, left: 0.0, bottom: notification.frameEnd.height, right: 0.0)
            scrollView.contentInset = contentInset
            scrollView.scrollIndicatorInsets = contentInset
            
            // If active text field is hidden by keyboard, scroll it so it's visible
            // Your app might not need or want this behavior.
            var aRect = view.frame
            aRect.size.height -= notification.frameEnd.height
            
            if let inputView = keyboard.activeField {
                
                let frame = inputView.convert(inputView.frame, from: scrollView)
                if !aRect.contains(frame) {
                    scrollView.scrollRectToVisible(frame, animated: true)
                }
                
            }
        }
        
    }
    
    func keyboard(_ keyboard: Keyboard, willHide notification: KeyboardNotification) {
        if let scrollView = scrollView {
            let contentInset = UIEdgeInsets.zero
            scrollView.contentInset = contentInset
            scrollView.scrollIndicatorInsets = contentInset
        }
    }
    
    func keyboard(_ keyboard: Keyboard, didHide notification: KeyboardNotification) {
        if let scrollView = scrollView {
            let contentInset = UIEdgeInsets.zero
            scrollView.contentInset = contentInset
            scrollView.scrollIndicatorInsets = contentInset
        }
    }
    
}
