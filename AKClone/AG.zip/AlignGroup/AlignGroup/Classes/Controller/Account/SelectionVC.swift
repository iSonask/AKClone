//
//  SelectionVC.swift
//  AlignGroup
//
//  Created by SHANI SHAH on 06/02/19.
//  Copyright © 2019 SHANI SHAH. All rights reserved.
//

import UIKit

class SelectionVC: UIViewController {

    @IBOutlet weak var loginButton: UIButton!
    @IBOutlet weak var registerButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        addImageToBackground(image: UIImage(named: "selection")!)
        configure()
        // Do any additional setup after loading the view.
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        

    }
    
    
    @IBAction func loginButtonAction(_ sender: UIButton) {
        let controller = LoginVC.getViewController()
        navigationController?.pushViewController(controller, animated: true)
    }
    
    @IBAction func registerButtonAction(_ sender: UIButton) {
        let controller = RegisterVC.getViewController()
        navigationController?.pushViewController(controller, animated: true)
    }
    
    func configure()  {
        loginButton.layer.cornerRadius = loginButton.frame.height / 2
        loginButton.layer.masksToBounds = true
        loginButton.titleLabel?.font = .boldBig()
        loginButton.setTitle("Login", for: .normal)
        loginButton.setTitleColor(.black, for: .normal)
        loginButton.backgroundColor = .white
        
        registerButton.backgroundColor = .white
        registerButton.setTitleColor(.black, for: .normal)
        registerButton.titleLabel?.font = .boldBig()
        registerButton.setTitle("Register", for: .normal)
        registerButton.layer.cornerRadius = registerButton.frame.height / 2
        registerButton.layer.masksToBounds = true
    }
    
}
