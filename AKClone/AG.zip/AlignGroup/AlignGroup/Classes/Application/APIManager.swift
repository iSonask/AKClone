//
//  APIManager.swift
//  AlignGroup
//
//  Created by SHANI SHAH on 18/02/19.
//  Copyright © 2019 SHANI SHAH. All rights reserved.
//

import UIKit
import Foundation
import SystemConfiguration
import Alamofire

typealias JSONResponse = [String : Any]
typealias APIParameters = [String : Any]

extension Constant{
    
    struct API {
        
        static let serverUrl = "http://13.126.56.134:8999/Onet.svc/"
        static let imageUrl = "http://13.126.56.134:9000/"
        
        static let headers: HTTPHeaders = [
            "Content-Type": "application/json" //"X-Auth" : "633uq4t0qdmdlfdgkerlope_uilna4334"
        ]
        
        enum Name: String {
            case meetingSchedule = "Meeting/Schedule"
            case friendConnections = "GetFriendConnection"
            
            var url: String{
                return "\(serverUrl)\(rawValue)"
            }
        }
    }
    
}
struct Constant {
    
}


class APIManager: NSObject{
    
//    static let shared = APIManager()
    private override init() { }
    
    class func postRequest(apiName: Constant.API.Name,parameter: APIParameters, success: @escaping(_ response: JSONResponse)-> Void ) {
        UIApplication.topViewController()?.showActivityIndicator()
        if Reachable.isConnectedToNetwork(){
            Alamofire.request(apiName.url, method: .post, parameters: parameter, encoding: JSONEncoding.prettyPrinted, headers: Constant.API.headers).responseJSON { (response) in
                    UIApplication.topViewController()?.hideActivity()
                if let dataDict = response.result.value as? JSONResponse{
                    success(dataDict)
                } else {
                    success(["message":"Something went wrong"])
                }
            }
        } else {
            UIApplication.topViewController()?.hideActivity()
            success(["message":"No Internet"])
            UIApplication.topViewController()?.alert(title: "Error", message: "Can not connect to internet")
        }
        
    }
    
    class func getRequest(apiName: Constant.API.Name,parameter: APIParameters, success: @escaping(_ response: JSONResponse)-> Void ) {
        UIApplication.topViewController()?.showActivityIndicator()
        if Reachable.isConnectedToNetwork(){
            
            Alamofire.request(apiName.url, method: .get, parameters: parameter, encoding: JSONEncoding.prettyPrinted, headers: Constant.API.headers).responseJSON { (response) in
                UIApplication.topViewController()?.hideActivity()
                if let dataDict = response.result.value as? JSONResponse{
                    success(dataDict)
                } else {
                    success(["message":"Something went wrong"])
                }
            }
            
        } else {
            
            UIApplication.topViewController()?.hideActivity()
            success(["message":"No Internet"])
            UIApplication.topViewController()?.alert(title: "Error", message: "Can not connect to internet")
            
        }
        
    }
    
}
