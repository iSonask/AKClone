//
//  AppDelegate.swift
//  AlignGroup
//
//  Created by SHANI SHAH on 02/02/19.
//  Copyright © 2019 SHANI SHAH. All rights reserved.
//

import UIKit
import CoreData
import UserNotificationsUI
import UserNotifications
import CoreLocation


@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate,UNUserNotificationCenterDelegate,CLLocationManagerDelegate {

    var window: UIWindow?

    var locationManager = CLLocationManager()

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        // Override point for customization after application launch.
        UIApplication.shared.statusBarView?.backgroundColor = .black
        application.statusBarStyle = .lightContent
        let back = ThreeColorsGradientView(frame: CGRect(x: 0, y: 0, width: window!.frame.width, height: 44))
        back.vertical = false
        UINavigationBar.appearance().tintColor = .black
        UINavigationBar.appearance().setBackgroundImage(back.asImage(), for: .default)
        UINavigationBar.appearance().titleTextAttributes = [NSAttributedString.Key.foregroundColor : UIColor.black,NSAttributedString.Key.font: UIFont.boldBig()]
        
        UNUserNotificationCenter.current().delegate = self
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge]) { (permissionGranted, error) in
            if permissionGranted{
                print("granted")
                self.setNotificationCategories()
                self.addNotification()
            } else {
                self.showAlertMessage(messageTitle: "AlignGroup", withMessage: "Notification service is disabled!!")
            }
            
        }
        
        checkLocationService()
        startLocationUpdate()
        
        Thread.sleep(forTimeInterval: 0.9)
        
        
        return true
    }
    
    func applicationWillResignActive(_ application: UIApplication) {
        // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
        // Use this method to pause ongoing tasks, disable timers, and invalidate graphics rendering callbacks. Games should use this method to pause the game.
        
    }
    
    func applicationDidEnterBackground(_ application: UIApplication) {
        // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
        // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.

    }

    func applicationWillEnterForeground(_ application: UIApplication) {
        // Called as part of the transition from the background to the active state; here you can undo many of the changes made on entering the background.
    }

    func applicationDidBecomeActive(_ application: UIApplication) {
        // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
        checkLocationService()
    }
    
    func applicationWillTerminate(_ application: UIApplication) {
        // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
        // Saves changes in the application's managed object context before the application terminates.
        self.saveContext()
    }
    // MARK: - Core Data stack

    lazy var persistentContainer: NSPersistentContainer = {
        /*
         The persistent container for the application. This implementation
         creates and returns a container, having loaded the store for the
         application to it. This property is optional since there are legitimate
         error conditions that could cause the creation of the store to fail.
        */
        let container = NSPersistentContainer(name: "AlignGroup")
        container.loadPersistentStores(completionHandler: { (storeDescription, error) in
            if let error = error as NSError? {
                // Replace this implementation with code to handle the error appropriately.
                // fatalError() causes the application to generate a crash log and terminate. You should not use this function in a shipping application, although it may be useful during development.
                 
                /*
                 Typical reasons for an error here include:
                 * The parent directory does not exist, cannot be created, or disallows writing.
                 * The persistent store is not accessible, due to permissions or data protection when the device is locked.
                 * The device is out of space.
                 * The store could not be migrated to the current model version.
                 Check the error message to determine what the actual problem was.
                 */
                fatalError("Unresolved error \(error), \(error.userInfo)")
            }
        })
        return container
    }()

    // MARK: - Core Data Saving support

    func saveContext () {
        let context = persistentContainer.viewContext
        if context.hasChanges {
            do {
                try context.save()
            } catch {
                // Replace this implementation with code to handle the error appropriately.
                // fatalError() causes the application to generate a crash log and terminate. You should not use this function in a shipping application, although it may be useful during development.
                let nserror = error as NSError
                fatalError("Unresolved error \(nserror), \(nserror.userInfo)")
            }
        }
    }

}

extension AppDelegate {
    
    fileprivate func startLocationUpdate() {
        
        locationManager.requestAlwaysAuthorization()
        
        // For use in foreground
        locationManager.requestWhenInUseAuthorization()
        if CLLocationManager.locationServicesEnabled() {
            locationManager.delegate = self
            locationManager.desiredAccuracy = kCLLocationAccuracyBest
            locationManager.distanceFilter = 5
            locationManager.startUpdatingLocation()
            locationManager.startMonitoringSignificantLocationChanges()
            locationManager.allowsBackgroundLocationUpdates = true
            locationManager.pausesLocationUpdatesAutomatically = false
            locationManager.activityType = CLActivityType.fitness
            
        }
        
    }
    
    fileprivate func addNotification(){
        //7 -
        let content = UNMutableNotificationContent()
        content.title = "Alert"
        content.subtitle = "Are you going to office today?"
        //        content.body = ""
        content.categoryIdentifier = "GoingOffice"
        
        //8 -
        let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 2, repeats: false)
        
        //9 -
        let requestIdentifier = "AlignGroup"
        let request = UNNotificationRequest(identifier: requestIdentifier, content: content, trigger: trigger)
        
        //10 -
        UNUserNotificationCenter.current().add(request) { (error) in
            //11 -
            print(error as Any)
        }
        
    }
    
    fileprivate func setNotificationCategories()  {
        //18 -
        let going = UNNotificationAction(identifier: "going", title: "Going.", options: [.foreground])
        let notGoing = UNNotificationAction(identifier: "notGoing", title: "Not Going.", options: [.foreground])
        
        //19 -
        let officeCategory = UNNotificationCategory(identifier: "GoingOffice", actions: [going, notGoing], intentIdentifiers: [], options: [])
        
        //20 -
        UNUserNotificationCenter.current().setNotificationCategories([officeCategory])
    }
    
    func userNotificationCenter(_ center: UNUserNotificationCenter, willPresent notification: UNNotification, withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
        
        //15 -
        completionHandler([.alert, .sound])
    }
    
    func userNotificationCenter(_ center: UNUserNotificationCenter, didReceive response: UNNotificationResponse, withCompletionHandler completionHandler: @escaping () -> Void) {
        
        
        if response.actionIdentifier == "going" {
            print("going")
            checkLocationService()
        } else if response.actionIdentifier == "notGoing" {
            print("NnotGoingo")
        } else {
            print("Keep trying!")
        }
    }
    
    
    fileprivate func setUpGeofenceForPlayaGrandeBeach() {
        let geofenceRegionCenter = CLLocationCoordinate2DMake(23.0235, 72.5290) // Shivranjani
        let geofenceRegion = CLCircularRegion(center: geofenceRegionCenter, radius: 200, identifier: "CurrentLocation");
        geofenceRegion.notifyOnExit = true;
        geofenceRegion.notifyOnEntry = true;
        
        self.locationManager.startMonitoring(for: geofenceRegion)
    }
    
    //MARK - CLLocationManagerDelegate
    
    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
        if (status == CLAuthorizationStatus.authorizedAlways) {
            //App Authorized, stablish geofence
            self.setUpGeofenceForPlayaGrandeBeach()
        }
    }
    
    func locationManager(_ manager: CLLocationManager, didStartMonitoringFor region: CLRegion) {
        print("Started Monitoring Region: \(region.identifier)")
    }
    
    func locationManager(_ manager: CLLocationManager, didEnterRegion region: CLRegion) {
        print("enter region")
        
    }
    
    func locationManager(_ manager: CLLocationManager, didExitRegion region: CLRegion) {
        print("exit region")
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        
    }
    
    fileprivate func checkLocationService()  {
        if CLLocationManager.locationServicesEnabled()
        {
            switch CLLocationManager.authorizationStatus()//(locationManager.authorizationStatus())
            {
            case .authorizedAlways, .authorizedWhenInUse:
                print("Authorize.")
                startLocationUpdate()
                break
            case .notDetermined:
                print("Not determined.")
                self.showAlertMessage(messageTitle: "AlignGroup", withMessage: "Location service is disabled!!")
                break
                
            case .restricted:
                print("Restricted.")
                self.showAlertMessage(messageTitle: "AlignGroup", withMessage: "Location service is disabled!!")
                break
                
            case .denied:
                print("Denied.")
                self.showAlertMessage(messageTitle: "AlignGroup", withMessage: "Location service is disabled!!")
            }
        }
    }
}

extension AppDelegate {
    
    func showAlertMessage(messageTitle: NSString, withMessage: NSString) ->Void  {
        OperationQueue.main.addOperation {
            
        let alertController = UIAlertController(title: messageTitle as String, message: withMessage as String, preferredStyle: .alert)
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel) { (action:UIAlertAction!) in
            
        }
        alertController.addAction(cancelAction)
        
        let OKAction = UIAlertAction(title: "Settings", style: .default) { (action:UIAlertAction!) in
            if let url = URL(string: UIApplication.openSettingsURLString){
                UIApplication.shared.universalOpenUrl(url)
            }
        }
        alertController.addAction(OKAction)
            self.window?.rootViewController?.present(alertController, animated: true, completion: nil)
            
        }
    }

}

