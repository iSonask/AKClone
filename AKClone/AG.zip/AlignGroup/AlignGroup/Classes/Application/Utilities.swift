//
//  Utilities.swift
//  AlignGroup
//
//  Created by SHANI SHAH on 12/02/19.
//  Copyright © 2019 SHANI SHAH. All rights reserved.
//

import Foundation
import UIKit

struct Utilities {
    
    
    public static func hexStringToUIColor(hex: String) -> UIColor {
        var cString:String = hex.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
        
        if (cString.hasPrefix("#")) {
            cString.remove(at: cString.startIndex)
        }
        
        if ((cString.count) != 6) {
            return UIColor.gray
        }
        
        var rgbValue:UInt32 = 0
        Scanner(string: cString).scanHexInt32(&rgbValue)
        
        return UIColor(
            red: CGFloat((rgbValue & 0xFF0000) >> 16) / 255.0,
            green: CGFloat((rgbValue & 0x00FF00) >> 8) / 255.0,
            blue: CGFloat(rgbValue & 0x0000FF) / 255.0,
            alpha: CGFloat(1.0)
        )
    }
    
    
    public static func trimString(str: String) -> String {
        
        if let str1 = str as String? {
            return str1.trimmingCharacters(in: .whitespacesAndNewlines)
        } else {
            return ""
        }
    }
    
    public static func removeNSNull(from dict: [AnyHashable: Any]) -> [AnyHashable:Any] {
        var mutableDict = dict
        let keysWithEmptString = dict.filter { $0.1 is NSNull }.map { $0.0 }
        for key in keysWithEmptString {
            mutableDict[key] = ""
        }
        return mutableDict
    }
    
    public static func dateFormatBookMeeting(date: Date) -> (String, String) {
        
        let dateformatter = DateFormatter()
        dateformatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
        var str1: String = dateformatter.string(from: date)
        let date1: Date = dateformatter.date(from: str1)!
        dateformatter.dateFormat = "MMM dd,yyyy"
        str1 = dateformatter.string(from: date1)
        dateformatter.dateFormat = "HH:mm"
        let str2 = dateformatter.string(from: date1)
        let valueArr: [String] = str2.components(separatedBy: ":")
        if (valueArr.count > 0) {
            let value = valueArr[0]
            if Int(value)! <= 22 {
                let strtemp: String = String(Int(value)! + 2)
                return (str1, strtemp + ":00")
            } else {
                return (str1, "00:00")
            }
        } else {
            return (str1, "00:00")
        }
    }
    
    public static func getIntFromTimeFormat(str: String) -> Int {
        let valueArr: [String] = str.components(separatedBy: ":")
        if (valueArr.count > 0) {
            let value = valueArr[0]
            return Int(value)!
        } else {
            return 0
        }
    }
    
    public static func dateWithoutTime( date: Date) -> Date {
        let dateformatter = DateFormatter()
        dateformatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
        var str1: String = dateformatter.string(from: date)
        var date1: Date = dateformatter.date(from: str1)!
        dateformatter.dateFormat = "yyyy-MM-dd"
        str1 = dateformatter.string(from: date1)
        date1 = dateformatter.date(from: str1)!
        return date1
    }
    
    public static func nextLine(msg: String) -> String {
        if msg != "" {
            return msg+"\n"
        } else {
            return msg
        }
    }
}
