//
//  AppExtension.swift
//  AlignGroup
//
//  Created by SHANI SHAH on 07/02/19.
//  Copyright © 2019 SHANI SHAH. All rights reserved.
//

import Foundation
import UIKit
import SystemConfiguration

extension UIColor {
    
    static var appColor = UIColor(red: 245.0/255.0, green: 125.0/255.0, blue: 63.0/255.0, alpha: 1.0)
    
    static var appGray = UIColor(red: 230.0/255.0, green: 230.0/255.0, blue: 230.0/255.0, alpha: 1.0)
    
    static var appLightOrange = UIColor(red: 239.0/255.0, green: 218.0/255.0, blue: 206.0/255.0, alpha: 1.0)
    
    static var appLightOrange1 = UIColor(red: 250.0/255.0, green: 171.0/255.0, blue: 137.0/255.0, alpha: 1.0)
    
    static var appGreen = UIColor.green//(red: 215.0/255.0, green: 243.0/255.0, blue: 36.0/255.0, alpha: 1.0)
}


extension UIViewController{
    
    func addImageToBackground(image: UIImage)  {
    
        let bgView = UIImageView(image: image)
        bgView.frame = view.bounds
        bgView.contentMode = .scaleAspectFill
        view.backgroundColor = .clear
        view.insertSubview(bgView, at: 0)
    
    }
    
    

  func alert(title: String = "",message: String) {
    let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
    let OKAction = UIAlertAction(title: "OK", style: .default, handler: nil)
    alertController.addAction(OKAction)
    self.present(alertController, animated: true, completion: nil)
  }

}


extension UIApplication {
    var statusBarView: UIView? {
        if responds(to: Selector("statusBar")) {
            return value(forKey: "statusBar") as? UIView
        }
        return nil
    }
}


extension UIView {
    
    func roundTopCorners(radius: CGFloat) {
        layer.cornerRadius = radius
        layer.maskedCorners = [.layerMaxXMinYCorner, .layerMinXMinYCorner]
        layer.masksToBounds = true
        clipsToBounds = true
        layoutSubviews()
    }
    
    func roundBottomCorners(radius: CGFloat) {
        layer.cornerRadius = radius
        layer.maskedCorners = [.layerMaxXMaxYCorner,.layerMinXMaxYCorner]
        layer.masksToBounds = true
        clipsToBounds = true
        layoutSubviews()
    }
    
    
    func addBottomShadow()  {
        layer.shadowColor = UIColor.black.cgColor
        layer.shadowOpacity = 1
        layer.shadowOffset = CGSize.zero
        layer.shadowRadius = 3
        layoutSubviews()
    }
}

@IBDesignable class ThreeColorsGradientView: UIView {
    @IBInspectable var firstColor: UIColor = UIColor.orange {
        didSet{
            applyGradient()
        }
    }
    @IBInspectable var secondColor: UIColor = UIColor.yellow  {
        didSet{
            applyGradient()
        }
    }
    @IBInspectable var thirdColor: UIColor = UIColor.orange  {
        didSet{
            applyGradient()
        }
    }
    
    
    @IBInspectable var vertical: Bool = true {
        didSet {
            updateGradientDirection()
        }
    }
    
    lazy var gradientLayer: CAGradientLayer = {
        let layer = CAGradientLayer()
        layer.colors = [firstColor.cgColor, secondColor.cgColor, thirdColor.cgColor]
        layer.startPoint = CGPoint.zero
        return layer
    }()
    
    //MARK: -
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        
        applyGradient()
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        applyGradient()
    }
    
    override func prepareForInterfaceBuilder() {
        super.prepareForInterfaceBuilder()
        applyGradient()
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        updateGradientFrame()
    }
    
    //MARK: -
    
    func applyGradient() {
        updateGradientDirection()
        layer.sublayers = [gradientLayer]
    }
    
    func updateGradientFrame() {
        gradientLayer.frame = bounds
    }
    
    func updateGradientDirection() {
        gradientLayer.endPoint = vertical ? CGPoint(x: 0, y: 1) : CGPoint(x: 1, y: 0)
    }
}

extension UIView {
    
    // Using a function since `var image` might conflict with an existing variable
    // (like on `UIImageView`)
    func asImage() -> UIImage {
        if #available(iOS 10.0, *) {
            let renderer = UIGraphicsImageRenderer(bounds: bounds)
            return renderer.image { rendererContext in
                layer.render(in: rendererContext.cgContext)
            }
        } else {
            UIGraphicsBeginImageContext(self.frame.size)
            self.layer.render(in:UIGraphicsGetCurrentContext()!)
            let image = UIGraphicsGetImageFromCurrentImageContext()
            UIGraphicsEndImageContext()
            return UIImage(cgImage: image!.cgImage!)
        }
    }
}

extension NSLayoutConstraint {
    /**
     Change multiplier constraint
     
     - parameter multiplier: CGFloat
     - returns: NSLayoutConstraint
     */
    func setMultiplier(multiplier:CGFloat) -> NSLayoutConstraint {
        
        NSLayoutConstraint.deactivate([self])
        
        let newConstraint = NSLayoutConstraint(
            item: firstItem,
            attribute: firstAttribute,
            relatedBy: relation,
            toItem: secondItem,
            attribute: secondAttribute,
            multiplier: multiplier,
            constant: constant)
        
        newConstraint.priority = priority
        newConstraint.shouldBeArchived = self.shouldBeArchived
        newConstraint.identifier = self.identifier
        
        NSLayoutConstraint.activate([newConstraint])
        return newConstraint
    }
}

extension Date {
    
    func adding(minutes: Int) -> Date {
        return Calendar.current.date(byAdding: .minute, value: minutes, to: self)!
    }
}



public enum ChangeRootViewControllerAnimation {
    case none
    case transitionCrossDissolve
    case transitionFlipFromRight
    case scale
}

extension UIApplication {
    
    public func universalOpenUrl(_ url: URL) {
        if #available(iOS 10, *) {
            open(url, options: [:],
                 completionHandler: {
                    (success) in
                    print("Open \(url): \(success)")
            })
        } else {
            let success = openURL(url)
            print("Open \(url): \(success)")
        }
        
    }
    
    /// Return the specific topViewController in application
    public class func topViewController(_ viewController: UIViewController? = UIApplication.shared.keyWindow?.rootViewController) -> UIViewController? {
        if let nav = viewController as? UINavigationController {
            return topViewController(nav.visibleViewController)
        }
        if let tab = viewController as? UITabBarController {
            if let selected = tab.selectedViewController {
                return topViewController(selected)
            }
        }
        if let presented = viewController?.presentedViewController {
            return topViewController(presented)
        }
        return viewController
    }
    
    
    
    public func switchRootViewController(_ window: UIWindow?, rootViewController: UIViewController, animation: ChangeRootViewControllerAnimation, completion: (() -> Void)?) {
        if let window = window {
            
            switch animation {
            case .none:
                window.rootViewController = rootViewController
            case .transitionFlipFromRight:
                UIView.transition(with: window, duration: 0.4, options: .transitionFlipFromRight, animations: {
                    let oldState: Bool = UIView.areAnimationsEnabled
                    UIView.setAnimationsEnabled(false)
                    window.rootViewController = rootViewController
                    UIView.setAnimationsEnabled(oldState)
                }, completion: { (finished: Bool) -> () in
                    completion?()
                })
                
            case .transitionCrossDissolve:
                UIView.transition(with: window, duration: 0.4, options: .transitionCrossDissolve, animations: {
                    let oldState: Bool = UIView.areAnimationsEnabled
                    UIView.setAnimationsEnabled(false)
                    window.rootViewController = rootViewController
                    UIView.setAnimationsEnabled(oldState)
                }, completion: { (finished: Bool) -> () in
                    completion?()
                })
            case .scale:
                let snapshot: UIView = window.snapshotView(afterScreenUpdates: true)!
                rootViewController.view.addSubview(snapshot);
                
                window.rootViewController = rootViewController;
                
                UIView.animate(withDuration: 0.4, animations: {() in
                    snapshot.layer.opacity = 0;
                    snapshot.layer.transform = CATransform3DMakeScale(1.5, 1.5, 1.5);
                }, completion: {
                    (value: Bool) in
                    snapshot.removeFromSuperview();
                    completion?()
                })
            }
        }
    }
}

public class Reachable {
    
    class func isConnectedToNetwork() -> Bool {
        
        var zeroAddress = sockaddr_in()
        zeroAddress.sin_len = UInt8(MemoryLayout.size(ofValue: zeroAddress))
        zeroAddress.sin_family = sa_family_t(AF_INET)
        
        let defaultRouteReachability = withUnsafePointer(to: &zeroAddress) {
            $0.withMemoryRebound(to: sockaddr.self, capacity: 1) {zeroSockAddress in
                SCNetworkReachabilityCreateWithAddress(nil, zeroSockAddress)
            }
        }
        
        var flags = SCNetworkReachabilityFlags()
        if !SCNetworkReachabilityGetFlags(defaultRouteReachability!, &flags) {
            return false
        }
        let isReachable = (flags.rawValue & UInt32(kSCNetworkFlagsReachable)) != 0
        let needsConnection = (flags.rawValue & UInt32(kSCNetworkFlagsConnectionRequired)) != 0
        return (isReachable && !needsConnection)
        
    }
}
