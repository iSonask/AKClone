//
//  EditViewCell.swift
//  AlignGroup
//
//  Created by Ample on 22/02/19.
//  Copyright © 2019 SHANI SHAH. All rights reserved.
//

import UIKit

class EditViewCell: UITableViewCell {

    @IBOutlet weak var userImageView: UIImageView!
    @IBOutlet weak var userNameLabel: UILabel!
    @IBOutlet weak var attendanceLabel: UILabel!
    @IBOutlet weak var detailButton: UIButton!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        configure()
    }
    
    func configure(){
        self.backgroundColor = .clear
        self.contentView.backgroundColor = .clear
        
        userNameLabel.font = .customBold(size: 16)
        userNameLabel.textColor = .black
        
        attendanceLabel.font = .regular()
        attendanceLabel.textColor = .appColor
        
        selectionStyle = .none
        userNameLabel.superview?.layer.cornerRadius = 5
        userNameLabel.superview?.layer.shadowColor = UIColor.black.cgColor
        userNameLabel.superview?.layer.shadowOffset = CGSize(width: 0.5, height: 0.5)
        userNameLabel.superview?.layer.shadowOpacity = 0.5
        userNameLabel.superview?.layer.shadowRadius = 2.0
        userNameLabel.superview?.layer.masksToBounds = false
    }
    
    func setupData(data: [String:String]) {
        userNameLabel.text = data["name"]
        attendanceLabel.text = data["attendance"]
        userImageView.image = UIImage(named: data["image"]!)
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    @IBAction func onClickDetailBtnAction(_ sender: UIButton) {
    }

}
