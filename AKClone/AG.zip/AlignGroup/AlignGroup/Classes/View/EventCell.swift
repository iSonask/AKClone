//
//  EventCell.swift
//  AlignGroup
//
//  Created by SHANI SHAH on 13/02/19.
//  Copyright © 2019 SHANI SHAH. All rights reserved.
//

import UIKit

class EventCell: UITableViewCell {

    
    @IBOutlet weak var timeLabel: UILabel!
    @IBOutlet weak var timeDescription: UILabel!
    @IBOutlet weak var calendarImageView: UIImageView!
    
    @IBOutlet weak var userImageView: UIImageView!
    @IBOutlet weak var currentLabel: UILabel!
    @IBOutlet weak var currentTimeLabel: UILabel!
    @IBOutlet weak var dotLabel: UILabel!
    
    @IBOutlet weak var titleDayLabel: UILabel!
    @IBOutlet weak var dayDescriptionLabel: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        configure()
    }
    
    func configure() {
        selectionStyle = .none
        
        timeLabel.font = .custom(size: 10)
        timeDescription.font = .custom(size: 10)
        timeLabel.numberOfLines = 2
        
        currentLabel.font = .custom(size: 10)
        currentTimeLabel.font = .custom(size: 10)
        currentTimeLabel.textColor = .red
        currentLabel.textColor = .red
        currentLabel.text = "Time Now"
        
        dotLabel.layer.cornerRadius = dotLabel.frame.width / 2
        dotLabel.layer.masksToBounds = true
        dotLabel.backgroundColor = .red
        
        titleDayLabel.text = "All day"
        titleDayLabel.font = .custom(size: 10)
        dayDescriptionLabel.font = .custom(size: 10)
        userImageView.image = UIImage(named: "iconUsers")?.maskWithColor(color: .black)
        userImageView.contentMode = .scaleAspectFit
        calendarImageView.image = UIImage(named: "iconCalendar")?.maskWithColor(color: .black)
        calendarImageView.contentMode = .scaleAspectFit
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
