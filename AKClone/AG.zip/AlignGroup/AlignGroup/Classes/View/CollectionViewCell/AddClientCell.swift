//
//  AddClientCell.swift
//  AlignGroup
//
//  Created by Ample on 20/02/19.
//  Copyright © 2019 SHANI SHAH. All rights reserved.
//

import UIKit

class AddClientCell: UICollectionViewCell {
    
    override func awakeFromNib() {
        super.awakeFromNib()
        configure()
    }
    
    func configure(){
        self.backgroundColor = .appLightOrange
        self.layer.borderColor = UIColor.appColor.cgColor
        self.layer.borderWidth = 1
        self.layer.cornerRadius = 10
        self.layer.masksToBounds = true
    }
}
