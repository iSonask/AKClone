//
//  UsersCollectionViewCell.swift
//  AlignGroup
//
//  Created by Ample on 20/02/19.
//  Copyright © 2019 SHANI SHAH. All rights reserved.
//

import UIKit

class UsersCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var upperView: UIView!
    @IBOutlet weak var clientNameLabel: UILabel!
    @IBOutlet weak var clientImageView: UIImageView!
    @IBOutlet weak var lowerView: UIView!
    
    @IBOutlet weak var viewButton: UIButton!
    @IBOutlet weak var editButton: UIButton!
    @IBOutlet weak var deleteButton: UIButton!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        configure()
    }
    
    func configure(){
        self.layer.borderColor = UIColor.appColor.cgColor
        self.layer.borderWidth = 1
        self.layer.cornerRadius = 10
        self.layer.masksToBounds = true
        
        clientNameLabel.font = .bold()
        upperView.backgroundColor = .appLightOrange
        lowerView.backgroundColor = .appLightOrange
        
        deleteButton.setImage(UIImage(named: "iconTrash")?.maskWithColor(color: .black), for: .normal)
    }
}
