//
//  MenuCell.swift
//  AlignGroup
//
//  Created by Ample on 22/02/19.
//  Copyright © 2019 SHANI SHAH. All rights reserved.
//

import UIKit

class MenuCell: UITableViewCell {

    @IBOutlet weak var menuiconImageView: UIImageView!
    @IBOutlet weak var itemNameLabel: UILabel!
    @IBOutlet weak var disclosureIconImageView: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        configure()
    }
    
    func configure(){
        self.backgroundColor = .black
        itemNameLabel.textColor = .white
        itemNameLabel.font = .custom(size: 16)
        selectionStyle = .none
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

    func setupData(data: [String:String]) {
        itemNameLabel.text = data["name"]
        menuiconImageView.image = UIImage(named: data["image"]!)
    }
}
