//
//  AnnouncementCell.swift
//  AlignGroup
//
//  Created by SHANI SHAH on 06/02/19.
//  Copyright © 2019 SHANI SHAH. All rights reserved.
//

import UIKit

class AnnouncementCell: UITableViewCell {

    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var itemLabel: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        itemLabel.layer.cornerRadius = itemLabel.frame.width / 2
        itemLabel.layer.masksToBounds = true
        
        backgroundColor = .clear
        contentView.backgroundColor = .clear
        selectionStyle = .none
        titleLabel.font = .custom(size: 9)
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
