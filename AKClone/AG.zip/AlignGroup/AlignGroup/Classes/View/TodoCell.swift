//
//  TodoCell.swift
//  AlignGroup
//
//  Created by SHANI SHAH on 11/02/19.
//  Copyright © 2019 SHANI SHAH. All rights reserved.
//

import UIKit

class TodoCell: UITableViewCell {

    @IBOutlet weak var editButton: UIButton!
    @IBOutlet weak var viewButton: UIButton!
    @IBOutlet weak var priorityLabel: UILabel!
    
    @IBOutlet weak var completeLabel: UILabel!
    @IBOutlet weak var nameLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        configure()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func configure() {
        
        selectionStyle = .none
        backgroundColor = .clear
        contentView.backgroundColor = .clear
        
        viewButton.superview?.layer.cornerRadius = 10
        viewButton.superview?.layer.masksToBounds = true
        viewButton.superview?.backgroundColor = .white
        viewButton.superview?.layer.borderColor = UIColor.appColor.cgColor
        viewButton.superview?.layer.borderWidth = 1.0
        
        viewButton.setImage(UIImage(named: "iconEye"), for: .normal)
        editButton.setImage(UIImage(named: "iconPencil"), for: .normal)
        
        viewButton.imageView?.contentMode = .scaleAspectFit
        editButton.imageView?.contentMode = .scaleAspectFit
        
        priorityLabel.textAlignment = .center
        completeLabel.textAlignment = .center
        
        priorityLabel.font = .custom(size: 9)
        completeLabel.font =  .custom(size: 9)
        
        priorityLabel.textColor = .black
        completeLabel.textColor = .black
        
        nameLabel.textAlignment = .left
        nameLabel.font = .customBold(size: 10)
        nameLabel.textColor = .black
        nameLabel.numberOfLines = 0
    }

}
