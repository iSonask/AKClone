//
//  UsersOfClientsCell.swift
//  AlignGroup
//
//  Created by Ample on 19/02/19.
//  Copyright © 2019 SHANI SHAH. All rights reserved.
//

import UIKit

class UsersOfClientsCell: UITableViewCell {

    @IBOutlet weak var usersImageView: UIImageView!
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var lblDesignation: UILabel!
    
    @IBOutlet weak var viewButton: UIButton!
    @IBOutlet weak var editButton: UIButton!
    @IBOutlet weak var deleteButton: UIButton!
    var spacing: CGFloat = 6.0
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        configure()
    }

    func configure()  {
        selectionStyle = .none
        
        usersImageView.layer.cornerRadius = 5
        usersImageView.layer.masksToBounds = true
        usersImageView.contentMode = .scaleAspectFit
        lblName.font = .regular()
        lblName.textColor = .black
        lblDesignation.font = .regular()
        lblDesignation.textColor = .black
        
        viewButton.setTitle("View", for: .normal)
        viewButton.setTitleColor(.black, for: .normal)
        viewButton.backgroundColor = .appLightOrange
        viewButton.titleLabel?.font = .small()
        let iconEye = UIImage(named: "iconEye")
    viewButton.setImage(iconEye?.withRenderingMode(UIImage.RenderingMode.alwaysOriginal), for: .normal)
        
        editButton.setTitle("Edit", for: .normal)
        editButton.setTitleColor(.black, for: .normal)
        editButton.backgroundColor = .appLightOrange1
        editButton.titleLabel?.font = .small()
        editButton.setImage(UIImage(named: "iconPencil"), for: .normal)
        
        deleteButton.setTitle("Delete", for: .normal)
        deleteButton.setTitleColor(.black, for: .normal)
        deleteButton.backgroundColor = .appColor
        deleteButton.titleLabel?.font = .small()
        deleteButton.setImage(UIImage(named: "iconTrash")?.maskWithColor(color: .black), for: .normal)
    }
    
    func setupData(data: [String:String]) {
        lblName.text = data["name"]
        lblDesignation.text = data["designation"]
        usersImageView.image = UIImage(named: data["image"]!)
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
