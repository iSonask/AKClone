//
//  CompanyDetailCell.swift
//  AlignGroup
//
//  Created by SHANI SHAH on 06/02/19.
//  Copyright © 2019 SHANI SHAH. All rights reserved.
//

import UIKit

class CompanyDetailCell: UITableViewCell {

    @IBOutlet weak var colorLabel: UILabel!
    @IBOutlet weak var titleLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        titleLabel.font = .customBold(size: 9)
        backgroundColor = .clear
        contentView.backgroundColor = .clear
        selectionStyle = .none
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
