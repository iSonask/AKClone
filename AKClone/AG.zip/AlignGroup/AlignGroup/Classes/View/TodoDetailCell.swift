//
//  TaskDetailCell.swift
//  AlignGroup
//
//  Created by SHANI SHAH on 12/02/19.
//  Copyright © 2019 SHANI SHAH. All rights reserved.
//

import UIKit

class TodoDetailCell: UITableViewCell {

    
    @IBOutlet weak var completedView: UIView!
    @IBOutlet weak var constImageTrailingConstraint: NSLayoutConstraint!
    
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var numberLabel: UILabel!
    @IBOutlet weak var completionImageView: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        titleLabel.font = .custom(size: 9)
        numberLabel.font = .custom(size: 9)
        titleLabel.textColor = .red
        numberLabel.textColor = .black
        //Int(arc4random_uniform(6))
        selectionStyle = .none
        
        completedView.backgroundColor = Utilities.hexStringToUIColor(hex: "#\(Int(arc4random_uniform(999999)))")
    }
    
    func setupData(name:String,numberTitle:String,completed:Bool) {
        titleLabel.text = name
        numberLabel.text = numberTitle
        if completed{
            completionImageView.image = UIImage(named: "iconClose")
            constImageTrailingConstraint = constImageTrailingConstraint.setMultiplier(multiplier: 1.66)
        } else{
            constImageTrailingConstraint = constImageTrailingConstraint.setMultiplier(multiplier: 1.0)
            completionImageView.image = UIImage(named: "iconComplete")
        }
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
