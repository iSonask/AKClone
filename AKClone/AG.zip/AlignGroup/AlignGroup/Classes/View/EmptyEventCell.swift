//
//  EmptyEventCell.swift
//  AlignGroup
//
//  Created by SHANI SHAH on 13/02/19.
//  Copyright © 2019 SHANI SHAH. All rights reserved.
//

import UIKit

class EmptyEventCell: UITableViewCell {

    
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var createMeetingButton: UIButton!
    @IBOutlet weak var userImageView: UIImageView!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        configure()
    }
    
    func configure()  {
        titleLabel.font = .big()
        createMeetingButton.titleLabel?.font = .regular()
        createMeetingButton.backgroundColor = .appColor
        createMeetingButton.setTitleColor(.white, for: .normal)
        createMeetingButton.setTitle("Create Meeting", for: .normal)
        createMeetingButton.layer.cornerRadius = 20
        createMeetingButton.layer.masksToBounds = true
        
        userImageView.image = UIImage(named: "iconGroup")?.maskWithColor(color: .black)
        userImageView.contentMode = .scaleAspectFit
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
