//
//  AttendanceCell.swift
//  AlignGroup
//
//  Created by Shani Shah on 13/2/19.
//  Copyright © 2019 SHANI SHAH. All rights reserved.
//

import UIKit

class AttendanceCell: UITableViewCell {

    @IBOutlet weak var attedanceImageView: UIImageView!
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var lblDesignation: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        configure()
    }
    
    func configure()  {
        
        selectionStyle = .none
        
        
        attedanceImageView.layer.cornerRadius = 5
        attedanceImageView.layer.masksToBounds = true
        attedanceImageView.contentMode = .scaleAspectFit
        lblName.font = .bold()
        lblName.textColor = .black
        lblDesignation.font = .regular()
        lblDesignation.textColor = .black
    }

    func setupData(data: [String:String]) {
        lblName.text = data["name"]
        lblDesignation.text = data["designation"]
        attedanceImageView.image = UIImage(named: data["image"]!)
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
