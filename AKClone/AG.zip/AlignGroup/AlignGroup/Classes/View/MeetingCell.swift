//
//  MeetingCell.swift
//  AlignGroup
//
//  Created by SHANI SHAH on 14/02/19.
//  Copyright © 2019 SHANI SHAH. All rights reserved.
//

import UIKit

class MeetingCell: UITableViewCell {

    
    @IBOutlet weak var titleImageView: UIImageView!
    @IBOutlet weak var titleLabel: UILabel!
    
    @IBOutlet weak var calendarView: UIImageView!
    @IBOutlet weak var timeLabel: UILabel!
    @IBOutlet weak var timeDurationLabel: UILabel!
    
    @IBOutlet weak var userLabel: UILabel!
    @IBOutlet weak var replyImageView: UIImageView!
    @IBOutlet weak var replyLabel: UILabel!
    @IBOutlet weak var acceptedImageView: UIImageView!
    @IBOutlet weak var acceptedlabel: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        selectionStyle = .none
        backgroundColor = .clear
        contentView.backgroundColor = .clear
        configure()
    }

    func configure() {
        titleLabel.font = .customBold(size: 10)
        titleLabel.textColor = .black
        
        titleImageView.image = UIImage(named: "iconGroup")?.maskWithColor(color: .black)
        titleImageView.contentMode = .scaleAspectFit
        
        timeLabel.font = .custom(size: 10)
        timeLabel.textColor = .gray
        
        replyLabel.font = .custom(size: 10)
        replyLabel.textColor = .gray
        
        acceptedlabel.font = .custom(size: 10)
        acceptedlabel.textColor = .gray
        
        timeDurationLabel.textColor = .gray
        userLabel.textColor = .gray
        
        calendarView.image = UIImage(named: "iconCalendar")
        calendarView.contentMode = .scaleAspectFit
    }
    
    func setupData()  {
        
        titleLabel.text = "Set Up Your to-do List"
        replyLabel.text = "3 Replies"
        acceptedlabel.text = "2/10 Accepted"
        timeLabel.text = "Time \(Date().format(with: "dd.MM.YYYY HH:mm"))"
        var attributed = NSAttributedString(string: "\(Date().format(with: "HH:mm"))", attributes: [:]).boldedCustom10
        attributed += NSAttributedString(string: "   to   ", attributes: [NSAttributedString.Key.font: UIFont.custom(size: 10)])
        attributed += NSAttributedString(string: "\(Date().format(with: "HH:mm"))", attributes: [:]).boldedCustom10
        

        timeDurationLabel.attributedText = attributed
        var attributed1 = NSAttributedString(string: "Tony", attributes: [:]).colored(with: .appColor).boldedCustom10
        attributed1 += NSAttributedString(string: "    |    ", attributes: [NSAttributedString.Key.font: UIFont.custom(size: 10)])
        attributed1 += NSAttributedString(string: "\(Date().format(with: "dd.MM.YYYY  HH:mm"))", attributes: [NSAttributedString.Key.font: UIFont.custom(size: 10)])
        userLabel.attributedText = attributed1
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
