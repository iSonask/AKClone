//
//  TaskCell.swift
//  AlignGroup
//
//  Created by SHANI SHAH on 06/02/19.
//  Copyright © 2019 SHANI SHAH. All rights reserved.
//

import UIKit

class TaskCell: UITableViewCell {

    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var detailLabel: UILabel!
    @IBOutlet weak var itemImageView: UIImageView!
    @IBOutlet weak var rightImageView: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        itemImageView.contentMode = .scaleAspectFit
        itemImageView.image = UIImage(named: "iconList")
        rightImageView.contentMode = .scaleAspectFit
        rightImageView.image = UIImage(named: "iconRightArrow")
        backgroundColor = .clear
        contentView.backgroundColor = .clear
        selectionStyle = .none
        titleLabel.font = .customBold(size: 10)
        detailLabel.font = .custom(size: 9)
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
