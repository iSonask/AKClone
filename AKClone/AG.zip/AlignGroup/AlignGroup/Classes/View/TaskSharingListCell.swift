//
//  TaskSharingListCell.swift
//  AlignGroup
//
//  Created by sameer on 18/02/19.
//  Copyright © 2019 SHANI SHAH. All rights reserved.
//

import UIKit

class TaskSharingListCell: UITableViewCell {

    @IBOutlet weak var taskSharingImageView: UIImageView!
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var lblDesignation: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        configure()
    }

    func configure()  {
        selectionStyle = .none
        
        taskSharingImageView.layer.cornerRadius = 5
        taskSharingImageView.layer.masksToBounds = true
        taskSharingImageView.contentMode = .scaleAspectFit
        lblName.font = .bold()
        lblName.textColor = .black
        lblDesignation.font = .regular()
        lblDesignation.textColor = .black
    }
    
    func setupData(data: [String:String]) {
        lblName.text = data["name"]
        lblDesignation.text = data["designation"]
        taskSharingImageView.image = UIImage(named: data["image"]!)
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
}
