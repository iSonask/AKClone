//
//  TreeTableViewCell.swift
//  RATreeViewExamples
//
//  Created by Rafal Augustyniak on 22/11/15.
//  Copyright © 2015 com.Augustyniak. All rights reserved.
//

import UIKit

class TreeTableViewCell : UITableViewCell {

    @IBOutlet weak var containerView: UIView!
    @IBOutlet private weak var additionalButton: UIButton!
    @IBOutlet private weak var detailsLabel: UILabel!
    @IBOutlet private weak var customTitleLabel: UILabel!
    @IBOutlet  weak var deleteButton: UIButton!
    
    var additionButtonActionBlock : ((TreeTableViewCell) -> Void)?
    var deleteButtonActionBlock : ((TreeTableViewCell) -> Void)?
    
    private var additionalButtonHidden : Bool {
        get {
            return additionalButton.isHidden;
        }
        set {
            additionalButton.isHidden = newValue;
        }
    }

    override func awakeFromNib() {
        super.awakeFromNib()
        backgroundColor = .clear
        contentView.backgroundColor = .clear
        selectedBackgroundView? = UIView()
        selectedBackgroundView?.backgroundColor = .clear
        detailsLabel.textAlignment = .center
        detailsLabel.font = .bold()
        customTitleLabel.font = .regular()
        containerView.layer.borderColor = UIColor.gray.cgColor
        containerView.layer.borderWidth = 0.7
    }

    
    
    func setup(withTitle title: String, detailsText: String, level : Int, additionalButtonHidden: Bool) {
        customTitleLabel.text = title
        detailsLabel.text = detailsText
        self.additionalButtonHidden = additionalButtonHidden

        let backgroundColor: UIColor
        if level == 0 {
            backgroundColor = UIColor(red: 247.0/255.0, green: 247.0/255.0, blue: 247.0/255.0, alpha: 1.0)
        } else if level == 1 {
            backgroundColor = UIColor(red: 209.0/255.0, green: 238.0/255.0, blue: 252.0/255.0, alpha: 1.0)
        } else {
            backgroundColor = UIColor(red: 224.0/255.0, green: 248.0/255.0, blue: 216.0/255.0, alpha: 1.0)
        }
        
//        self.containerView.backgroundColor = backgroundColor
        self.contentView.backgroundColor = .clear//backgroundColor
        print(level)
        let left = 30.0 + 20.0 * CGFloat(level)
        self.containerView.frame.origin.x = left - 7.0
        
    }

    @IBAction func additionButtonTapped(_ sender : AnyObject) -> Void {
        if let action = additionButtonActionBlock {
            action(self)
        }
    }
    
    @IBAction func deleteButtonTapped(_ sender : AnyObject) -> Void {
        if let action = deleteButtonActionBlock {
            action(self)
        }
    }

}
