//
//  Meeting.swift
//  AlignGroup
//
//  Created by SHANI SHAH on 21/02/19.
//  Copyright © 2019 SHANI SHAH. All rights reserved.
//

import Foundation


class Meeting : Decodable{
    
    let id: String?
    let status: String?
    let subject: String?
    let startDate: String?
    let endDate: String?
    let note: String?
    let participantType: String?
    let flag: String?
 
    private enum CodingKeys : String, CodingKey {
        case flag = "Attendance_Flag",
        status = "meeting_status",
        endDate = "End_Date_Time",
        startDate = "Start_Date_Time",
        subject = "Subject",
        id = "meeting_id",
        note = "Notes",
        participantType = "participant_type"
    }
    
    required init(from decoder: Decoder) throws {
        
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.flag = try container.decode(String?.self, forKey: .flag)
        self.status = try container.decode(String?.self, forKey: .status)
        self.endDate = try container.decode(String?.self, forKey: .endDate)
        self.startDate = try container.decode(String?.self, forKey: .startDate)
        self.subject = try container.decode(String?.self, forKey: .subject)
        self.id = try container.decode(String?.self, forKey: .id)
        self.note = try container.decode(String?.self, forKey: .note)
        self.participantType = try container.decode(String?.self, forKey: .participantType)
        
    }
}
