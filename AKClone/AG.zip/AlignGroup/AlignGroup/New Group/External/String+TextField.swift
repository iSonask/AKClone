//
//  String+TextField.swift
//  ShoppingCart
//
//  Created by SHANI SHAH on 08/01/19.
//  Copyright © 2019 SHANI SHAH. All rights reserved.
//

import Foundation
import UIKit

extension String{
    
    public var isValidEmail: Bool {
        // http://emailregex.com/
        let regex = "^(?:[\\p{L}0-9!#$%\\&'*+/=?\\^_`{|}~-]+(?:\\.[\\p{L}0-9!#$%\\&'*+/=?\\^_`{|}~-]+)*|\"(?:[\\x01-\\x08\\x0b\\x0c\\x0e-\\x1f\\x21\\x23-\\x5b\\x5d-\\x7f]|\\\\[\\x01-\\x09\\x0b\\x0c\\x0e-\\x7f])*\")@(?:(?:[\\p{L}0-9](?:[a-z0-9-]*[\\p{L}0-9])?\\.)+[\\p{L}0-9](?:[\\p{L}0-9-]*[\\p{L}0-9])?|\\[(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?|[\\p{L}0-9-]*[\\p{L}0-9]:(?:[\\x01-\\x08\\x0b\\x0c\\x0e-\\x1f\\x21-\\x5a\\x53-\\x7f]|\\\\[\\x01-\\x09\\x0b\\x0c\\x0e-\\x7f])+)\\])$"
        return range(of: regex, options: .regularExpression, range: nil, locale: nil) != nil
    }
    
}

extension UITextField{
    
    //set cornerRadius
    func cornerRadius(){
        self.layoutIfNeeded()
        self.layer.cornerRadius = self.frame.height / 2
        self.clipsToBounds = true
    }
    
    //set bordercolor
    func borderColor(){
        self.layer.borderColor = UIColor.black.cgColor
        self.layer.borderWidth = 1.0
    }
    
    //set borderWidth
    func borderWidth(size:CGFloat){
        self.layer.borderWidth = size
    }
    
    //set begginning space - left space
    func setLeftPadding(paddingValue:CGFloat) {
        let paddingView = UIView(frame: CGRect(x: 0, y: 0, width: paddingValue, height: self.frame.size.height))
        self.leftViewMode = .always
        self.leftView = paddingView
    }
    
    //set end of space
    func setRightPadding(paddingValue:CGFloat){
        let paddingView = UIView(frame: CGRect(x: (self.frame.size.width - paddingValue), y: 0, width: paddingValue, height: self.frame.size.height))
        self.rightViewMode = .always
        self.rightView = paddingView
    }
}

@IBDesignable
class FormTextField: UITextField {
    
    fileprivate let placeHolderLabel: UILabel = UILabel()
    
    fileprivate var placeHolderHeight: CGFloat {
        return placeHolderLabel.font!.lineHeight + 5
    }
    
    override var textAlignment: NSTextAlignment {
        didSet{
            placeHolderLabel.textAlignment = textAlignment
        }
    }
    
    override var text: String? {
        didSet{
            layoutPlaceHolderLabel()
        }
    }
    
    @IBInspectable override var placeholder: String? {
        get{
            return placeHolderLabel.text
        }
        set{
            placeHolderLabel.text = newValue
        }
    }
    
    var placeHolderColor: UIColor = .appColor {
        didSet{
            placeHolderLabel.textColor = placeHolderColor
        }
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        commonInit()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        commonInit()
    }
    
    fileprivate func commonInit() {
        
        borderStyle = .none
        tintColor = UIColor.black
        textColor = UIColor.black
        font = UIFont.regular()
        
        // Place holder label
        placeHolderLabel.translatesAutoresizingMaskIntoConstraints = false
        placeHolderLabel.textAlignment  = textAlignment
        placeHolderLabel.textColor  = placeHolderColor
        addSubview(placeHolderLabel)
        
        var heightConstraint: NSLayoutConstraint?
        
        for constraint in constraints {
            if constraint.firstAttribute == .height {
                heightConstraint = constraint
                heightConstraint?.constant = 50
            }
        }
        
        if heightConstraint == nil {
            heightConstraint = NSLayoutConstraint(item: self,
                                                  attribute: .height,
                                                  relatedBy: .equal,
                                                  toItem: nil,
                                                  attribute: .notAnAttribute,
                                                  multiplier: 1,
                                                  constant: 50)
            addConstraint(heightConstraint!)
        }
        
        
        //        drawBottomLine()
        layoutPlaceHolderLabel()
        
        // Add observer
        let notificationCenter = NotificationCenter.default
        notificationCenter.addObserver(self, selector: #selector(textFieldDidBeginEditing), name: UITextField.textDidBeginEditingNotification, object: nil)
        notificationCenter.addObserver(self, selector: #selector(textFieldDidEndEditing), name: UITextField.textDidEndEditingNotification, object: nil)
        
    }
    
    deinit {
        
        // Remove observer
        NotificationCenter.default.removeObserver(self)
        
    }
    
    // MARK: - override methods
    
    override func textRect(forBounds bounds: CGRect) -> CGRect {
        var rect = super.textRect(forBounds: bounds)
        rect.origin.y += placeHolderHeight
        rect.size.height -= placeHolderHeight
        rect.origin.x += 8
        rect.size.width -= 8
        
        return rect
    }
    
    override func editingRect(forBounds bounds: CGRect) -> CGRect {
        var rect = super.editingRect(forBounds: bounds)
        rect.origin.y += placeHolderHeight
        rect.size.height -= placeHolderHeight
        rect.origin.x += 8
        rect.size.width -= 8
        
        return rect
    }
    
    override func leftViewRect(forBounds bounds: CGRect) -> CGRect {
        let rect = CGRect(x: 0, y: frame.size.height - 22 - 5, width: 22, height: 22)
        return rect
    }
    
    // MARK: - Notification observer
    
    @objc func textFieldDidBeginEditing() {
        layoutPlaceHolderLabel()
    }
    
    @objc func textFieldDidEndEditing() {
        layoutPlaceHolderLabel()
    }
    
    // MARK: - private methods
    
    fileprivate func layoutPlaceHolderLabel() {
        
        placeHolderLabel.alpha = 0
        
        placeHolderLabel.removeFromSuperview()
        addSubview(placeHolderLabel)
        
        if isEditing || text!.count > 0 {
            
            placeHolderLabel.font = UIFont.regular()
            
            var leftMargin: CGFloat = 8
            var rightMargin: CGFloat = 8
            
            if let leftView = leftView{
                leftMargin += leftView.frame.size.width
            }
            
            if let rightView = rightView{
                rightMargin += rightView.frame.size.width
            }
            
            let metrics: [String : Any] = [
                "leftMargin" : leftMargin,
                "rightMargin" : rightMargin,
                "lineHeight" : placeHolderHeight,
                ]
            
            let views: [String : Any] = [
                "placeHolderLabel" : placeHolderLabel
            ]
            
            addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "H:|-leftMargin-[placeHolderLabel]-rightMargin-|", options: [], metrics: metrics, views: views))
            
            addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "V:|-(==5)-[placeHolderLabel(lineHeight)]-(>=5)-|", options: [], metrics: metrics, views: views))
            layoutIfNeeded()
            
            UIView.animate(withDuration: 0.2, animations: {
                self.placeHolderLabel.alpha = 1
            })
            
        }else {
            
            placeHolderLabel.font = font
            
            var leftMargin: CGFloat = 8
            var rightMargin: CGFloat = 8
            
            if let leftView = leftView{
                leftMargin += leftView.frame.size.width
            }
            
            if let rightView = rightView{
                rightMargin += rightView.frame.size.width
            }
            
            let metrics: [String : Any] = [
                "leftMargin" : leftMargin,
                "rightMargin" : rightMargin,
                "lineHeight" : placeHolderHeight,
                ]
            
            let views: [String : Any] = [
                "placeHolderLabel" : placeHolderLabel
            ]
            
            addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "H:|-leftMargin-[placeHolderLabel]-rightMargin-|", options: [], metrics: metrics, views: views))
            addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "V:|-(>=5)-[placeHolderLabel(lineHeight)]-(==5)-|", options: [], metrics: metrics, views: views))
            
            layoutIfNeeded()
            
            UIView.animate(withDuration: 0.2, animations: {
                self.placeHolderLabel.alpha = 1
            })
            
        }
        
    }
    
}


public extension NSAttributedString {
    
    #if os(iOS)
    /// SwifterSwift: Bolded string.
    public var bolded: NSAttributedString {
        return applying(attributes: [.font: UIFont.bold()])
    }
    
    public var boldedCustom10: NSAttributedString {
        return applying(attributes: [.font: UIFont.customBold(size: 10)])
    }
    
    #endif
    
    /// SwifterSwift: Underlined string.
    public var underlined: NSAttributedString {
        return applying(attributes: [.underlineStyle: NSUnderlineStyle.single.rawValue])
    }
    
    #if os(iOS)
    /// SwifterSwift: Italicized string.
    public var italicized: NSAttributedString {
        return applying(attributes: [.font: UIFont.italicSystemFont(ofSize: UIFont.systemFontSize)])
    }
    #endif
    
    /// SwifterSwift: Struckthrough string.
    public var struckthrough: NSAttributedString {
        return applying(attributes: [.strikethroughStyle: NSNumber(value: NSUnderlineStyle.single.rawValue as Int)])
    }
    
    /// SwifterSwift: Dictionary of the attributes applied across the whole string
    public var attributes: [NSAttributedString.Key: Any] {
        guard self.length > 0 else { return [:] }
        return attributes(at: 0, effectiveRange: nil)
    }
    
}

// MARK: - Methods
public extension NSAttributedString {
    
    /// SwifterSwift: Applies given attributes to the new instance of NSAttributedString initialized with self object
    ///
    /// - Parameter attributes: Dictionary of attributes
    /// - Returns: NSAttributedString with applied attributes
    fileprivate func applying(attributes: [NSAttributedString.Key: Any]) -> NSAttributedString {
        let copy = NSMutableAttributedString(attributedString: self)
        let range = (string as NSString).range(of: string)
        copy.addAttributes(attributes, range: range)
        
        return copy
    }
    
    #if os(macOS)
    /// SwifterSwift: Add color to NSAttributedString.
    ///
    /// - Parameter color: text color.
    /// - Returns: a NSAttributedString colored with given color.
    public func colored(with color: NSColor) -> NSAttributedString {
        return applying(attributes: [.foregroundColor: color])
    }
    #else
    /// SwifterSwift: Add color to NSAttributedString.
    ///
    /// - Parameter color: text color.
    /// - Returns: a NSAttributedString colored with given color.
    public func colored(with color: UIColor) -> NSAttributedString {
        return applying(attributes: [.foregroundColor: color])
    }
    #endif
    
    /// SwifterSwift: Apply attributes to substrings matching a regular expression
    ///
    /// - Parameters:
    ///   - attributes: Dictionary of attributes
    ///   - pattern: a regular expression to target
    /// - Returns: An NSAttributedString with attributes applied to substrings matching the pattern
    public func applying(attributes: [NSAttributedString.Key: Any], toRangesMatching pattern: String) -> NSAttributedString {
        guard let pattern = try? NSRegularExpression(pattern: pattern, options: []) else { return self }
        
        let matches = pattern.matches(in: string, options: [], range: NSRange(0..<length))
        let result = NSMutableAttributedString(attributedString: self)
        
        for match in matches {
            result.addAttributes(attributes, range: match.range)
        }
        
        return result
    }
    
    /// SwifterSwift: Apply attributes to occurrences of a given string
    ///
    /// - Parameters:
    ///   - attributes: Dictionary of attributes
    ///   - target: a subsequence string for the attributes to be applied to
    /// - Returns: An NSAttributedString with attributes applied on the target string
    public func applying<T: StringProtocol>(attributes: [NSAttributedString.Key: Any], toOccurrencesOf target: T) -> NSAttributedString {
        let pattern = "\\Q\(target)\\E"
        
        return applying(attributes: attributes, toRangesMatching: pattern)
    }
    
}

// MARK: - Operators
public extension NSAttributedString {
    
    /// SwifterSwift: Add a NSAttributedString to another NSAttributedString.
    ///
    /// - Parameters:
    ///   - lhs: NSAttributedString to add to.
    ///   - rhs: NSAttributedString to add.
    public static func += (lhs: inout NSAttributedString, rhs: NSAttributedString) {
        let string = NSMutableAttributedString(attributedString: lhs)
        string.append(rhs)
        lhs = string
    }
    
    /// SwifterSwift: Add a NSAttributedString to another NSAttributedString and return a new NSAttributedString instance.
    ///
    /// - Parameters:
    ///   - lhs: NSAttributedString to add.
    ///   - rhs: NSAttributedString to add.
    /// - Returns: New instance with added NSAttributedString.
    public static func + (lhs: NSAttributedString, rhs: NSAttributedString) -> NSAttributedString {
        let string = NSMutableAttributedString(attributedString: lhs)
        string.append(rhs)
        return NSAttributedString(attributedString: string)
    }
    
    /// SwifterSwift: Add a NSAttributedString to another NSAttributedString.
    ///
    /// - Parameters:
    ///   - lhs: NSAttributedString to add to.
    ///   - rhs: String to add.
    public static func += (lhs: inout NSAttributedString, rhs: String) {
        lhs += NSAttributedString(string: rhs)
    }
    
    /// SwifterSwift: Add a NSAttributedString to another NSAttributedString and return a new NSAttributedString instance.
    ///
    /// - Parameters:
    ///   - lhs: NSAttributedString to add.
    ///   - rhs: String to add.
    /// - Returns: New instance with added NSAttributedString.
    public static func + (lhs: NSAttributedString, rhs: String) -> NSAttributedString {
        return lhs + NSAttributedString(string: rhs)
    }
    
}
