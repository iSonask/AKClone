//
//  RedirectionProtocol.swift
//  ShoppingCart
//
//  Created by SHANI SHAH on 08/01/19.
//  Copyright © 2019 SHANI SHAH. All rights reserved.
//

import Foundation
import UIKit


protocol RedirectionProtocol {
    static func getViewController() -> UIViewController
}

//MARK:- Main Storyboard

protocol StoryboardRedirectionProtocol: RedirectionProtocol {
    
    static var storyboard: UIStoryboard { get }
    static var storyboardIdentifier: String { get }
}

extension StoryboardRedirectionProtocol where Self: UIViewController {
    
    static var storyboard: UIStoryboard {
        return UIStoryboard(name: "Main", bundle: nil)
    }
    
    static var storyboardIdentifier: String {
        return String(describing: self)
    }
    
    private static func fromStoryboard() -> Self {
        
        let viewController = storyboard.instantiateViewController(withIdentifier: storyboardIdentifier) as! Self
        return viewController
    }
    
    static func getViewController() -> UIViewController {
        return fromStoryboard()
    }
}


//MARK:- Task Storyboard

protocol TaskRedirectionProtocol: RedirectionProtocol {
    
    static var storyboard: UIStoryboard { get }
    static var storyboardIdentifier: String { get }
}

extension TaskRedirectionProtocol where Self: UIViewController {
    
    static var storyboard: UIStoryboard {
        return UIStoryboard(name: "Task", bundle: nil)
    }
    
    static var storyboardIdentifier: String {
        return String(describing: self)
    }
    
    private static func fromStoryboard() -> Self {
        
        let viewController = storyboard.instantiateViewController(withIdentifier: storyboardIdentifier) as! Self
        return viewController
    }
    
    static func getViewController() -> UIViewController {
        return fromStoryboard()
    }
}


//MARK:- Calendar Storyboard

protocol CalendarRedirectionProtocol: RedirectionProtocol {
    
    static var storyboard: UIStoryboard { get }
    static var storyboardIdentifier: String { get }
}

extension CalendarRedirectionProtocol where Self: UIViewController {
    
    static var storyboard: UIStoryboard {
        return UIStoryboard(name: "Calendar", bundle: nil)
    }
    
    static var storyboardIdentifier: String {
        return String(describing: self)
    }
    
    private static func fromStoryboard() -> Self {
        
        let viewController = storyboard.instantiateViewController(withIdentifier: storyboardIdentifier) as! Self
        return viewController
    }
    
    static func getViewController() -> UIViewController {
        return fromStoryboard()
    }
}




//MARK:- User Storyboard
protocol UsersRedirectionProtocol: RedirectionProtocol {
    
    static var storyboard: UIStoryboard { get }
    static var storyboardIdentifier: String { get }
}

extension UsersRedirectionProtocol where Self: UIViewController {
    
    static var storyboard: UIStoryboard {
        return UIStoryboard(name: "Users", bundle: nil)
    }
    
    static var storyboardIdentifier: String {
        return String(describing: self)
    }
    
    private static func fromStoryboard() -> Self {
        
        let viewController = storyboard.instantiateViewController(withIdentifier: storyboardIdentifier) as! Self
        return viewController
    }
    
    static func getViewController() -> UIViewController {
        return fromStoryboard()
    }
}


//MARK:- Menu Storyboard

protocol MenuRedirectionProtocol: RedirectionProtocol {
    
    static var storyboard: UIStoryboard { get }
    static var storyboardIdentifier: String { get }
}

extension MenuRedirectionProtocol where Self: UIViewController {
    
    static var storyboard: UIStoryboard {
        return UIStoryboard(name: "Menu", bundle: nil)
    }
    
    static var storyboardIdentifier: String {
        return String(describing: self)
    }
    
    private static func fromStoryboard() -> Self {
        
        let viewController = storyboard.instantiateViewController(withIdentifier: storyboardIdentifier) as! Self
        return viewController
    }
    
    static func getViewController() -> UIViewController {
        return fromStoryboard()
    }
}

