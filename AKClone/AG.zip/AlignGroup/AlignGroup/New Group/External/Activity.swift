//
//  Activity.swift
//  ShoppingCart
//
//  Created by SHANI SHAH on 08/01/19.
//  Copyright © 2019 SHANI SHAH. All rights reserved.
//

import Foundation
import UIKit

var activity = UIActivityIndicatorView()


extension UIViewController{
    
    
    func showActivityIndicator() {
        let transform: CGAffineTransform = CGAffineTransform(scaleX: 2.0, y: 2.0)
        activity.transform = transform
        activity.center = view.center
        activity.hidesWhenStopped = true
        activity.style = .whiteLarge
        activity.color = .black
        view.addSubview(activity)
        activity.startAnimating()
    }
    
    func hideActivity(){
        activity.stopAnimating()
    }
}

