//
//  Font.swift
//  ShoppingCart
//
//  Created by SHANI SHAH on 08/01/19.
//  Copyright © 2019 SHANI SHAH. All rights reserved.
//

import Foundation
import UIKit


extension UIFont{
    
    class func custom(size: Int) -> UIFont {
        return UIFont(name: "NexaRegular", size: CGFloat(size))!
    }
    
    class func customBold(size: Int) -> UIFont {
        return UIFont(name: "NexaBold", size: CGFloat(size))!
    }
    
    class func regular() -> UIFont {
        return UIFont(name: "NexaRegular", size: 13)!//.systemFont(ofSize: 13)
    }
    
    class func big() -> UIFont {
        return UIFont(name: "NexaRegular", size: 16)!
    }
    
    class func boldBig() -> UIFont {
        return UIFont(name: "NexaBold", size: 16)!
    }
    
    class func bold() -> UIFont {
        return UIFont(name: "NexaBold", size: 13)!
    }
    
    class func small() -> UIFont {
        return UIFont(name: "NexaRegular", size: 10)!//.systemFont(ofSize: 13)
    }
}
