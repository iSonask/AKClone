//
//  PieCharts.h
//  PieCharts
//
//  Created by Ivan Schuetz on 03/01/2017.
//  Copyright © 2017 Ivan Schuetz. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for PieCharts.
FOUNDATION_EXPORT double PieChartsVersionNumber;

//! Project version string for PieCharts.
FOUNDATION_EXPORT const unsigned char PieChartsVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <PieCharts/PublicHeader.h>


