//
//  ClosureButton.swift
//  ShoppingCart
//
//  Created by SHANI SHAH on 10/01/19.
//  Copyright © 2019 SHANI SHAH. All rights reserved.
//

//https://stackoverflow.com/questions/28894765/uibutton-action-in-table-view-cell/41374087

import Foundation
import UIKit

class ClosureSleeve {
    let closure: ()->()
    
    init (_ closure: @escaping ()->()) {
        self.closure = closure
    }
    
    @objc func invoke () {
        closure()
    }
}


extension UIControl {
    
    func addAction(for controlEvents: UIControl.Event, _ closure: @escaping ()->()) {
        let sleeve = ClosureSleeve(closure)
        addTarget(sleeve, action: #selector(ClosureSleeve.invoke), for: controlEvents)
        objc_setAssociatedObject(self, String(format: "[%d]", arc4random()), sleeve, objc_AssociationPolicy.OBJC_ASSOCIATION_RETAIN)
    }
}
