//
//  CoreChartOrientation.swift
//  CoreCharts
//
//  Created by Kemal Türk on 17.04.2018.
//  Copyright © 2018 Çağrı ÇOLAK. All rights reserved.
//

enum CoreChartOrientation {
    case Vertical
    case Horizontal
}
