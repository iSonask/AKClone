//
//  CVCalendarViewDelegate.swift
//  CVCalendar
//
//  Created by E. Mozharovsky on 12/27/14.
//  Copyright (c) 2014 GameApp. All rights reserved.
//

import UIKit

@objc
public protocol CVCalendarViewDelegate {
    func presentationMode() -> CalendarMode
    func firstWeekday() -> Weekday

    /*
    Determines whether resizing should cause related views' animation.
    */
    @objc optional func shouldAnimateResizing() -> Bool
    @objc optional func toggleDateAnimationDuration() -> Double

    @objc optional func shouldScrollOnOutDayViewSelection() -> Bool
    @objc optional func shouldAutoSelectDayOnWeekChange() -> Bool
    @objc optional func shouldAutoSelectDayOnMonthChange() -> Bool
    @objc optional func shouldShowWeekdaysOut() -> Bool
    @objc optional func shouldSelectDayView(_ dayView: DayView1) -> Bool
    @objc optional func didSelectDayView(_ dayView: DayView1, animationDidFinish: Bool)
    @objc optional func presentedDateUpdated(_ date: CVDate)
    @objc optional func topMarker(shouldDisplayOnDayView dayView: DayView1) -> Bool
    @objc optional func dotMarker(shouldMoveOnHighlightingOnDayView dayView: DayView1) -> Bool
    @objc optional func dotMarker(shouldShowOnDayView dayView: DayView1) -> Bool
    @objc optional func dotMarker(colorOnDayView dayView: DayView1) -> [UIColor]
    @objc optional func dotMarker(moveOffsetOnDayView dayView: DayView1) -> CGFloat
    @objc optional func dotMarker(sizeOnDayView dayView: DayView1) -> CGFloat

    @objc optional func selectionViewPath() -> ((CGRect) -> (UIBezierPath))
    @objc optional func shouldShowCustomSingleSelection() -> Bool

    @objc optional func preliminaryView(viewOnDayView dayView: DayView1) -> UIView
    @objc optional func preliminaryView(shouldDisplayOnDayView dayView: DayView1) -> Bool

    @objc optional func supplementaryView(viewOnDayView dayView: DayView1) -> UIView
    @objc optional func supplementaryView(shouldDisplayOnDayView dayView: DayView1) -> Bool
    

    @objc optional func didShowNextMonthView(_ date: Foundation.Date)
    @objc optional func didShowPreviousMonthView(_ date: Foundation.Date)
  
    @objc optional func didShowNextWeekView(from startDayView: DayView1, to endDayView: DayView1)
    @objc optional func didShowPreviousWeekView(from startDayView: DayView1, to endDayView: DayView1)
    
    // Localization
    @objc optional func calendar() -> Calendar?
    
    // Range selection
    @objc optional func shouldSelectRange() -> Bool
    @objc optional func didSelectRange(from startDayView: DayView1, to endDayView: DayView1)
    @objc optional func disableScrollingBeforeDate() -> Date
    @objc optional func disableScrollingBeyondDate() -> Date
    @objc optional func maxSelectableRange() -> Int
    @objc optional func earliestSelectableDate() -> Date
    @objc optional func latestSelectableDate() -> Date
}
