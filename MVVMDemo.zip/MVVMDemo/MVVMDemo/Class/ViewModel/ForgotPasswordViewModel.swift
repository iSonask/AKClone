//
//  ForgotPasswordViewModel.swift
//  MVVMDemo
//
//  
//

import Foundation

class ForgotPasswordViewModel {
    weak var coordinator: ForgotPasswordCoordinator?
    var email: String = ""
    
    var resetSuccess: (() -> Void)?
    var resetFailure: ((String) -> Void)?
    
    func resetPassword() {
        // Simulate password reset logic. Replace with actual service.
        if email.contains("@") {
            resetSuccess?()
            coordinator?.navigationController.popViewController(animated: true)
        } else {
            resetFailure?("Invalid email address")
        }
    }
    
    
}
