//
//  SignupViewModel.swift
//  MVVMDemo
//
//  
//

import Foundation


class SignupViewModel {
    

    var username: String = ""
    var password: String = ""
    var confirmPassword: String = ""
    
    var signupSuccess: (() -> Void)?
    var signupFailure: ((String) -> Void)?
    
    func signup() {
        // Simulate signup logic. Replace with actual service.
        if username.isEmpty {
            signupFailure?("email not empty")
        } else if password.isEmpty {
            signupFailure?("password not empty")
        } else if confirmPassword.isEmpty {
            signupFailure?("confirmPassword not empty")
        } else if password == confirmPassword {
            signupSuccess?()
        } else {
            signupFailure?("Passwords do not match")
        }
    }
}
