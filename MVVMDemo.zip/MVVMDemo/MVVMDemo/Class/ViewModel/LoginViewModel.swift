//
//  LoginViewModel.swift
//  MVVMDemo
//
//  
//

import Foundation

class LoginViewModel {
    var username: String = ""
    var password: String = ""
    
    var loginSuccess: (() -> Void)?
    var loginFailure: ((String) -> Void)?
    
    
    
    func login() {
        // Simulate login logic. Replace with actual authentication service.
        
        if username == "user" && password == "password" {
            loginSuccess?()
            
        } else {
            loginFailure?("Invalid username or password")
        }
    }
    
}
