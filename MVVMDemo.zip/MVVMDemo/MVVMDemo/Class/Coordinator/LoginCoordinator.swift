//
//  LoginCoordinator.swift
//  MVVMDemo
//
//  
//

import Foundation
import UIKit

class LoginCoordinator: Coordinator {
    var navigationController: UINavigationController
    
    init(navigationController: UINavigationController) {
        self.navigationController = navigationController
    }
    
    func start() {
        let viewModel = LoginViewModel()
        let loginVC = LoginViewController.instantiate()
        loginVC.viewModel = viewModel
        loginVC.coordinator = self
        navigationController.pushViewController(loginVC, animated: true)
    }
    
    func showSignup() {
        let signupCoordinator = SignupCoordinator(navigationController: navigationController)
        signupCoordinator.start()
    }
    
    func showForgotPassword() {
        let forgotPasswordCoordinator = ForgotPasswordCoordinator(navigationController: navigationController)
        forgotPasswordCoordinator.start()
    }
    
    func showHome() {
        let mainTabBarCoordinator = MainTabBarCoordinator(navigationController: navigationController)
        mainTabBarCoordinator.start()
    }
}
