//
//  SignupCoordinator.swift
//  MVVMDemo
//
//  
//

import Foundation
import UIKit

class SignupCoordinator: Coordinator {
    var navigationController: UINavigationController
    
    init(navigationController: UINavigationController) {
        self.navigationController = navigationController
    }
    
    func start() {
        let viewModel = SignupViewModel()
        let signupVC = SignUpViewController.instantiate()
        signupVC.viewModel = viewModel
        signupVC.coordinator = self
        navigationController.pushViewController(signupVC, animated: true)
    }
    
    func showHome() {
        let mainTabBarCoordinator = MainTabBarCoordinator(navigationController: navigationController)
        mainTabBarCoordinator.start()
    }
}
