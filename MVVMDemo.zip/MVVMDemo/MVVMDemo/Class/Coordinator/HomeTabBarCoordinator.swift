//
//  HomeTabBarCoordinator.swift
//  MVVMDemo
//
//  
//

import Foundation
import UIKit

class MainTabBarCoordinator: Coordinator {
    
    var navigationController: UINavigationController
    
    init(navigationController: UINavigationController) {
        self.navigationController = navigationController
    }
    
    func start() {
        let tabBarVC = HomeTabBar.instantiate()
        navigationController.pushViewController(tabBarVC, animated: true)
    }
}
