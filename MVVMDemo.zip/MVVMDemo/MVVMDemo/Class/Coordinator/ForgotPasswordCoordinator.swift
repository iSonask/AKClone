//
//  ForgotPasswordCoordinator.swift
//  MVVMDemo
//
//  
//

import Foundation
import UIKit

class ForgotPasswordCoordinator: Coordinator {
    var navigationController: UINavigationController
    
    init(navigationController: UINavigationController) {
        self.navigationController = navigationController
    }
    
    func start() {
        let viewModel = ForgotPasswordViewModel()
        let forgotPasswordVC = ForgotPasswordViewController.instantiate()
        forgotPasswordVC.viewModel = viewModel
        viewModel.coordinator = self
        navigationController.pushViewController(forgotPasswordVC, animated: true)
    }
}
