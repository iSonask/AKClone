//
//  User.swift
//  MVVMDemo
//
//  
//

import Foundation

struct User {
    let username: String
    let password: String
}
