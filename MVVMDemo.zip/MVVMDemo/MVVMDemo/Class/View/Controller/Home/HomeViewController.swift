//
//  HomeViewController.swift
//  MVVMDemo
//
//  
//

import UIKit

class HomeViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    static func instantiate() -> HomeViewController {
        let storyboard = UIStoryboard(name: "Main", bundle: .main)
        return storyboard.instantiateViewController(identifier: "HomeViewController") as! HomeViewController
    }
}
