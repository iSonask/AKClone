//
//  SignUpViewController.swift
//  MVVMDemo
//
//  
//

import UIKit

class SignUpViewController: UIViewController {

    @IBOutlet weak var usernameTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var confirmPasswordTextField: UITextField!
    @IBOutlet weak var signupButton: UIButton!
    
    lazy var coordinator = SignupCoordinator(navigationController: self.navigationController!)
    var viewModel = SignupViewModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupBindings()
    }
    
    @IBAction func signupButtonTapped(_ sender: UIButton) {
        viewModel.username = usernameTextField.text ?? ""
        viewModel.password = passwordTextField.text ?? ""
        viewModel.confirmPassword = confirmPasswordTextField.text ?? ""
        viewModel.signup()
    }
    
    private func setupBindings() {
        
        viewModel.signupSuccess = { [weak self] in
            guard let this = self else { return }
            this.coordinator.showHome()
        }
        
        viewModel.signupFailure = { [weak self] errorMessage in
            guard let this = self else { return }
        }
    }

    static func instantiate() -> SignUpViewController {
        let storyboard = UIStoryboard(name: "Main", bundle: .main)
        return storyboard.instantiateViewController(identifier: "SignUpViewController") as! SignUpViewController
    }
}
