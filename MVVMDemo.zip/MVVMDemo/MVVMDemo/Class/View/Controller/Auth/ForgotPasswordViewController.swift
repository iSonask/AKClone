//
//  ForgotPasswordViewController.swift
//  MVVMDemo
//
//  
//

import UIKit

class ForgotPasswordViewController: UIViewController {

    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var resetButton: UIButton!
    
    var viewModel = ForgotPasswordViewModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupBindings()
    }
    
    @IBAction func resetButtonTapped(_ sender: UIButton) {
        viewModel.email = emailTextField.text ?? ""
        viewModel.resetPassword()
    }
    
    private func setupBindings() {
        viewModel = ForgotPasswordViewModel()
        
        viewModel.resetSuccess = { [weak self] in
        }
        
        viewModel.resetFailure = { [weak self] errorMessage in
        }
    }
    
    static func instantiate() -> ForgotPasswordViewController {
        let storyboard = UIStoryboard(name: "Main", bundle: .main)
        return storyboard.instantiateViewController(identifier: "ForgotPasswordViewController") as! ForgotPasswordViewController
    }

}
