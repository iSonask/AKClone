//
//  LoginViewController.swift
//  MVVMDemo
//
//  
//

import UIKit

class LoginViewController: UIViewController {

    @IBOutlet weak var usernameTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var loginButton: UIButton!
    var coordinator: LoginCoordinator!
    var viewModel: LoginViewModel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupBindings()
        coordinator = LoginCoordinator(navigationController: self.navigationController!)
    }
    
    @IBAction func loginButtonTapped(_ sender: UIButton) {
        viewModel.username = usernameTextField.text ?? ""
        viewModel.password = passwordTextField.text ?? ""
        viewModel.login()
        
    }
    
    @IBAction func signupButtonTapped(_ sender: UIButton) {
        coordinator.showSignup()
        
    }
    
    @IBAction func forgotPasswordButtonTapped(_ sender: UIButton) {
        coordinator.showForgotPassword()
    }
    
    private func setupBindings() {
        viewModel = LoginViewModel()
        viewModel.loginSuccess = { [weak self] in
            guard let this = self else { return }
            this.coordinator.showHome()
        }
        
        viewModel.loginFailure = { [weak self] errorMessage in
            guard let this = self else { return }
        }
    }
    
    static func instantiate() -> LoginViewController {
        let storyboard = UIStoryboard(name: "Main", bundle: .main)
        return storyboard.instantiateViewController(identifier: "LoginViewController") as! LoginViewController
    }



}

